.class public Lcom/particle/ParticlesDrawable;
.super Landroid/graphics/drawable/Drawable;

# interfaces
.implements Landroid/graphics/drawable/Animatable;
.implements Lcom/particle/ParticlesScene;
.implements Lcom/particle/c;
.implements Lcom/particle/g;


# annotations
.annotation build Landroid/support/annotation/Keep;
.end annotation


# instance fields
.field private final mCanvasParticlesView:Lcom/particle/a;

.field private final mController:Lcom/particle/f;


# direct methods
.method public constructor <init>()V
    .registers 8

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Landroid/graphics/drawable/Drawable;-><init>()V

    move-object v1, v0

    new-instance v2, Lcom/particle/a;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    invoke-direct {v3}, Lcom/particle/a;-><init>()V

    iput-object v2, v1, Lcom/particle/ParticlesDrawable;->mCanvasParticlesView:Lcom/particle/a;

    move-object v1, v0

    new-instance v2, Lcom/particle/f;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    move-object v4, v0

    move-object v5, v0

    invoke-direct {v3, v4, v5}, Lcom/particle/f;-><init>(Lcom/particle/c;Lcom/particle/g;)V

    iput-object v2, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .registers 6
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mCanvasParticlesView:Lcom/particle/a;

    move-object v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/a;->a(Landroid/graphics/Canvas;)V

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v2}, Lcom/particle/f;->e()V

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mCanvasParticlesView:Lcom/particle/a;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Lcom/particle/a;->a(Landroid/graphics/Canvas;)V

    return-void
.end method

.method public drawLine(FFFFFI)V
    .registers 21
    .param p6    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move-object v7, v0

    iget-object v7, v7, Lcom/particle/ParticlesDrawable;->mCanvasParticlesView:Lcom/particle/a;

    move v8, v1

    move v9, v2

    move v10, v3

    move v11, v4

    move v12, v5

    move v13, v6

    invoke-virtual/range {v7 .. v13}, Lcom/particle/a;->drawLine(FFFFFI)V

    return-void
.end method

.method public fillCircle(FFFI)V
    .registers 15
    .param p4    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, v0

    iget-object v5, v5, Lcom/particle/ParticlesDrawable;->mCanvasParticlesView:Lcom/particle/a;

    move v6, v1

    move v7, v2

    move v8, v3

    move v9, v4

    invoke-virtual {v5, v6, v7, v8, v9}, Lcom/particle/a;->fillCircle(FFFI)V

    return-void
.end method

.method public getAlpha()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->a()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getDotColor()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getDotColor()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getFrameDelay()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getFrameDelay()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getLineColor()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getLineColor()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getLineDistance()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getLineDistance()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getLineThickness()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getLineThickness()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getMaxDotRadius()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getMaxDotRadius()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getMinDotRadius()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getMinDotRadius()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getNumDots()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getNumDots()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getOpacity()I
    .registers 3

    move-object v0, p0

    const/4 v1, -0x3

    move v0, v1

    return v0
.end method

.method public getPaint()Landroid/graphics/Paint;
    .registers 3
    .annotation build Landroid/support/annotation/Keep;
    .end annotation

    .annotation build Landroid/support/annotation/NonNull;
    .end annotation

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mCanvasParticlesView:Lcom/particle/a;

    invoke-virtual {v1}, Lcom/particle/a;->a()Landroid/graphics/Paint;

    move-result-object v1

    move-object v0, v1

    return-object v0
.end method

.method public getStepMultiplier()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getStepMultiplier()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public inflate(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    .registers 15
    .param p1    # Landroid/content/res/Resources;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .param p3    # Landroid/util/AttributeSet;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .param p4    # Landroid/content/res/Resources$Theme;
        .annotation build Landroid/support/annotation/Nullable;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, v0

    move-object v6, v1

    move-object v7, v2

    move-object v8, v3

    move-object v9, v4

    invoke-super {v5, v6, v7, v8, v9}, Landroid/graphics/drawable/Drawable;->inflate(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    move-object v5, v0

    iget-object v5, v5, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    move-object v6, v1

    move-object v7, v3

    invoke-virtual {v5, v6, v7}, Lcom/particle/f;->a(Landroid/content/res/Resources;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public invalidate()V
    .registers 3

    move-object v0, p0

    move-object v1, v0

    invoke-virtual {v1}, Lcom/particle/ParticlesDrawable;->invalidateSelf()V

    return-void
.end method

.method public isRunning()Z
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->d()Z

    move-result v1

    move v0, v1

    return v0
.end method

.method public makeBrandNewFrame()V
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->makeBrandNewFrame()V

    return-void
.end method

.method public makeBrandNewFrameWithPointsOffscreen()V
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->makeBrandNewFrameWithPointsOffscreen()V

    return-void
.end method

.method public nextFrame()V
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->nextFrame()V

    return-void
.end method

.method public scheduleNextFrame(J)V
    .registers 12

    move-object v0, p0

    move-wide v1, p1

    move-object v3, v0

    move-object v4, v0

    iget-object v4, v4, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    move-wide v7, v1

    add-long/2addr v5, v7

    invoke-virtual {v3, v4, v5, v6}, Lcom/particle/ParticlesDrawable;->scheduleSelf(Ljava/lang/Runnable;J)V

    return-void
.end method

.method public setAlpha(I)V
    .registers 6

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->a(I)V

    return-void
.end method

.method public setBounds(IIII)V
    .registers 15

    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, v0

    move v6, v1

    move v7, v2

    move v8, v3

    move v9, v4

    invoke-super {v5, v6, v7, v8, v9}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    move-object v5, v0

    iget-object v5, v5, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    move v6, v1

    move v7, v2

    move v8, v3

    move v9, v4

    invoke-virtual {v5, v6, v7, v8, v9}, Lcom/particle/f;->a(IIII)V

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mCanvasParticlesView:Lcom/particle/a;

    move-object v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/a;->a(Landroid/graphics/ColorFilter;)V

    return-void
.end method

.method public setDotColor(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setDotColor(I)V

    return-void
.end method

.method public setDotRadiusRange(FF)V
    .registers 9
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.5
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.5
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v3, v0

    iget-object v3, v3, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    move v4, v1

    move v5, v2

    invoke-virtual {v3, v4, v5}, Lcom/particle/f;->setDotRadiusRange(FF)V

    return-void
.end method

.method public setFrameDelay(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/IntRange;
            from = 0x0L
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setFrameDelay(I)V

    return-void
.end method

.method public setLineColor(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setLineColor(I)V

    return-void
.end method

.method public setLineDistance(F)V
    .registers 6
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setLineDistance(F)V

    return-void
.end method

.method public setLineThickness(F)V
    .registers 6
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 1.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setLineThickness(F)V

    return-void
.end method

.method public setNumDots(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/IntRange;
            from = 0x0L
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setNumDots(I)V

    return-void
.end method

.method public setStepMultiplier(F)V
    .registers 6
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setStepMultiplier(F)V

    return-void
.end method

.method public start()V
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->b()V

    return-void
.end method

.method public stop()V
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->c()V

    return-void
.end method

.method public unscheduleNextFrame()V
    .registers 4

    move-object v0, p0

    move-object v1, v0

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesDrawable;->mController:Lcom/particle/f;

    invoke-virtual {v1, v2}, Lcom/particle/ParticlesDrawable;->unscheduleSelf(Ljava/lang/Runnable;)V

    return-void
.end method
