.class final Lcom/particle/e;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/particle/ParticlesSceneConfiguration;


# instance fields
.field private final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Lcom/particle/d;",
            ">;"
        }
    .end annotation
.end field

.field private b:F

.field private c:F

.field private d:F

.field private e:F

.field private f:I

.field private g:I
    .annotation build Landroid/support/annotation/ColorInt;
    .end annotation
.end field

.field private h:I
    .annotation build Landroid/support/annotation/ColorInt;
    .end annotation
.end field

.field private i:I

.field private j:F

.field private k:I

.field private l:I
    .annotation build Landroid/support/annotation/ColorInt;
    .end annotation
.end field

.field private m:I

.field private n:I


# direct methods
.method constructor <init>()V
    .registers 7

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    move-object v1, v0

    new-instance v2, Ljava/util/ArrayList;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const/16 v4, 0x3c

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    iput-object v2, v1, Lcom/particle/e;->a:Ljava/util/List;

    move-object v1, v0

    sget v2, Lcom/particle/b;->b:F

    iput v2, v1, Lcom/particle/e;->b:F

    move-object v1, v0

    sget v2, Lcom/particle/b;->a:F

    iput v2, v1, Lcom/particle/e;->c:F

    move-object v1, v0

    sget v2, Lcom/particle/b;->c:F

    iput v2, v1, Lcom/particle/e;->d:F

    move-object v1, v0

    sget v2, Lcom/particle/b;->d:F

    iput v2, v1, Lcom/particle/e;->e:F

    move-object v1, v0

    const/16 v2, 0x3c

    iput v2, v1, Lcom/particle/e;->f:I

    move-object v1, v0

    const/4 v2, -0x1

    iput v2, v1, Lcom/particle/e;->g:I

    move-object v1, v0

    const/4 v2, -0x1

    iput v2, v1, Lcom/particle/e;->h:I

    move-object v1, v0

    const/16 v2, 0xa

    iput v2, v1, Lcom/particle/e;->i:I

    move-object v1, v0

    const/high16 v2, 0x3f800000    # 1.0f

    iput v2, v1, Lcom/particle/e;->j:F

    move-object v1, v0

    const/16 v2, 0xff

    iput v2, v1, Lcom/particle/e;->k:I

    move-object v1, v0

    move-object v2, v0

    iget v2, v2, Lcom/particle/e;->g:I

    move-object v3, v0

    iget v3, v3, Lcom/particle/e;->k:I

    invoke-static {v2, v3}, Lcom/particle/e;->a(II)I

    move-result v2

    iput v2, v1, Lcom/particle/e;->l:I

    return-void
.end method

.method static a(II)I
    .registers 8
    .param p0    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param
    .annotation build Landroid/support/annotation/VisibleForTesting;
    .end annotation

    move v0, p0

    move v1, p1

    move v3, v0

    invoke-static {v3}, Landroid/graphics/Color;->alpha(I)I

    move-result v3

    move v4, v1

    mul-int/2addr v3, v4

    const/16 v4, 0xff

    div-int/lit16 v3, v3, 0xff

    move v2, v3

    move v3, v0

    const v4, -0x10000

    and-int/2addr v3, v4

    move v4, v2

    const/16 v5, 0x18

    shl-int/lit8 v4, v4, 0x18

    or-int/2addr v3, v4

    move v0, v3

    return v0
.end method


# virtual methods
.method a()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List",
            "<",
            "Lcom/particle/d;",
            ">;"
        }
    .end annotation

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/e;->a:Ljava/util/List;

    move-object v0, v1

    return-object v0
.end method

.method a(I)V
    .registers 6

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/particle/e;->m:I

    return-void
.end method

.method a(Lcom/particle/d;)V
    .registers 6
    .param p1    # Lcom/particle/d;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/e;->a:Ljava/util/List;

    move-object v3, v1

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v2

    return-void
.end method

.method b()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->m:I

    move v0, v1

    return v0
.end method

.method b(I)V
    .registers 6

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/particle/e;->n:I

    return-void
.end method

.method c()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->n:I

    move v0, v1

    return v0
.end method

.method c(I)V
    .registers 7

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/particle/e;->k:I

    move-object v2, v0

    move-object v3, v0

    iget v3, v3, Lcom/particle/e;->g:I

    move v4, v1

    invoke-static {v3, v4}, Lcom/particle/e;->a(II)I

    move-result v3

    iput v3, v2, Lcom/particle/e;->l:I

    return-void
.end method

.method d()V
    .registers 4

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/e;->a:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_12

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/e;->a:Ljava/util/List;

    const/4 v2, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v1

    :cond_12
    return-void
.end method

.method e()V
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/e;->a:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    return-void
.end method

.method f()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->k:I

    move v0, v1

    return v0
.end method

.method g()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->l:I

    move v0, v1

    return v0
.end method

.method public getDotColor()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->g:I

    move v0, v1

    return v0
.end method

.method public getFrameDelay()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->i:I

    move v0, v1

    return v0
.end method

.method public getLineColor()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->h:I

    move v0, v1

    return v0
.end method

.method public getLineDistance()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->e:F

    move v0, v1

    return v0
.end method

.method public getLineThickness()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->d:F

    move v0, v1

    return v0
.end method

.method public getMaxDotRadius()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->c:F

    move v0, v1

    return v0
.end method

.method public getMinDotRadius()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->b:F

    move v0, v1

    return v0
.end method

.method public getNumDots()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->f:I

    move v0, v1

    return v0
.end method

.method public getStepMultiplier()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget v1, v1, Lcom/particle/e;->j:F

    move v0, v1

    return v0
.end method

.method public setDotColor(I)V
    .registers 7
    .param p1    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/particle/e;->g:I

    move-object v2, v0

    move v3, v1

    move-object v4, v0

    iget v4, v4, Lcom/particle/e;->k:I

    invoke-static {v3, v4}, Lcom/particle/e;->a(II)I

    move-result v3

    iput v3, v2, Lcom/particle/e;->l:I

    return-void
.end method

.method public setDotRadiusRange(FF)V
    .registers 15
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.5
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.5
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, v1

    const/high16 v4, 0x3f000000    # 0.5f

    cmpg-float v3, v3, v4

    if-ltz v3, :cond_11

    move v3, v2

    const/high16 v4, 0x3f000000    # 0.5f

    cmpg-float v3, v3, v4

    if-gez v3, :cond_1c

    :cond_11
    new-instance v3, Ljava/lang/IllegalArgumentException;

    move-object v11, v3

    move-object v3, v11

    move-object v4, v11

    const-string v5, "Dot radius must not be less than 0.5"

    invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v3

    :cond_1c
    move v3, v1

    const/high16 v4, 0x7fc00000    # Float.NaN

    invoke-static {v3, v4}, Ljava/lang/Float;->compare(FF)I

    move-result v3

    if-eqz v3, :cond_2e

    move v3, v2

    const/high16 v4, 0x7fc00000    # Float.NaN

    invoke-static {v3, v4}, Ljava/lang/Float;->compare(FF)I

    move-result v3

    if-nez v3, :cond_39

    :cond_2e
    new-instance v3, Ljava/lang/IllegalArgumentException;

    move-object v11, v3

    move-object v3, v11

    move-object v4, v11

    const-string v5, "Dot radius must be a valid float"

    invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v3

    :cond_39
    move v3, v1

    move v4, v2

    cmpl-float v3, v3, v4

    if-lez v3, :cond_69

    new-instance v3, Ljava/lang/IllegalArgumentException;

    move-object v11, v3

    move-object v3, v11

    move-object v4, v11

    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v6, "Min radius must not be greater than max, but min = %f, max = %f"

    const/4 v7, 0x2

    new-array v7, v7, [Ljava/lang/Object;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    const/4 v9, 0x0

    move v10, v1

    invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v10

    aput-object v10, v8, v9

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    const/4 v9, 0x1

    move v10, v2

    invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v10

    aput-object v10, v8, v9

    invoke-static {v5, v6, v7}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v3

    :cond_69
    move-object v3, v0

    move v4, v1

    iput v4, v3, Lcom/particle/e;->b:F

    move-object v3, v0

    move v4, v2

    iput v4, v3, Lcom/particle/e;->c:F

    return-void
.end method

.method public setFrameDelay(I)V
    .registers 8
    .param p1    # I
        .annotation build Landroid/support/annotation/IntRange;
            from = 0x0L
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, v1

    if-gez v2, :cond_10

    new-instance v2, Ljava/lang/IllegalArgumentException;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "delay must not be nagative"

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_10
    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/particle/e;->i:I

    return-void
.end method

.method public setLineColor(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/particle/e;->h:I

    return-void
.end method

.method public setLineDistance(F)V
    .registers 8
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, v1

    const/4 v3, 0x0

    cmpg-float v2, v2, v3

    if-gez v2, :cond_13

    new-instance v2, Ljava/lang/IllegalArgumentException;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "line distance must not be negative"

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_13
    move v2, v1

    const/high16 v3, 0x7fc00000    # Float.NaN

    invoke-static {v2, v3}, Ljava/lang/Float;->compare(FF)I

    move-result v2

    if-nez v2, :cond_27

    new-instance v2, Ljava/lang/IllegalArgumentException;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "line distance must be a valid float"

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_27
    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/particle/e;->e:F

    return-void
.end method

.method public setLineThickness(F)V
    .registers 8
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 1.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, v1

    const/high16 v3, 0x3f800000    # 1.0f

    cmpg-float v2, v2, v3

    if-gez v2, :cond_14

    new-instance v2, Ljava/lang/IllegalArgumentException;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "Line thickness must not be less than 1"

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_14
    move v2, v1

    const/high16 v3, 0x7fc00000    # Float.NaN

    invoke-static {v2, v3}, Ljava/lang/Float;->compare(FF)I

    move-result v2

    if-nez v2, :cond_28

    new-instance v2, Ljava/lang/IllegalArgumentException;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "line thickness must be a valid float"

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_28
    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/particle/e;->d:F

    return-void
.end method

.method public setNumDots(I)V
    .registers 8
    .param p1    # I
        .annotation build Landroid/support/annotation/IntRange;
            from = 0x0L
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, v1

    if-gez v2, :cond_10

    new-instance v2, Ljava/lang/IllegalArgumentException;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "numPoints must not be negative"

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_10
    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/particle/e;->f:I

    return-void
.end method

.method public setStepMultiplier(F)V
    .registers 8
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, v1

    const/4 v3, 0x0

    cmpg-float v2, v2, v3

    if-gez v2, :cond_13

    new-instance v2, Ljava/lang/IllegalArgumentException;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "step multiplier must not be nagative"

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_13
    move v2, v1

    const/high16 v3, 0x7fc00000    # Float.NaN

    invoke-static {v2, v3}, Ljava/lang/Float;->compare(FF)I

    move-result v2

    if-nez v2, :cond_27

    new-instance v2, Ljava/lang/IllegalArgumentException;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "step multiplier must be a valid float"

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_27
    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/particle/e;->j:F

    return-void
.end method
