.class public interface abstract Lcom/particle/ParticlesSceneConfiguration;
.super Ljava/lang/Object;


# annotations
.annotation build Landroid/support/annotation/Keep;
.end annotation


# virtual methods
.method public abstract getDotColor()I
    .annotation build Landroid/support/annotation/ColorInt;
    .end annotation
.end method

.method public abstract getFrameDelay()I
.end method

.method public abstract getLineColor()I
    .annotation build Landroid/support/annotation/ColorInt;
    .end annotation
.end method

.method public abstract getLineDistance()F
.end method

.method public abstract getLineThickness()F
.end method

.method public abstract getMaxDotRadius()F
.end method

.method public abstract getMinDotRadius()F
.end method

.method public abstract getNumDots()I
.end method

.method public abstract getStepMultiplier()F
.end method

.method public abstract setDotColor(I)V
    .param p1    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param
.end method

.method public abstract setDotRadiusRange(FF)V
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.5
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.5
        .end annotation
    .end param
.end method

.method public abstract setFrameDelay(I)V
    .param p1    # I
        .annotation build Landroid/support/annotation/IntRange;
            from = 0x0L
        .end annotation
    .end param
.end method

.method public abstract setLineColor(I)V
    .param p1    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param
.end method

.method public abstract setLineDistance(F)V
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.0
        .end annotation
    .end param
.end method

.method public abstract setLineThickness(F)V
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 1.0
        .end annotation
    .end param
.end method

.method public abstract setNumDots(I)V
    .param p1    # I
        .annotation build Landroid/support/annotation/IntRange;
            from = 0x0L
        .end annotation
    .end param
.end method

.method public abstract setStepMultiplier(F)V
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.0
        .end annotation
    .end param
.end method
