.class public interface abstract Lcom/particle/ParticlesScene;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/particle/ParticlesSceneConfiguration;


# annotations
.annotation build Landroid/support/annotation/Keep;
.end annotation


# virtual methods
.method public abstract makeBrandNewFrame()V
.end method

.method public abstract makeBrandNewFrameWithPointsOffscreen()V
.end method

.method public abstract nextFrame()V
.end method
