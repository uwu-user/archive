.class public final Lcom/particle/R$styleable;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/particle/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "styleable"
.end annotation


# static fields
.field public static final ParticlesView:[I

.field public static final ParticlesView_particle_app_dotColor:I = 0x5

.field public static final ParticlesView_particle_app_frameDelayMillis:I = 0x7

.field public static final ParticlesView_particle_app_lineColor:I = 0x6

.field public static final ParticlesView_particle_app_lineDistance:I = 0x3

.field public static final ParticlesView_particle_app_lineThickness:I = 0x2

.field public static final ParticlesView_particle_app_maxDotRadius:I = 0x1

.field public static final ParticlesView_particle_app_minDotRadius:I = 0x0

.field public static final ParticlesView_particle_app_numDots:I = 0x4

.field public static final ParticlesView_particle_app_stepMultiplier:I = 0x8


# direct methods
.method static final constructor <clinit>()V
    .registers 3

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_a

    sput-object v2, Lcom/particle/R$styleable;->ParticlesView:[I

    return-void

    :array_a
    .array-data 4
        0x7f010000
        0x7f010001
        0x7f010002
        0x7f010003
        0x7f010004
        0x7f010005
        0x7f010006
        0x7f010007
        0x7f010008
    .end array-data
.end method

.method public constructor <init>()V
    .registers 4

    .prologue
    .line 276
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
