.class interface abstract Lcom/particle/g;
.super Ljava/lang/Object;


# virtual methods
.method public abstract invalidate()V
.end method

.method public abstract scheduleNextFrame(J)V
.end method

.method public abstract unscheduleNextFrame()V
.end method
