.class final Lcom/particle/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/particle/c;


# instance fields
.field private final a:Landroid/graphics/Paint;

.field private b:Landroid/graphics/Canvas;
    .annotation build Landroid/support/annotation/Nullable;
    .end annotation
.end field


# direct methods
.method constructor <init>()V
    .registers 7

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    move-object v1, v0

    new-instance v2, Landroid/graphics/Paint;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const/4 v4, 0x5

    invoke-direct {v3, v4}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v2, v1, Lcom/particle/a;->a:Landroid/graphics/Paint;

    return-void
.end method


# virtual methods
.method a()Landroid/graphics/Paint;
    .registers 3
    .annotation build Landroid/support/annotation/NonNull;
    .end annotation

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/a;->a:Landroid/graphics/Paint;

    move-object v0, v1

    return-object v0
.end method

.method a(Landroid/graphics/Canvas;)V
    .registers 6
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroid/support/annotation/Nullable;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    move-object v3, v1

    iput-object v3, v2, Lcom/particle/a;->b:Landroid/graphics/Canvas;

    return-void
.end method

.method a(Landroid/graphics/ColorFilter;)V
    .registers 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/a;->a:Landroid/graphics/Paint;

    move-object v3, v1

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    move-result-object v2

    return-void
.end method

.method public drawLine(FFFFFI)V
    .registers 21
    .param p6    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move-object v7, v0

    iget-object v7, v7, Lcom/particle/a;->b:Landroid/graphics/Canvas;

    if-nez v7, :cond_1c

    new-instance v7, Ljava/lang/IllegalStateException;

    move-object v13, v7

    move-object v7, v13

    move-object v8, v13

    const-string v9, "Called in wrong state"

    invoke-direct {v8, v9}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v7

    :cond_1c
    move-object v7, v0

    iget-object v7, v7, Lcom/particle/a;->a:Landroid/graphics/Paint;

    move v8, v5

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    move-object v7, v0

    iget-object v7, v7, Lcom/particle/a;->a:Landroid/graphics/Paint;

    move v8, v6

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    move-object v7, v0

    iget-object v7, v7, Lcom/particle/a;->b:Landroid/graphics/Canvas;

    move v8, v1

    move v9, v2

    move v10, v3

    move v11, v4

    move-object v12, v0

    iget-object v12, v12, Lcom/particle/a;->a:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method public fillCircle(FFFI)V
    .registers 16
    .param p4    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, v0

    iget-object v5, v5, Lcom/particle/a;->b:Landroid/graphics/Canvas;

    if-nez v5, :cond_15

    new-instance v5, Ljava/lang/IllegalStateException;

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    const-string v7, "Called in wrong state"

    invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v5

    :cond_15
    move-object v5, v0

    iget-object v5, v5, Lcom/particle/a;->a:Landroid/graphics/Paint;

    move v6, v4

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    move-object v5, v0

    iget-object v5, v5, Lcom/particle/a;->b:Landroid/graphics/Canvas;

    move v6, v1

    move v7, v2

    move v8, v3

    move-object v9, v0

    iget-object v9, v9, Lcom/particle/a;->a:Landroid/graphics/Paint;

    invoke-virtual {v5, v6, v7, v8, v9}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    return-void
.end method
