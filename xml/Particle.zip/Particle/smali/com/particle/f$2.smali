.class Lcom/particle/f$2;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/particle/f$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/particle/f;->l()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/particle/f;


# direct methods
.method constructor <init>(Lcom/particle/f;)V
    .registers 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    move-object v3, v1

    iput-object v3, v2, Lcom/particle/f$2;->a:Lcom/particle/f;

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)Lcom/particle/d;
    .registers 6

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/f$2;->a:Lcom/particle/f;

    const/4 v3, 0x0

    invoke-static {v2, v3}, Lcom/particle/f;->a(Lcom/particle/f;Z)Lcom/particle/d;

    move-result-object v2

    move-object v0, v2

    return-object v0
.end method
