.class public final Lcom/particle/R$drawable;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/particle/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "drawable"
.end annotation


# static fields
.field public static final ic_launcher:I = 0x7f020000

.field public static final particle:I = 0x7f020001


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 97
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
