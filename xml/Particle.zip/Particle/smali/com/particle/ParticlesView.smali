.class public Lcom/particle/ParticlesView;
.super Landroid/view/View;

# interfaces
.implements Lcom/particle/ParticlesScene;
.implements Lcom/particle/c;
.implements Lcom/particle/g;


# annotations
.annotation build Landroid/support/annotation/Keep;
.end annotation


# instance fields
.field private mAttachedToWindow:Z

.field private final mCanvasParticlesView:Lcom/particle/a;

.field private final mController:Lcom/particle/f;

.field private mEmulateOnAttachToWindow:Z

.field mExplicitlyStopped:Z
    .annotation build Landroid/support/annotation/VisibleForTesting;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 10

    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    move-object v3, v1

    invoke-direct {v2, v3}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v2, v0

    new-instance v3, Lcom/particle/f;

    move-object v7, v3

    move-object v3, v7

    move-object v4, v7

    move-object v5, v0

    move-object v6, v0

    invoke-direct {v4, v5, v6}, Lcom/particle/f;-><init>(Lcom/particle/c;Lcom/particle/g;)V

    iput-object v3, v2, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move-object v2, v0

    new-instance v3, Lcom/particle/a;

    move-object v7, v3

    move-object v3, v7

    move-object v4, v7

    invoke-direct {v4}, Lcom/particle/a;-><init>()V

    iput-object v3, v2, Lcom/particle/ParticlesView;->mCanvasParticlesView:Lcom/particle/a;

    move-object v2, v0

    move-object v3, v1

    const/4 v4, 0x0

    invoke-direct {v2, v3, v4}, Lcom/particle/ParticlesView;->init(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 12

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, v0

    move-object v4, v1

    move-object v5, v2

    invoke-direct {v3, v4, v5}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    move-object v3, v0

    new-instance v4, Lcom/particle/f;

    move-object v8, v4

    move-object v4, v8

    move-object v5, v8

    move-object v6, v0

    move-object v7, v0

    invoke-direct {v5, v6, v7}, Lcom/particle/f;-><init>(Lcom/particle/c;Lcom/particle/g;)V

    iput-object v4, v3, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move-object v3, v0

    new-instance v4, Lcom/particle/a;

    move-object v8, v4

    move-object v4, v8

    move-object v5, v8

    invoke-direct {v5}, Lcom/particle/a;-><init>()V

    iput-object v4, v3, Lcom/particle/ParticlesView;->mCanvasParticlesView:Lcom/particle/a;

    move-object v3, v0

    move-object v4, v1

    move-object v5, v2

    invoke-direct {v3, v4, v5}, Lcom/particle/ParticlesView;->init(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 14

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v4, v0

    move-object v5, v1

    move-object v6, v2

    move v7, v3

    invoke-direct {v4, v5, v6, v7}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    move-object v4, v0

    new-instance v5, Lcom/particle/f;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    move-object v7, v0

    move-object v8, v0

    invoke-direct {v6, v7, v8}, Lcom/particle/f;-><init>(Lcom/particle/c;Lcom/particle/g;)V

    iput-object v5, v4, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move-object v4, v0

    new-instance v5, Lcom/particle/a;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    invoke-direct {v6}, Lcom/particle/a;-><init>()V

    iput-object v5, v4, Lcom/particle/ParticlesView;->mCanvasParticlesView:Lcom/particle/a;

    move-object v4, v0

    move-object v5, v1

    move-object v6, v2

    invoke-direct {v4, v5, v6}, Lcom/particle/ParticlesView;->init(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .registers 16
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move-object v5, v0

    move-object v6, v1

    move-object v7, v2

    move v8, v3

    move v9, v4

    invoke-direct {v5, v6, v7, v8, v9}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    move-object v5, v0

    new-instance v6, Lcom/particle/f;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move-object v8, v0

    move-object v9, v0

    invoke-direct {v7, v8, v9}, Lcom/particle/f;-><init>(Lcom/particle/c;Lcom/particle/g;)V

    iput-object v6, v5, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move-object v5, v0

    new-instance v6, Lcom/particle/a;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Lcom/particle/a;-><init>()V

    iput-object v6, v5, Lcom/particle/ParticlesView;->mCanvasParticlesView:Lcom/particle/a;

    move-object v5, v0

    move-object v6, v1

    move-object v7, v2

    invoke-direct {v5, v6, v7}, Lcom/particle/ParticlesView;->init(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method private init(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 11
    .param p1    # Landroid/content/Context;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroid/support/annotation/Nullable;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v6, 0xb

    if-lt v5, v6, :cond_15

    move-object v5, v0

    const/4 v6, 0x2

    move-object v7, v0

    iget-object v7, v7, Lcom/particle/ParticlesView;->mCanvasParticlesView:Lcom/particle/a;

    invoke-virtual {v7}, Lcom/particle/a;->a()Landroid/graphics/Paint;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, Lcom/particle/ParticlesView;->setLayerType(ILandroid/graphics/Paint;)V

    :cond_15
    move-object v5, v2

    if-eqz v5, :cond_2c

    move-object v5, v1

    move-object v6, v2

    sget-object v7, Lcom/particle/R$styleable;->ParticlesView:[I

    invoke-virtual {v5, v6, v7}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v5

    move-object v3, v5

    move-object v5, v0

    :try_start_22
    iget-object v5, v5, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move-object v6, v3

    invoke-virtual {v5, v6}, Lcom/particle/f;->a(Landroid/content/res/TypedArray;)V
    :try_end_28
    .catchall {:try_start_22 .. :try_end_28} :catchall_2d

    move-object v5, v3

    invoke-virtual {v5}, Landroid/content/res/TypedArray;->recycle()V

    :cond_2c
    return-void

    :catchall_2d
    move-exception v5

    move-object v4, v5

    move-object v5, v3

    invoke-virtual {v5}, Landroid/content/res/TypedArray;->recycle()V

    move-object v5, v4

    throw v5
.end method

.method private isAttachedToWindowCompat()Z
    .registers 4

    move-object v0, p0

    move-object v1, v0

    iget-boolean v1, v1, Lcom/particle/ParticlesView;->mEmulateOnAttachToWindow:Z

    if-eqz v1, :cond_b

    move-object v1, v0

    iget-boolean v1, v1, Lcom/particle/ParticlesView;->mAttachedToWindow:Z

    move v0, v1

    :goto_a
    return v0

    :cond_b
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x13

    if-lt v1, v2, :cond_18

    move-object v1, v0

    invoke-virtual {v1}, Lcom/particle/ParticlesView;->isAttachedToWindow()Z

    move-result v1

    move v0, v1

    goto :goto_a

    :cond_18
    move-object v1, v0

    iget-boolean v1, v1, Lcom/particle/ParticlesView;->mAttachedToWindow:Z

    move v0, v1

    goto :goto_a
.end method

.method private isVisibleWithAllParents(Landroid/view/View;)Z
    .registers 7
    .param p1    # Landroid/view/View;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v3, v1

    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v3

    if-eqz v3, :cond_c

    const/4 v3, 0x0

    move v0, v3

    :goto_b
    return v0

    :cond_c
    move-object v3, v1

    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    move-object v2, v3

    move-object v3, v2

    instance-of v3, v3, Landroid/view/View;

    if-eqz v3, :cond_21

    move-object v3, v0

    move-object v4, v2

    check-cast v4, Landroid/view/View;

    invoke-direct {v3, v4}, Lcom/particle/ParticlesView;->isVisibleWithAllParents(Landroid/view/View;)Z

    move-result v3

    move v0, v3

    goto :goto_b

    :cond_21
    const/4 v3, 0x1

    move v0, v3

    goto :goto_b
.end method


# virtual methods
.method public drawLine(FFFFFI)V
    .registers 21
    .param p6    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move-object v7, v0

    iget-object v7, v7, Lcom/particle/ParticlesView;->mCanvasParticlesView:Lcom/particle/a;

    move v8, v1

    move v9, v2

    move v10, v3

    move v11, v4

    move v12, v5

    move v13, v6

    invoke-virtual/range {v7 .. v13}, Lcom/particle/a;->drawLine(FFFFFI)V

    return-void
.end method

.method public fillCircle(FFFI)V
    .registers 15
    .param p4    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, v0

    iget-object v5, v5, Lcom/particle/ParticlesView;->mCanvasParticlesView:Lcom/particle/a;

    move v6, v1

    move v7, v2

    move v8, v3

    move v9, v4

    invoke-virtual {v5, v6, v7, v8, v9}, Lcom/particle/a;->fillCircle(FFFI)V

    return-void
.end method

.method public getDotColor()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getDotColor()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getFrameDelay()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getFrameDelay()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getLineColor()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getLineColor()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getLineDistance()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getLineDistance()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getLineThickness()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getLineThickness()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getMaxDotRadius()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getMaxDotRadius()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getMinDotRadius()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getMinDotRadius()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getNumDots()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getNumDots()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getPaint()Landroid/graphics/Paint;
    .registers 3
    .annotation build Landroid/support/annotation/Keep;
    .end annotation

    .annotation build Landroid/support/annotation/NonNull;
    .end annotation

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mCanvasParticlesView:Lcom/particle/a;

    invoke-virtual {v1}, Lcom/particle/a;->a()Landroid/graphics/Paint;

    move-result-object v1

    move-object v0, v1

    return-object v0
.end method

.method public getStepMultiplier()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->getStepMultiplier()F

    move-result v1

    move v0, v1

    return v0
.end method

.method isRunning()Z
    .registers 3
    .annotation build Landroid/support/annotation/VisibleForTesting;
    .end annotation

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->d()Z

    move-result v1

    move v0, v1

    return v0
.end method

.method public makeBrandNewFrame()V
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->makeBrandNewFrame()V

    return-void
.end method

.method public makeBrandNewFrameWithPointsOffscreen()V
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->makeBrandNewFrameWithPointsOffscreen()V

    return-void
.end method

.method public nextFrame()V
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->nextFrame()V

    return-void
.end method

.method protected onAttachedToWindow()V
    .registers 4

    move-object v0, p0

    move-object v1, v0

    invoke-super {v1}, Landroid/view/View;->onAttachedToWindow()V

    move-object v1, v0

    const/4 v2, 0x1

    iput-boolean v2, v1, Lcom/particle/ParticlesView;->mAttachedToWindow:Z

    move-object v1, v0

    invoke-virtual {v1}, Lcom/particle/ParticlesView;->startInternal()V

    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 4

    move-object v0, p0

    move-object v1, v0

    invoke-super {v1}, Landroid/view/View;->onDetachedFromWindow()V

    move-object v1, v0

    const/4 v2, 0x0

    iput-boolean v2, v1, Lcom/particle/ParticlesView;->mAttachedToWindow:Z

    move-object v1, v0

    invoke-virtual {v1}, Lcom/particle/ParticlesView;->stopInternal()V

    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    move-object v3, v1

    invoke-super {v2, v3}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesView;->mCanvasParticlesView:Lcom/particle/a;

    move-object v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/a;->a(Landroid/graphics/Canvas;)V

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v2}, Lcom/particle/f;->e()V

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v2}, Lcom/particle/f;->run()V

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesView;->mCanvasParticlesView:Lcom/particle/a;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Lcom/particle/a;->a(Landroid/graphics/Canvas;)V

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .registers 15

    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, v0

    move v6, v1

    move v7, v2

    move v8, v3

    move v9, v4

    invoke-super {v5, v6, v7, v8, v9}, Landroid/view/View;->onSizeChanged(IIII)V

    move-object v5, v0

    iget-object v5, v5, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    const/4 v6, 0x0

    const/4 v7, 0x0

    move v8, v1

    move v9, v2

    invoke-virtual {v5, v6, v7, v8, v9}, Lcom/particle/f;->a(IIII)V

    return-void
.end method

.method protected onVisibilityChanged(Landroid/view/View;I)V
    .registers 9
    .param p1    # Landroid/view/View;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v3, v0

    move-object v4, v1

    move v5, v2

    invoke-super {v3, v4, v5}, Landroid/view/View;->onVisibilityChanged(Landroid/view/View;I)V

    move v3, v2

    if-eqz v3, :cond_11

    move-object v3, v0

    invoke-virtual {v3}, Lcom/particle/ParticlesView;->stopInternal()V

    :goto_10
    return-void

    :cond_11
    move-object v3, v0

    invoke-virtual {v3}, Lcom/particle/ParticlesView;->startInternal()V

    goto :goto_10
.end method

.method public scheduleNextFrame(J)V
    .registers 9

    move-object v0, p0

    move-wide v1, p1

    move-object v3, v0

    move-wide v4, v1

    invoke-virtual {v3, v4, v5}, Lcom/particle/ParticlesView;->postInvalidateDelayed(J)V

    return-void
.end method

.method public setDotColor(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setDotColor(I)V

    return-void
.end method

.method public setDotRadiusRange(FF)V
    .registers 9
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.5
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.5
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v3, v0

    iget-object v3, v3, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move v4, v1

    move v5, v2

    invoke-virtual {v3, v4, v5}, Lcom/particle/f;->setDotRadiusRange(FF)V

    return-void
.end method

.method setEmulateOnAttachToWindow(Z)V
    .registers 6
    .annotation build Landroid/support/annotation/VisibleForTesting;
        otherwise = 0x5
    .end annotation

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    move v3, v1

    iput-boolean v3, v2, Lcom/particle/ParticlesView;->mEmulateOnAttachToWindow:Z

    return-void
.end method

.method public setFrameDelay(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/IntRange;
            from = 0x0L
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setFrameDelay(I)V

    return-void
.end method

.method public setLineColor(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setLineColor(I)V

    return-void
.end method

.method public setLineDistance(F)V
    .registers 6
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setLineDistance(F)V

    return-void
.end method

.method public setLineThickness(F)V
    .registers 6
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 1.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setLineThickness(F)V

    return-void
.end method

.method public setNumDots(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/IntRange;
            from = 0x0L
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setNumDots(I)V

    return-void
.end method

.method public setStepMultiplier(F)V
    .registers 6
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/f;->setStepMultiplier(F)V

    return-void
.end method

.method public start()V
    .registers 4
    .annotation build Landroid/support/annotation/Keep;
    .end annotation

    move-object v0, p0

    move-object v1, v0

    const/4 v2, 0x0

    iput-boolean v2, v1, Lcom/particle/ParticlesView;->mExplicitlyStopped:Z

    move-object v1, v0

    invoke-virtual {v1}, Lcom/particle/ParticlesView;->startInternal()V

    return-void
.end method

.method startInternal()V
    .registers 4
    .annotation build Landroid/support/annotation/VisibleForTesting;
    .end annotation

    move-object v0, p0

    move-object v1, v0

    iget-boolean v1, v1, Lcom/particle/ParticlesView;->mExplicitlyStopped:Z

    if-nez v1, :cond_1b

    move-object v1, v0

    move-object v2, v0

    invoke-direct {v1, v2}, Lcom/particle/ParticlesView;->isVisibleWithAllParents(Landroid/view/View;)Z

    move-result v1

    if-eqz v1, :cond_1b

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/ParticlesView;->isAttachedToWindowCompat()Z

    move-result v1

    if-eqz v1, :cond_1b

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->b()V

    :cond_1b
    return-void
.end method

.method public stop()V
    .registers 4
    .annotation build Landroid/support/annotation/Keep;
    .end annotation

    move-object v0, p0

    move-object v1, v0

    const/4 v2, 0x1

    iput-boolean v2, v1, Lcom/particle/ParticlesView;->mExplicitlyStopped:Z

    move-object v1, v0

    invoke-virtual {v1}, Lcom/particle/ParticlesView;->stopInternal()V

    return-void
.end method

.method stopInternal()V
    .registers 3
    .annotation build Landroid/support/annotation/VisibleForTesting;
    .end annotation

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/ParticlesView;->mController:Lcom/particle/f;

    invoke-virtual {v1}, Lcom/particle/f;->c()V

    return-void
.end method

.method public unscheduleNextFrame()V
    .registers 1

    return-void
.end method
