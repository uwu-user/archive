.class public final Lcom/particle/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/particle/R$attr;,
        Lcom/particle/R$drawable;,
        Lcom/particle/R$layout;,
        Lcom/particle/R$string;,
        Lcom/particle/R$style;,
        Lcom/particle/R$styleable;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 277
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
