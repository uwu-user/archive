.class interface abstract Lcom/particle/c;
.super Ljava/lang/Object;


# virtual methods
.method public abstract drawLine(FFFFFI)V
    .param p6    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param
.end method

.method public abstract fillCircle(FFFI)V
    .param p4    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param
.end method
