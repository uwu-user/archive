.class public final Lcom/particle/R$attr;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/particle/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "attr"
.end annotation


# static fields
.field public static final particle_app_dotColor:I = 0x7f010005

.field public static final particle_app_frameDelayMillis:I = 0x7f010007

.field public static final particle_app_lineColor:I = 0x7f010006

.field public static final particle_app_lineDistance:I = 0x7f010003

.field public static final particle_app_lineThickness:I = 0x7f010002

.field public static final particle_app_maxDotRadius:I = 0x7f010001

.field public static final particle_app_minDotRadius:I = 0x7f010000

.field public static final particle_app_numDots:I = 0x7f010004

.field public static final particle_app_stepMultiplier:I = 0x7f010008


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 93
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
