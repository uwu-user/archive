.class final Lcom/particle/f;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/particle/ParticlesScene;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/particle/f$a;
    }
.end annotation


# static fields
.field private static final a:F


# instance fields
.field private final b:Lcom/particle/e;

.field private final c:Ljava/util/Random;

.field private d:Z

.field private e:J

.field private f:J

.field private g:Z

.field private final h:Lcom/particle/c;

.field private final i:Lcom/particle/g;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x1

    const/high16 v1, 0x41900000    # 18.0f

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    invoke-static {v0, v1, v2}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    sput v0, Lcom/particle/f;->a:F

    return-void
.end method

.method constructor <init>(Lcom/particle/c;Lcom/particle/g;)V
    .registers 10
    .param p1    # Lcom/particle/c;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Lcom/particle/g;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    new-instance v4, Lcom/particle/e;

    move-object v6, v4

    move-object v4, v6

    move-object v5, v6

    invoke-direct {v5}, Lcom/particle/e;-><init>()V

    iput-object v4, v3, Lcom/particle/f;->b:Lcom/particle/e;

    move-object v3, v0

    new-instance v4, Ljava/util/Random;

    move-object v6, v4

    move-object v4, v6

    move-object v5, v6

    invoke-direct {v5}, Ljava/util/Random;-><init>()V

    iput-object v4, v3, Lcom/particle/f;->c:Ljava/util/Random;

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lcom/particle/f;->h:Lcom/particle/c;

    move-object v3, v0

    move-object v4, v2

    iput-object v4, v3, Lcom/particle/f;->i:Lcom/particle/g;

    return-void
.end method

.method private static a(FFFF)F
    .registers 12

    move v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, v0

    move v5, v2

    sub-float/2addr v4, v5

    move v5, v0

    move v6, v2

    sub-float/2addr v5, v6

    mul-float/2addr v4, v5

    move v5, v1

    move v6, v3

    sub-float/2addr v5, v6

    move v6, v1

    move v7, v3

    sub-float/2addr v6, v7

    mul-float/2addr v5, v6

    add-float/2addr v4, v5

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v4

    double-to-float v4, v4

    move v0, v4

    return v0
.end method

.method static synthetic a(Lcom/particle/f;Z)Lcom/particle/d;
    .registers 6

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    move v3, v1

    invoke-direct {v2, v3}, Lcom/particle/f;->a(Z)Lcom/particle/d;

    move-result-object v2

    move-object v0, v2

    return-object v0
.end method

.method private a(Z)Lcom/particle/d;
    .registers 10
    .annotation build Landroid/support/annotation/NonNull;
    .end annotation

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    invoke-direct {v4}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v4

    move-object v2, v4

    move-object v4, v2

    invoke-virtual {v4}, Lcom/particle/e;->b()I

    move-result v4

    if-eqz v4, :cond_16

    move-object v4, v2

    invoke-virtual {v4}, Lcom/particle/e;->c()I

    move-result v4

    if-nez v4, :cond_21

    :cond_16
    new-instance v4, Ljava/lang/IllegalStateException;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const-string v6, "Cannot make new point if width or height is 0"

    invoke-direct {v5, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v4

    :cond_21
    new-instance v4, Lcom/particle/d;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Lcom/particle/d;-><init>()V

    move-object v3, v4

    move v4, v1

    if-eqz v4, :cond_35

    move-object v4, v0

    move-object v5, v3

    invoke-direct {v4, v5}, Lcom/particle/f;->a(Lcom/particle/d;)V

    :goto_32
    move-object v4, v3

    move-object v0, v4

    return-object v0

    :cond_35
    move-object v4, v0

    move-object v5, v3

    invoke-direct {v4, v5}, Lcom/particle/f;->b(Lcom/particle/d;)V

    goto :goto_32
.end method

.method private a(Lcom/particle/d;)V
    .registers 13
    .param p1    # Lcom/particle/d;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v7, v0

    invoke-direct {v7}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v7

    move-object v2, v7

    move-object v7, v2

    invoke-virtual {v7}, Lcom/particle/e;->b()I

    move-result v7

    move v3, v7

    move-object v7, v2

    invoke-virtual {v7}, Lcom/particle/e;->c()I

    move-result v7

    move v4, v7

    move v7, v3

    if-eqz v7, :cond_1a

    move v7, v4

    if-nez v7, :cond_25

    :cond_1a
    new-instance v7, Ljava/lang/IllegalStateException;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const-string v9, "Cannot apply points if width or height is 0"

    invoke-direct {v8, v9}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v7

    :cond_25
    move-object v7, v0

    iget-object v7, v7, Lcom/particle/f;->c:Ljava/util/Random;

    const/16 v8, 0x168

    invoke-virtual {v7, v8}, Ljava/util/Random;->nextInt(I)I

    move-result v7

    int-to-double v7, v7

    invoke-static {v7, v8}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v7

    move-wide v5, v7

    move-object v7, v1

    move-wide v8, v5

    invoke-static {v8, v9}, Ljava/lang/Math;->cos(D)D

    move-result-wide v8

    double-to-float v8, v8

    iput v8, v7, Lcom/particle/d;->a:F

    move-object v7, v1

    move-wide v8, v5

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    double-to-float v8, v8

    iput v8, v7, Lcom/particle/d;->b:F

    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lcom/particle/f;->c:Ljava/util/Random;

    move v9, v3

    invoke-virtual {v8, v9}, Ljava/util/Random;->nextInt(I)I

    move-result v8

    int-to-float v8, v8

    iput v8, v7, Lcom/particle/d;->c:F

    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lcom/particle/f;->c:Ljava/util/Random;

    move v9, v4

    invoke-virtual {v8, v9}, Ljava/util/Random;->nextInt(I)I

    move-result v8

    int-to-float v8, v8

    iput v8, v7, Lcom/particle/d;->d:F

    move-object v7, v1

    move-object v8, v0

    invoke-direct {v8}, Lcom/particle/f;->m()F

    move-result v8

    iput v8, v7, Lcom/particle/d;->e:F

    move-object v7, v1

    move-object v8, v0

    invoke-direct {v8}, Lcom/particle/f;->n()F

    move-result v8

    iput v8, v7, Lcom/particle/d;->f:F

    return-void
.end method

.method private a(Lcom/particle/e;Lcom/particle/d;)V
    .registers 11
    .param p1    # Lcom/particle/e;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Lcom/particle/d;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, v0

    invoke-direct {v3}, Lcom/particle/f;->g()Lcom/particle/c;

    move-result-object v3

    move-object v4, v2

    iget v4, v4, Lcom/particle/d;->c:F

    move-object v5, v2

    iget v5, v5, Lcom/particle/d;->d:F

    move-object v6, v2

    iget v6, v6, Lcom/particle/d;->f:F

    move-object v7, v1

    invoke-virtual {v7}, Lcom/particle/e;->g()I

    move-result v7

    invoke-interface {v3, v4, v5, v6, v7}, Lcom/particle/c;->fillCircle(FFFI)V

    return-void
.end method

.method private a(Lcom/particle/e;Lcom/particle/d;Lcom/particle/d;F)V
    .registers 21
    .param p1    # Lcom/particle/e;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Lcom/particle/d;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .param p3    # Lcom/particle/d;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move/from16 v4, p4

    const/high16 v7, 0x3f800000    # 1.0f

    move v8, v4

    move-object v9, v1

    invoke-virtual {v9}, Lcom/particle/e;->getLineDistance()F

    move-result v9

    div-float/2addr v8, v9

    sub-float/2addr v7, v8

    move v5, v7

    const/high16 v7, 0x437f0000    # 255.0f

    move v8, v5

    mul-float/2addr v7, v8

    float-to-int v7, v7

    move v6, v7

    move v7, v6

    move-object v8, v1

    invoke-virtual {v8}, Lcom/particle/e;->f()I

    move-result v8

    mul-int/2addr v7, v8

    const/16 v8, 0xff

    div-int/lit16 v7, v7, 0xff

    move v6, v7

    move-object v7, v0

    invoke-direct {v7}, Lcom/particle/f;->g()Lcom/particle/c;

    move-result-object v7

    move-object v8, v2

    iget v8, v8, Lcom/particle/d;->c:F

    move-object v9, v2

    iget v9, v9, Lcom/particle/d;->d:F

    move-object v10, v3

    iget v10, v10, Lcom/particle/d;->c:F

    move-object v11, v3

    iget v11, v11, Lcom/particle/d;->d:F

    move-object v12, v1

    invoke-virtual {v12}, Lcom/particle/e;->getLineThickness()F

    move-result v12

    move-object v13, v1

    invoke-virtual {v13}, Lcom/particle/e;->getLineColor()I

    move-result v13

    const v14, -0x4658eef9

    and-int/2addr v13, v14

    move v14, v6

    const/16 v15, 0x18

    shl-int/lit8 v14, v14, 0x18

    or-int/2addr v13, v14

    invoke-interface/range {v7 .. v13}, Lcom/particle/c;->drawLine(FFFFFI)V

    return-void
.end method

.method private a(Lcom/particle/f$a;)V
    .registers 10
    .param p1    # Lcom/particle/f$a;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    invoke-direct {v4}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v4

    move-object v2, v4

    move-object v4, v2

    invoke-virtual {v4}, Lcom/particle/e;->b()I

    move-result v4

    if-eqz v4, :cond_16

    move-object v4, v2

    invoke-virtual {v4}, Lcom/particle/e;->c()I

    move-result v4

    if-nez v4, :cond_21

    :cond_16
    new-instance v4, Ljava/lang/IllegalStateException;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const-string v6, "Cannot init points if width or height is 0"

    invoke-direct {v5, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v4

    :cond_21
    move-object v4, v2

    invoke-virtual {v4}, Lcom/particle/e;->e()V

    const/4 v4, 0x0

    move v3, v4

    :goto_27
    move v4, v3

    move-object v5, v2

    invoke-virtual {v5}, Lcom/particle/e;->getNumDots()I

    move-result v5

    if-ge v4, v5, :cond_3c

    move-object v4, v2

    move-object v5, v1

    move v6, v3

    invoke-interface {v5, v6}, Lcom/particle/f$a;->a(I)Lcom/particle/d;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/particle/e;->a(Lcom/particle/d;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_27

    :cond_3c
    return-void
.end method

.method private a(FF)Z
    .registers 10

    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v5, v0

    invoke-direct {v5}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v5

    move-object v3, v5

    move-object v5, v3

    invoke-virtual {v5}, Lcom/particle/e;->getMinDotRadius()F

    move-result v5

    move-object v6, v3

    invoke-virtual {v6}, Lcom/particle/e;->getLineDistance()F

    move-result v6

    add-float/2addr v5, v6

    move v4, v5

    move v5, v1

    move v6, v4

    add-float/2addr v5, v6

    const/4 v6, 0x0

    cmpg-float v5, v5, v6

    if-ltz v5, :cond_3f

    move v5, v1

    move v6, v4

    sub-float/2addr v5, v6

    move-object v6, v3

    invoke-virtual {v6}, Lcom/particle/e;->b()I

    move-result v6

    int-to-float v6, v6

    cmpl-float v5, v5, v6

    if-gtz v5, :cond_3f

    move v5, v2

    move v6, v4

    add-float/2addr v5, v6

    const/4 v6, 0x0

    cmpg-float v5, v5, v6

    if-ltz v5, :cond_3f

    move v5, v2

    move v6, v4

    sub-float/2addr v5, v6

    move-object v6, v3

    invoke-virtual {v6}, Lcom/particle/e;->c()I

    move-result v6

    int-to-float v6, v6

    cmpl-float v5, v5, v6

    if-lez v5, :cond_42

    :cond_3f
    const/4 v5, 0x1

    :goto_40
    move v0, v5

    return v0

    :cond_42
    const/4 v5, 0x0

    goto :goto_40
.end method

.method private static b(FFFF)F
    .registers 16

    move v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v8, v1

    move v9, v3

    sub-float/2addr v8, v9

    float-to-double v8, v8

    move v10, v0

    move v11, v2

    sub-float/2addr v10, v11

    float-to-double v10, v10

    invoke-static {v8, v9, v10, v11}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v8

    move-wide v4, v8

    move-wide v8, v4

    invoke-static {v8, v9}, Ljava/lang/Math;->toDegrees(D)D

    move-result-wide v8

    move-wide v6, v8

    move-wide v8, v4

    const-wide/16 v10, 0x0

    cmpg-double v8, v8, v10

    if-gez v8, :cond_26

    move-wide v8, v6

    const-wide v10, 0x4076800000000000L    # 360.0

    add-double/2addr v8, v10

    move-wide v6, v8

    :cond_26
    move-wide v8, v6

    double-to-float v8, v8

    move v0, v8

    return v0
.end method

.method private b(Lcom/particle/d;)V
    .registers 18
    .param p1    # Lcom/particle/d;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v11, v0

    invoke-direct {v11}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v11

    move-object v2, v11

    move-object v11, v2

    invoke-virtual {v11}, Lcom/particle/e;->b()I

    move-result v11

    move v3, v11

    move-object v11, v2

    invoke-virtual {v11}, Lcom/particle/e;->c()I

    move-result v11

    move v4, v11

    move v11, v3

    if-eqz v11, :cond_1c

    move v11, v4

    if-nez v11, :cond_27

    :cond_1c
    new-instance v11, Ljava/lang/IllegalStateException;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    const-string v13, "Cannot apply points if width or height is 0"

    invoke-direct {v12, v13}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v11

    :cond_27
    move-object v11, v1

    move-object v12, v0

    iget-object v12, v12, Lcom/particle/f;->c:Ljava/util/Random;

    move v13, v3

    invoke-virtual {v12, v13}, Ljava/util/Random;->nextInt(I)I

    move-result v12

    int-to-float v12, v12

    iput v12, v11, Lcom/particle/d;->c:F

    move-object v11, v1

    move-object v12, v0

    iget-object v12, v12, Lcom/particle/f;->c:Ljava/util/Random;

    move v13, v4

    invoke-virtual {v12, v13}, Ljava/util/Random;->nextInt(I)I

    move-result v12

    int-to-float v12, v12

    iput v12, v11, Lcom/particle/d;->d:F

    move-object v11, v2

    invoke-virtual {v11}, Lcom/particle/e;->getMinDotRadius()F

    move-result v11

    move-object v12, v2

    invoke-virtual {v12}, Lcom/particle/e;->getLineDistance()F

    move-result v12

    add-float/2addr v11, v12

    move v5, v11

    move-object v11, v0

    iget-object v11, v11, Lcom/particle/f;->c:Ljava/util/Random;

    const/4 v12, 0x4

    invoke-virtual {v11, v12}, Ljava/util/Random;->nextInt(I)I

    move-result v11

    packed-switch v11, :pswitch_data_156

    new-instance v11, Ljava/lang/IllegalArgumentException;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    const-string v13, "Supplied value out of range"

    invoke-direct {v12, v13}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v11

    :pswitch_61
    move-object v11, v1

    move v12, v5

    neg-float v12, v12

    iput v12, v11, Lcom/particle/d;->c:F

    sget v11, Lcom/particle/f;->a:F

    sget v12, Lcom/particle/f;->a:F

    move-object v13, v1

    iget v13, v13, Lcom/particle/d;->c:F

    move-object v14, v1

    iget v14, v14, Lcom/particle/d;->d:F

    invoke-static {v11, v12, v13, v14}, Lcom/particle/f;->b(FFFF)F

    move-result v11

    move v6, v11

    sget v11, Lcom/particle/f;->a:F

    move v12, v4

    int-to-float v12, v12

    sget v13, Lcom/particle/f;->a:F

    sub-float/2addr v12, v13

    move-object v13, v1

    iget v13, v13, Lcom/particle/d;->c:F

    move-object v14, v1

    iget v14, v14, Lcom/particle/d;->d:F

    invoke-static {v11, v12, v13, v14}, Lcom/particle/f;->b(FFFF)F

    move-result v11

    move v7, v11

    :goto_87
    move v11, v7

    move v12, v6

    cmpg-float v11, v11, v12

    if-gez v11, :cond_92

    move v11, v7

    const/high16 v12, 0x43b40000    # 360.0f

    add-float/2addr v11, v12

    move v7, v11

    :cond_92
    move v11, v6

    move-object v12, v0

    iget-object v12, v12, Lcom/particle/f;->c:Ljava/util/Random;

    move v13, v7

    move v14, v6

    sub-float/2addr v13, v14

    invoke-static {v13}, Ljava/lang/Math;->abs(F)F

    move-result v13

    float-to-int v13, v13

    invoke-virtual {v12, v13}, Ljava/util/Random;->nextInt(I)I

    move-result v12

    int-to-float v12, v12

    add-float/2addr v11, v12

    move v8, v11

    move v11, v8

    float-to-double v11, v11

    invoke-static {v11, v12}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v11

    move-wide v9, v11

    move-object v11, v1

    move-wide v12, v9

    invoke-static {v12, v13}, Ljava/lang/Math;->cos(D)D

    move-result-wide v12

    double-to-float v12, v12

    iput v12, v11, Lcom/particle/d;->a:F

    move-object v11, v1

    move-wide v12, v9

    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    move-result-wide v12

    double-to-float v12, v12

    iput v12, v11, Lcom/particle/d;->b:F

    move-object v11, v1

    move-object v12, v0

    invoke-direct {v12}, Lcom/particle/f;->m()F

    move-result v12

    iput v12, v11, Lcom/particle/d;->e:F

    move-object v11, v1

    move-object v12, v0

    invoke-direct {v12}, Lcom/particle/f;->n()F

    move-result v12

    iput v12, v11, Lcom/particle/d;->f:F

    return-void

    :pswitch_cf
    move-object v11, v1

    move v12, v5

    neg-float v12, v12

    iput v12, v11, Lcom/particle/d;->d:F

    move v11, v3

    int-to-float v11, v11

    sget v12, Lcom/particle/f;->a:F

    sub-float/2addr v11, v12

    sget v12, Lcom/particle/f;->a:F

    move-object v13, v1

    iget v13, v13, Lcom/particle/d;->c:F

    move-object v14, v1

    iget v14, v14, Lcom/particle/d;->d:F

    invoke-static {v11, v12, v13, v14}, Lcom/particle/f;->b(FFFF)F

    move-result v11

    move v6, v11

    sget v11, Lcom/particle/f;->a:F

    sget v12, Lcom/particle/f;->a:F

    move-object v13, v1

    iget v13, v13, Lcom/particle/d;->c:F

    move-object v14, v1

    iget v14, v14, Lcom/particle/d;->d:F

    invoke-static {v11, v12, v13, v14}, Lcom/particle/f;->b(FFFF)F

    move-result v11

    move v7, v11

    goto :goto_87

    :pswitch_f6
    move-object v11, v1

    move v12, v3

    int-to-float v12, v12

    move v13, v5

    add-float/2addr v12, v13

    iput v12, v11, Lcom/particle/d;->c:F

    move v11, v3

    int-to-float v11, v11

    sget v12, Lcom/particle/f;->a:F

    sub-float/2addr v11, v12

    move v12, v4

    int-to-float v12, v12

    sget v13, Lcom/particle/f;->a:F

    sub-float/2addr v12, v13

    move-object v13, v1

    iget v13, v13, Lcom/particle/d;->c:F

    move-object v14, v1

    iget v14, v14, Lcom/particle/d;->d:F

    invoke-static {v11, v12, v13, v14}, Lcom/particle/f;->b(FFFF)F

    move-result v11

    move v6, v11

    move v11, v3

    int-to-float v11, v11

    sget v12, Lcom/particle/f;->a:F

    sub-float/2addr v11, v12

    sget v12, Lcom/particle/f;->a:F

    move-object v13, v1

    iget v13, v13, Lcom/particle/d;->c:F

    move-object v14, v1

    iget v14, v14, Lcom/particle/d;->d:F

    invoke-static {v11, v12, v13, v14}, Lcom/particle/f;->b(FFFF)F

    move-result v11

    move v7, v11

    goto/16 :goto_87

    :pswitch_126
    move-object v11, v1

    move v12, v4

    int-to-float v12, v12

    move v13, v5

    add-float/2addr v12, v13

    iput v12, v11, Lcom/particle/d;->d:F

    sget v11, Lcom/particle/f;->a:F

    move v12, v4

    int-to-float v12, v12

    sget v13, Lcom/particle/f;->a:F

    sub-float/2addr v12, v13

    move-object v13, v1

    iget v13, v13, Lcom/particle/d;->c:F

    move-object v14, v1

    iget v14, v14, Lcom/particle/d;->d:F

    invoke-static {v11, v12, v13, v14}, Lcom/particle/f;->b(FFFF)F

    move-result v11

    move v6, v11

    move v11, v3

    int-to-float v11, v11

    sget v12, Lcom/particle/f;->a:F

    sub-float/2addr v11, v12

    move v12, v4

    int-to-float v12, v12

    sget v13, Lcom/particle/f;->a:F

    sub-float/2addr v12, v13

    move-object v13, v1

    iget v13, v13, Lcom/particle/d;->c:F

    move-object v14, v1

    iget v14, v14, Lcom/particle/d;->d:F

    invoke-static {v11, v12, v13, v14}, Lcom/particle/f;->b(FFFF)F

    move-result v11

    move v7, v11

    goto/16 :goto_87

    :pswitch_data_156
    .packed-switch 0x0
        :pswitch_61
        :pswitch_cf
        :pswitch_f6
        :pswitch_126
    .end packed-switch
.end method

.method private f()Lcom/particle/e;
    .registers 3
    .annotation build Landroid/support/annotation/NonNull;
    .end annotation

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/f;->b:Lcom/particle/e;

    move-object v0, v1

    return-object v0
.end method

.method private g()Lcom/particle/c;
    .registers 3
    .annotation build Landroid/support/annotation/NonNull;
    .end annotation

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/f;->h:Lcom/particle/c;

    move-object v0, v1

    return-object v0
.end method

.method private h()Lcom/particle/g;
    .registers 3
    .annotation build Landroid/support/annotation/NonNull;
    .end annotation

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/f;->i:Lcom/particle/g;

    move-object v0, v1

    return-object v0
.end method

.method private i()V
    .registers 5

    move-object v0, p0

    move-object v1, v0

    const-wide/16 v2, 0x0

    iput-wide v2, v1, Lcom/particle/f;->e:J

    return-void
.end method

.method private j()V
    .registers 7

    move-object v0, p0

    move-object v1, v0

    invoke-virtual {v1}, Lcom/particle/f;->nextFrame()V

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->h()Lcom/particle/g;

    move-result-object v1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/f;->b:Lcom/particle/e;

    invoke-virtual {v2}, Lcom/particle/e;->getFrameDelay()I

    move-result v2

    int-to-long v2, v2

    move-object v4, v0

    iget-wide v4, v4, Lcom/particle/f;->f:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x5

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v2

    invoke-interface {v1, v2, v3}, Lcom/particle/g;->scheduleNextFrame(J)V

    return-void
.end method

.method private k()V
    .registers 7

    move-object v0, p0

    move-object v1, v0

    new-instance v2, Lcom/particle/f$1;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    move-object v4, v0

    invoke-direct {v3, v4}, Lcom/particle/f$1;-><init>(Lcom/particle/f;)V

    invoke-direct {v1, v2}, Lcom/particle/f;->a(Lcom/particle/f$a;)V

    return-void
.end method

.method private l()V
    .registers 7

    move-object v0, p0

    move-object v1, v0

    new-instance v2, Lcom/particle/f$2;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    move-object v4, v0

    invoke-direct {v3, v4}, Lcom/particle/f$2;-><init>(Lcom/particle/f;)V

    invoke-direct {v1, v2}, Lcom/particle/f;->a(Lcom/particle/f$a;)V

    return-void
.end method

.method private m()F
    .registers 6

    move-object v0, p0

    const/high16 v1, 0x3f800000    # 1.0f

    const v2, 0x3dcccccd    # 0.1f

    move-object v3, v0

    iget-object v3, v3, Lcom/particle/f;->c:Ljava/util/Random;

    const/16 v4, 0xb

    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    const/4 v4, 0x5

    add-int/lit8 v3, v3, -0x5

    int-to-float v3, v3

    mul-float/2addr v2, v3

    add-float/2addr v1, v2

    move v0, v1

    return v0
.end method

.method private n()F
    .registers 7

    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v2

    move-object v1, v2

    move-object v2, v1

    invoke-virtual {v2}, Lcom/particle/e;->getMinDotRadius()F

    move-result v2

    move-object v3, v1

    invoke-virtual {v3}, Lcom/particle/e;->getMaxDotRadius()F

    move-result v3

    cmpl-float v2, v2, v3

    if-nez v2, :cond_1c

    move-object v2, v1

    invoke-virtual {v2}, Lcom/particle/e;->getMinDotRadius()F

    move-result v2

    :goto_1a
    move v0, v2

    return v0

    :cond_1c
    move-object v2, v1

    invoke-virtual {v2}, Lcom/particle/e;->getMinDotRadius()F

    move-result v2

    move-object v3, v0

    iget-object v3, v3, Lcom/particle/f;->c:Ljava/util/Random;

    move-object v4, v1

    invoke-virtual {v4}, Lcom/particle/e;->getMaxDotRadius()F

    move-result v4

    move-object v5, v1

    invoke-virtual {v5}, Lcom/particle/e;->getMinDotRadius()F

    move-result v5

    sub-float/2addr v4, v5

    const/high16 v5, 0x42c80000    # 100.0f

    mul-float/2addr v4, v5

    float-to-int v4, v4

    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    int-to-float v3, v3

    const/high16 v4, 0x42c80000    # 100.0f

    div-float/2addr v3, v4

    add-float/2addr v2, v3

    goto :goto_1a
.end method


# virtual methods
.method a()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/particle/f;->b:Lcom/particle/e;

    invoke-virtual {v1}, Lcom/particle/e;->f()I

    move-result v1

    move v0, v1

    return v0
.end method

.method a(I)V
    .registers 6

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-object v2, v2, Lcom/particle/f;->b:Lcom/particle/e;

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/e;->c(I)V

    return-void
.end method

.method a(IIII)V
    .registers 14

    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v6, v0

    invoke-direct {v6}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v6

    move-object v5, v6

    move-object v6, v5

    move v7, v3

    move v8, v1

    sub-int/2addr v7, v8

    invoke-virtual {v6, v7}, Lcom/particle/e;->a(I)V

    move-object v6, v5

    move v7, v4

    move v8, v2

    sub-int/2addr v7, v8

    invoke-virtual {v6, v7}, Lcom/particle/e;->b(I)V

    move v6, v3

    move v7, v1

    sub-int/2addr v6, v7

    if-lez v6, :cond_30

    move v6, v4

    move v7, v2

    sub-int/2addr v6, v7

    if-lez v6, :cond_30

    move-object v6, v0

    iget-boolean v6, v6, Lcom/particle/f;->d:Z

    if-nez v6, :cond_30

    move-object v6, v0

    const/4 v7, 0x1

    iput-boolean v7, v6, Lcom/particle/f;->d:Z

    move-object v6, v0

    invoke-direct {v6}, Lcom/particle/f;->k()V

    :cond_30
    return-void
.end method

.method a(Landroid/content/res/Resources;Landroid/util/AttributeSet;)V
    .registers 11
    .param p1    # Landroid/content/res/Resources;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v5, v1

    move-object v6, v2

    sget-object v7, Lcom/particle/R$styleable;->ParticlesView:[I

    invoke-virtual {v5, v6, v7}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v5

    move-object v3, v5

    move-object v5, v0

    move-object v6, v3

    :try_start_e
    invoke-virtual {v5, v6}, Lcom/particle/f;->a(Landroid/content/res/TypedArray;)V
    :try_end_11
    .catchall {:try_start_e .. :try_end_11} :catchall_16

    move-object v5, v3

    invoke-virtual {v5}, Landroid/content/res/TypedArray;->recycle()V

    return-void

    :catchall_16
    move-exception v5

    move-object v4, v5

    move-object v5, v3

    invoke-virtual {v5}, Landroid/content/res/TypedArray;->recycle()V

    move-object v5, v4

    throw v5
.end method

.method a(Landroid/content/res/TypedArray;)V
    .registers 13
    .param p1    # Landroid/content/res/TypedArray;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    move-object v0, p0

    move-object v1, p1

    move-object v7, v1

    invoke-virtual {v7}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result v7

    move v2, v7

    sget v7, Lcom/particle/b;->b:F

    move v3, v7

    sget v7, Lcom/particle/b;->a:F

    move v4, v7

    const/4 v7, 0x0

    move v5, v7

    :goto_10
    move v7, v5

    move v8, v2

    if-ge v7, v8, :cond_b8

    move-object v7, v1

    move v8, v5

    invoke-virtual {v7, v8}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v7

    move v6, v7

    move v7, v6

    sget v8, Lcom/particle/R$styleable;->ParticlesView_particle_app_minDotRadius:I

    if-ne v7, v8, :cond_2c

    move-object v7, v1

    move v8, v6

    sget v9, Lcom/particle/b;->b:F

    invoke-virtual {v7, v8, v9}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v7

    move v3, v7

    :cond_29
    :goto_29
    add-int/lit8 v5, v5, 0x1

    goto :goto_10

    :cond_2c
    move v7, v6

    sget v8, Lcom/particle/R$styleable;->ParticlesView_particle_app_maxDotRadius:I

    if-ne v7, v8, :cond_3b

    move-object v7, v1

    move v8, v6

    sget v9, Lcom/particle/b;->a:F

    invoke-virtual {v7, v8, v9}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v7

    move v4, v7

    goto :goto_29

    :cond_3b
    move v7, v6

    sget v8, Lcom/particle/R$styleable;->ParticlesView_particle_app_lineThickness:I

    if-ne v7, v8, :cond_4d

    move-object v7, v0

    move-object v8, v1

    move v9, v6

    sget v10, Lcom/particle/b;->c:F

    invoke-virtual {v8, v9, v10}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v8

    invoke-virtual {v7, v8}, Lcom/particle/f;->setLineThickness(F)V

    goto :goto_29

    :cond_4d
    move v7, v6

    sget v8, Lcom/particle/R$styleable;->ParticlesView_particle_app_lineDistance:I

    if-ne v7, v8, :cond_5f

    move-object v7, v0

    move-object v8, v1

    move v9, v6

    sget v10, Lcom/particle/b;->d:F

    invoke-virtual {v8, v9, v10}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v8

    invoke-virtual {v7, v8}, Lcom/particle/f;->setLineDistance(F)V

    goto :goto_29

    :cond_5f
    move v7, v6

    sget v8, Lcom/particle/R$styleable;->ParticlesView_particle_app_numDots:I

    if-ne v7, v8, :cond_71

    move-object v7, v0

    move-object v8, v1

    move v9, v6

    const/16 v10, 0x3c

    invoke-virtual {v8, v9, v10}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result v8

    invoke-virtual {v7, v8}, Lcom/particle/f;->setNumDots(I)V

    goto :goto_29

    :cond_71
    move v7, v6

    sget v8, Lcom/particle/R$styleable;->ParticlesView_particle_app_dotColor:I

    if-ne v7, v8, :cond_82

    move-object v7, v0

    move-object v8, v1

    move v9, v6

    const/4 v10, -0x1

    invoke-virtual {v8, v9, v10}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v8

    invoke-virtual {v7, v8}, Lcom/particle/f;->setDotColor(I)V

    goto :goto_29

    :cond_82
    move v7, v6

    sget v8, Lcom/particle/R$styleable;->ParticlesView_particle_app_lineColor:I

    if-ne v7, v8, :cond_93

    move-object v7, v0

    move-object v8, v1

    move v9, v6

    const/4 v10, -0x1

    invoke-virtual {v8, v9, v10}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v8

    invoke-virtual {v7, v8}, Lcom/particle/f;->setLineColor(I)V

    goto :goto_29

    :cond_93
    move v7, v6

    sget v8, Lcom/particle/R$styleable;->ParticlesView_particle_app_frameDelayMillis:I

    if-ne v7, v8, :cond_a5

    move-object v7, v0

    move-object v8, v1

    move v9, v6

    const/16 v10, 0xa

    invoke-virtual {v8, v9, v10}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result v8

    invoke-virtual {v7, v8}, Lcom/particle/f;->setFrameDelay(I)V

    goto :goto_29

    :cond_a5
    move v7, v6

    sget v8, Lcom/particle/R$styleable;->ParticlesView_particle_app_stepMultiplier:I

    if-ne v7, v8, :cond_29

    move-object v7, v0

    move-object v8, v1

    move v9, v6

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-virtual {v8, v9, v10}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v8

    invoke-virtual {v7, v8}, Lcom/particle/f;->setStepMultiplier(F)V

    goto/16 :goto_29

    :cond_b8
    move-object v7, v0

    move v8, v3

    move v9, v4

    invoke-virtual {v7, v8, v9}, Lcom/particle/f;->setDotRadiusRange(FF)V

    return-void
.end method

.method b()V
    .registers 4

    move-object v0, p0

    move-object v1, v0

    iget-boolean v1, v1, Lcom/particle/f;->g:Z

    if-nez v1, :cond_12

    move-object v1, v0

    const/4 v2, 0x1

    iput-boolean v2, v1, Lcom/particle/f;->g:Z

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->i()V

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->j()V

    :cond_12
    return-void
.end method

.method c()V
    .registers 4

    move-object v0, p0

    move-object v1, v0

    iget-boolean v1, v1, Lcom/particle/f;->g:Z

    if-eqz v1, :cond_16

    move-object v1, v0

    const/4 v2, 0x0

    iput-boolean v2, v1, Lcom/particle/f;->g:Z

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->i()V

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->h()Lcom/particle/g;

    move-result-object v1

    invoke-interface {v1}, Lcom/particle/g;->unscheduleNextFrame()V

    :cond_16
    return-void
.end method

.method d()Z
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-boolean v1, v1, Lcom/particle/f;->g:Z

    move v0, v1

    return v0
.end method

.method e()V
    .registers 17

    move-object/from16 v0, p0

    move-object v11, v0

    invoke-direct {v11}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v11

    move-object v1, v11

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v11

    move-wide v2, v11

    move-object v11, v1

    invoke-virtual {v11}, Lcom/particle/e;->getNumDots()I

    move-result v11

    if-lez v11, :cond_70

    move-object v11, v1

    invoke-virtual {v11}, Lcom/particle/e;->a()Ljava/util/List;

    move-result-object v11

    move-object v4, v11

    move-object v11, v4

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    move v5, v11

    const/4 v11, 0x0

    move v6, v11

    :goto_22
    move v11, v6

    move v12, v5

    if-ge v11, v12, :cond_70

    move-object v11, v4

    move v12, v6

    invoke-interface {v11, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/particle/d;

    move-object v7, v11

    move v11, v6

    const/4 v12, 0x1

    add-int/lit8 v11, v11, 0x1

    move v8, v11

    :goto_34
    move v11, v8

    move v12, v5

    if-ge v11, v12, :cond_67

    move-object v11, v4

    move v12, v8

    invoke-interface {v11, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/particle/d;

    move-object v9, v11

    move-object v11, v7

    iget v11, v11, Lcom/particle/d;->c:F

    move-object v12, v7

    iget v12, v12, Lcom/particle/d;->d:F

    move-object v13, v9

    iget v13, v13, Lcom/particle/d;->c:F

    move-object v14, v9

    iget v14, v14, Lcom/particle/d;->d:F

    invoke-static {v11, v12, v13, v14}, Lcom/particle/f;->a(FFFF)F

    move-result v11

    move v10, v11

    move v11, v10

    move-object v12, v1

    invoke-virtual {v12}, Lcom/particle/e;->getLineDistance()F

    move-result v12

    cmpg-float v11, v11, v12

    if-gez v11, :cond_64

    move-object v11, v0

    move-object v12, v1

    move-object v13, v7

    move-object v14, v9

    move v15, v10

    invoke-direct {v11, v12, v13, v14, v15}, Lcom/particle/f;->a(Lcom/particle/e;Lcom/particle/d;Lcom/particle/d;F)V

    :cond_64
    add-int/lit8 v8, v8, 0x1

    goto :goto_34

    :cond_67
    move-object v11, v0

    move-object v12, v1

    move-object v13, v7

    invoke-direct {v11, v12, v13}, Lcom/particle/f;->a(Lcom/particle/e;Lcom/particle/d;)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_22

    :cond_70
    move-object v11, v0

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v12

    move-wide v14, v2

    sub-long/2addr v12, v14

    iput-wide v12, v11, Lcom/particle/f;->f:J

    return-void
.end method

.method public getDotColor()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/particle/e;->getDotColor()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getFrameDelay()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/particle/e;->getFrameDelay()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getLineColor()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/particle/e;->getLineColor()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getLineDistance()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/particle/e;->getLineDistance()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getLineThickness()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/particle/e;->getLineThickness()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getMaxDotRadius()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/particle/e;->getMaxDotRadius()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getMinDotRadius()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/particle/e;->getMinDotRadius()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getNumDots()I
    .registers 3

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/particle/e;->getNumDots()I

    move-result v1

    move v0, v1

    return v0
.end method

.method public getStepMultiplier()F
    .registers 3

    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/particle/e;->getStepMultiplier()F

    move-result v1

    move v0, v1

    return v0
.end method

.method public makeBrandNewFrame()V
    .registers 4

    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v2

    move-object v1, v2

    move-object v2, v1

    invoke-virtual {v2}, Lcom/particle/e;->b()I

    move-result v2

    if-eqz v2, :cond_1d

    move-object v2, v1

    invoke-virtual {v2}, Lcom/particle/e;->c()I

    move-result v2

    if-eqz v2, :cond_1d

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->i()V

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->k()V

    :cond_1d
    return-void
.end method

.method public makeBrandNewFrameWithPointsOffscreen()V
    .registers 4

    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v2

    move-object v1, v2

    move-object v2, v1

    invoke-virtual {v2}, Lcom/particle/e;->b()I

    move-result v2

    if-eqz v2, :cond_1d

    move-object v2, v1

    invoke-virtual {v2}, Lcom/particle/e;->c()I

    move-result v2

    if-eqz v2, :cond_1d

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->i()V

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->l()V

    :cond_1d
    return-void
.end method

.method public nextFrame()V
    .registers 13

    move-object v0, p0

    move-object v7, v0

    invoke-direct {v7}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v7

    move-object v1, v7

    move-object v7, v0

    iget-wide v7, v7, Lcom/particle/f;->e:J

    const-wide/16 v9, 0x0

    cmp-long v7, v7, v9

    if-nez v7, :cond_73

    const/high16 v7, 0x3f800000    # 1.0f

    :goto_12
    move v2, v7

    move-object v7, v1

    invoke-virtual {v7}, Lcom/particle/e;->a()Ljava/util/List;

    move-result-object v7

    move-object v3, v7

    move-object v7, v3

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    move v4, v7

    const/4 v7, 0x0

    move v5, v7

    :goto_21
    move v7, v5

    move v8, v4

    if-ge v7, v8, :cond_81

    move-object v7, v3

    move v8, v5

    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/particle/d;

    move-object v6, v7

    move-object v7, v6

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    iget v8, v8, Lcom/particle/d;->c:F

    move v9, v2

    move-object v10, v1

    invoke-virtual {v10}, Lcom/particle/e;->getStepMultiplier()F

    move-result v10

    mul-float/2addr v9, v10

    move-object v10, v6

    iget v10, v10, Lcom/particle/d;->e:F

    mul-float/2addr v9, v10

    move-object v10, v6

    iget v10, v10, Lcom/particle/d;->a:F

    mul-float/2addr v9, v10

    add-float/2addr v8, v9

    iput v8, v7, Lcom/particle/d;->c:F

    move-object v7, v6

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    iget v8, v8, Lcom/particle/d;->d:F

    move v9, v2

    move-object v10, v1

    invoke-virtual {v10}, Lcom/particle/e;->getStepMultiplier()F

    move-result v10

    mul-float/2addr v9, v10

    move-object v10, v6

    iget v10, v10, Lcom/particle/d;->e:F

    mul-float/2addr v9, v10

    move-object v10, v6

    iget v10, v10, Lcom/particle/d;->b:F

    mul-float/2addr v9, v10

    add-float/2addr v8, v9

    iput v8, v7, Lcom/particle/d;->d:F

    move-object v7, v0

    move-object v8, v6

    iget v8, v8, Lcom/particle/d;->c:F

    move-object v9, v6

    iget v9, v9, Lcom/particle/d;->d:F

    invoke-direct {v7, v8, v9}, Lcom/particle/f;->a(FF)Z

    move-result v7

    if-eqz v7, :cond_70

    move-object v7, v0

    move-object v8, v6

    invoke-direct {v7, v8}, Lcom/particle/f;->b(Lcom/particle/d;)V

    :cond_70
    add-int/lit8 v5, v5, 0x1

    goto :goto_21

    :cond_73
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v7

    move-object v9, v0

    iget-wide v9, v9, Lcom/particle/f;->e:J

    sub-long/2addr v7, v9

    long-to-float v7, v7

    const v8, 0x3d4ccccd    # 0.05f

    mul-float/2addr v7, v8

    goto :goto_12

    :cond_81
    move-object v7, v0

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v8

    iput-wide v8, v7, Lcom/particle/f;->e:J

    move-object v7, v0

    invoke-direct {v7}, Lcom/particle/f;->h()Lcom/particle/g;

    move-result-object v7

    invoke-interface {v7}, Lcom/particle/g;->invalidate()V

    return-void
.end method

.method public run()V
    .registers 3

    move-object v0, p0

    move-object v1, v0

    iget-boolean v1, v1, Lcom/particle/f;->g:Z

    if-eqz v1, :cond_b

    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->j()V

    :goto_a
    return-void

    :cond_b
    move-object v1, v0

    invoke-direct {v1}, Lcom/particle/f;->i()V

    goto :goto_a
.end method

.method public setDotColor(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v2

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/e;->setDotColor(I)V

    return-void
.end method

.method public setDotRadiusRange(FF)V
    .registers 9
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.5
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.5
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v3, v0

    invoke-direct {v3}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v3

    move v4, v1

    move v5, v2

    invoke-virtual {v3, v4, v5}, Lcom/particle/e;->setDotRadiusRange(FF)V

    return-void
.end method

.method public setFrameDelay(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/IntRange;
            from = 0x0L
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v2

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/e;->setFrameDelay(I)V

    return-void
.end method

.method public setLineColor(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroid/support/annotation/ColorInt;
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v2

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/e;->setLineColor(I)V

    return-void
.end method

.method public setLineDistance(F)V
    .registers 6
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v2

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/e;->setLineDistance(F)V

    return-void
.end method

.method public setLineThickness(F)V
    .registers 6
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 1.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v2

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/e;->setLineThickness(F)V

    return-void
.end method

.method public setNumDots(I)V
    .registers 11
    .param p1    # I
        .annotation build Landroid/support/annotation/IntRange;
            from = 0x0L
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move v5, v1

    if-gez v5, :cond_10

    new-instance v5, Ljava/lang/IllegalArgumentException;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    const-string v7, "numPoints must not be negative"

    invoke-direct {v6, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v5

    :cond_10
    move-object v5, v0

    invoke-direct {v5}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v5

    move-object v2, v5

    move-object v5, v2

    invoke-virtual {v5}, Lcom/particle/e;->getNumDots()I

    move-result v5

    move v3, v5

    move v5, v1

    move v6, v3

    if-eq v5, v6, :cond_41

    move-object v5, v0

    iget-boolean v5, v5, Lcom/particle/f;->d:Z

    if-eqz v5, :cond_3c

    move v5, v1

    move v6, v3

    if-le v5, v6, :cond_42

    move v5, v3

    move v4, v5

    :goto_2b
    move v5, v4

    move v6, v1

    if-ge v5, v6, :cond_3c

    move-object v5, v2

    move-object v6, v0

    const/4 v7, 0x0

    invoke-direct {v6, v7}, Lcom/particle/f;->a(Z)Lcom/particle/d;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/particle/e;->a(Lcom/particle/d;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_2b

    :cond_3c
    move-object v5, v2

    move v6, v1

    invoke-virtual {v5, v6}, Lcom/particle/e;->setNumDots(I)V

    :cond_41
    return-void

    :cond_42
    const/4 v5, 0x0

    move v4, v5

    :goto_44
    move v5, v4

    move v6, v3

    move v7, v1

    sub-int/2addr v6, v7

    if-ge v5, v6, :cond_3c

    move-object v5, v2

    invoke-virtual {v5}, Lcom/particle/e;->d()V

    add-int/lit8 v4, v4, 0x1

    goto :goto_44
.end method

.method public setStepMultiplier(F)V
    .registers 6
    .param p1    # F
        .annotation build Landroid/support/annotation/FloatRange;
            from = 0.0
        .end annotation
    .end param

    move-object v0, p0

    move v1, p1

    move-object v2, v0

    invoke-direct {v2}, Lcom/particle/f;->f()Lcom/particle/e;

    move-result-object v2

    move v3, v1

    invoke-virtual {v2, v3}, Lcom/particle/e;->setStepMultiplier(F)V

    return-void
.end method
