<?xml version="1.0" encoding="utf-8" ?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android" android:gravity="center" android:layout_width="fill_parent" android:layout_height="fill_parent">
				<com.fonts.rainbow.TextView android:textSize="16.0dip" android:textStyle="bold" android:textColor="#ffffffff" android:paddingTop="2.0dip" android:paddingBottom="2.0dip" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="test" />
</FrameLayout>
