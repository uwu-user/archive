.class Lcom/fonts/rainbow/HText$1;
.super Ljava/lang/Object;
.source "HText.java"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fonts/rainbow/HText;->init(Lcom/fonts/rainbow/HTextView;Landroid/util/AttributeSet;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/fonts/rainbow/HText;


# direct methods
.method constructor <init>(Lcom/fonts/rainbow/HText;)V
    .registers 2
    .param p1, "this$0"    # Lcom/fonts/rainbow/HText;

    .prologue
    .line 44
    iput-object p1, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onGlobalLayout()V
    .registers 4

    .prologue
    .line 47
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_4c

    .line 48
    iget-object v0, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    iget-object v0, v0, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v0}, Lcom/fonts/rainbow/HTextView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 52
    :goto_11
    iget-object v0, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    iget-object v1, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    iget-object v1, v1, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v1}, Lcom/fonts/rainbow/HTextView;->getTextSize()F

    move-result v1

    iput v1, v0, Lcom/fonts/rainbow/HText;->mTextSize:F

    .line 53
    iget-object v0, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    iget-object v1, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    iget-object v1, v1, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v1}, Lcom/fonts/rainbow/HTextView;->getWidth()I

    move-result v1

    iput v1, v0, Lcom/fonts/rainbow/HText;->mWidth:I

    .line 54
    iget-object v0, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    iget-object v1, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    iget-object v1, v1, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v1}, Lcom/fonts/rainbow/HTextView;->getHeight()I

    move-result v1

    iput v1, v0, Lcom/fonts/rainbow/HText;->mHeight:I

    .line 55
    iget-object v0, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    iget-object v1, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    iget-object v1, v1, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v1}, Lcom/fonts/rainbow/HTextView;->getLayout()Landroid/text/Layout;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/text/Layout;->getLineLeft(I)F

    move-result v1

    iput v1, v0, Lcom/fonts/rainbow/HText;->oldStartX:F

    .line 56
    iget-object v0, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    invoke-virtual {v0}, Lcom/fonts/rainbow/HText;->initVariables()V

    .line 57
    return-void

    .line 50
    :cond_4c
    iget-object v0, p0, Lcom/fonts/rainbow/HText$1;->this$0:Lcom/fonts/rainbow/HText;

    iget-object v0, v0, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v0}, Lcom/fonts/rainbow/HTextView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    goto :goto_11
.end method
