.class public interface abstract Lcom/fonts/rainbow/IHText;
.super Ljava/lang/Object;
.source "IHText.java"


# virtual methods
.method public abstract animateText(Ljava/lang/CharSequence;)V
.end method

.method public abstract init(Lcom/fonts/rainbow/HTextView;Landroid/util/AttributeSet;I)V
.end method

.method public abstract onDraw(Landroid/graphics/Canvas;)V
.end method
