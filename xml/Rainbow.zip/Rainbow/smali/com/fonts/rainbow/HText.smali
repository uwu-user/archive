.class public abstract Lcom/fonts/rainbow/HText;
.super Ljava/lang/Object;
.source "HText.java"

# interfaces
.implements Lcom/fonts/rainbow/IHText;


# instance fields
.field protected gapList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field protected mHTextView:Lcom/fonts/rainbow/HTextView;

.field protected mHeight:I

.field protected mOldPaint:Landroid/text/TextPaint;

.field protected mOldText:Ljava/lang/CharSequence;

.field protected mPaint:Landroid/text/TextPaint;

.field protected mText:Ljava/lang/CharSequence;

.field protected mTextSize:F

.field protected mWidth:I

.field protected oldGapList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field protected oldStartX:F

.field protected progress:F


# direct methods
.method public constructor <init>()V
    .registers 2

    .prologue
    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/fonts/rainbow/HText;->gapList:Ljava/util/List;

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/fonts/rainbow/HText;->oldGapList:Ljava/util/List;

    .line 27
    const/4 v0, 0x0

    iput v0, p0, Lcom/fonts/rainbow/HText;->oldStartX:F

    return-void
.end method

.method private prepareAnimate()V
    .registers 5

    .prologue
    .line 63
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v1}, Lcom/fonts/rainbow/HTextView;->getTextSize()F

    move-result v1

    iput v1, p0, Lcom/fonts/rainbow/HText;->mTextSize:F

    .line 64
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->mPaint:Landroid/text/TextPaint;

    iget v2, p0, Lcom/fonts/rainbow/HText;->mTextSize:F

    invoke-virtual {v1, v2}, Landroid/text/TextPaint;->setTextSize(F)V

    .line 65
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->mPaint:Landroid/text/TextPaint;

    iget-object v2, p0, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v2}, Lcom/fonts/rainbow/HTextView;->getCurrentTextColor()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/text/TextPaint;->setColor(I)V

    .line 66
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->mPaint:Landroid/text/TextPaint;

    iget-object v2, p0, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v2}, Lcom/fonts/rainbow/HTextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/text/TextPaint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 67
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->gapList:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 68
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_2b
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->mText:Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-ge v0, v1, :cond_4f

    .line 69
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->gapList:Ljava/util/List;

    iget-object v2, p0, Lcom/fonts/rainbow/HText;->mPaint:Landroid/text/TextPaint;

    iget-object v3, p0, Lcom/fonts/rainbow/HText;->mText:Ljava/lang/CharSequence;

    invoke-interface {v3, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/text/TextPaint;->measureText(Ljava/lang/String;)F

    move-result v2

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 68
    add-int/lit8 v0, v0, 0x1

    goto :goto_2b

    .line 71
    :cond_4f
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->mOldPaint:Landroid/text/TextPaint;

    iget v2, p0, Lcom/fonts/rainbow/HText;->mTextSize:F

    invoke-virtual {v1, v2}, Landroid/text/TextPaint;->setTextSize(F)V

    .line 72
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->mOldPaint:Landroid/text/TextPaint;

    iget-object v2, p0, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v2}, Lcom/fonts/rainbow/HTextView;->getCurrentTextColor()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/text/TextPaint;->setColor(I)V

    .line 73
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->mOldPaint:Landroid/text/TextPaint;

    iget-object v2, p0, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v2}, Lcom/fonts/rainbow/HTextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/text/TextPaint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 74
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->oldGapList:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 75
    const/4 v0, 0x0

    :goto_72
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->mOldText:Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-ge v0, v1, :cond_96

    .line 76
    iget-object v1, p0, Lcom/fonts/rainbow/HText;->oldGapList:Ljava/util/List;

    iget-object v2, p0, Lcom/fonts/rainbow/HText;->mOldPaint:Landroid/text/TextPaint;

    iget-object v3, p0, Lcom/fonts/rainbow/HText;->mOldText:Ljava/lang/CharSequence;

    invoke-interface {v3, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/text/TextPaint;->measureText(Ljava/lang/String;)F

    move-result v2

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 75
    add-int/lit8 v0, v0, 0x1

    goto :goto_72

    .line 78
    :cond_96
    return-void
.end method


# virtual methods
.method protected abstract animatePrepare(Ljava/lang/CharSequence;)V
.end method

.method protected abstract animateStart(Ljava/lang/CharSequence;)V
.end method

.method public animateText(Ljava/lang/CharSequence;)V
    .registers 3
    .param p1, "text"    # Ljava/lang/CharSequence;

    .prologue
    .line 82
    iget-object v0, p0, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v0, p1}, Lcom/fonts/rainbow/HTextView;->setText(Ljava/lang/CharSequence;)V

    .line 83
    iget-object v0, p0, Lcom/fonts/rainbow/HText;->mText:Ljava/lang/CharSequence;

    iput-object v0, p0, Lcom/fonts/rainbow/HText;->mOldText:Ljava/lang/CharSequence;

    .line 84
    iput-object p1, p0, Lcom/fonts/rainbow/HText;->mText:Ljava/lang/CharSequence;

    .line 85
    invoke-direct {p0}, Lcom/fonts/rainbow/HText;->prepareAnimate()V

    .line 86
    invoke-virtual {p0, p1}, Lcom/fonts/rainbow/HText;->animatePrepare(Ljava/lang/CharSequence;)V

    .line 87
    invoke-virtual {p0, p1}, Lcom/fonts/rainbow/HText;->animateStart(Ljava/lang/CharSequence;)V

    .line 88
    return-void
.end method

.method protected abstract drawFrame(Landroid/graphics/Canvas;)V
.end method

.method public init(Lcom/fonts/rainbow/HTextView;Landroid/util/AttributeSet;I)V
    .registers 6
    .param p1, "hTextView"    # Lcom/fonts/rainbow/HTextView;
    .param p2, "attrs"    # Landroid/util/AttributeSet;
    .param p3, "defStyle"    # I

    .prologue
    .line 36
    iput-object p1, p0, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    .line 37
    const-string v0, ""

    iput-object v0, p0, Lcom/fonts/rainbow/HText;->mOldText:Ljava/lang/CharSequence;

    .line 38
    invoke-virtual {p1}, Lcom/fonts/rainbow/HTextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    iput-object v0, p0, Lcom/fonts/rainbow/HText;->mText:Ljava/lang/CharSequence;

    .line 39
    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Lcom/fonts/rainbow/HText;->progress:F

    .line 41
    new-instance v0, Landroid/text/TextPaint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/text/TextPaint;-><init>(I)V

    iput-object v0, p0, Lcom/fonts/rainbow/HText;->mPaint:Landroid/text/TextPaint;

    .line 42
    new-instance v0, Landroid/text/TextPaint;

    iget-object v1, p0, Lcom/fonts/rainbow/HText;->mPaint:Landroid/text/TextPaint;

    invoke-direct {v0, v1}, Landroid/text/TextPaint;-><init>(Landroid/graphics/Paint;)V

    iput-object v0, p0, Lcom/fonts/rainbow/HText;->mOldPaint:Landroid/text/TextPaint;

    .line 44
    iget-object v0, p0, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v0}, Lcom/fonts/rainbow/HTextView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    new-instance v1, Lcom/fonts/rainbow/HText$1;

    invoke-direct {v1, p0}, Lcom/fonts/rainbow/HText$1;-><init>(Lcom/fonts/rainbow/HText;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 59
    invoke-direct {p0}, Lcom/fonts/rainbow/HText;->prepareAnimate()V

    .line 60
    return-void
.end method

.method protected abstract initVariables()V
.end method

.method public onDraw(Landroid/graphics/Canvas;)V
    .registers 2
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .prologue
    .line 92
    invoke-virtual {p0, p1}, Lcom/fonts/rainbow/HText;->drawFrame(Landroid/graphics/Canvas;)V

    .line 93
    return-void
.end method

.method public setProgress(F)V
    .registers 3
    .param p1, "progress"    # F

    .prologue
    .line 30
    iput p1, p0, Lcom/fonts/rainbow/HText;->progress:F

    .line 31
    iget-object v0, p0, Lcom/fonts/rainbow/HText;->mHTextView:Lcom/fonts/rainbow/HTextView;

    invoke-virtual {v0}, Lcom/fonts/rainbow/HTextView;->invalidate()V

    .line 32
    return-void
.end method
