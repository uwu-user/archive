.class public Lcom/fonts/rainbow/CharacterUtils;
.super Ljava/lang/Object;
.source "CharacterUtils.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static diff(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/util/List;
    .registers 9
    .param p0, "oldText"    # Ljava/lang/CharSequence;
    .param p1, "newText"    # Ljava/lang/CharSequence;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            "Ljava/lang/CharSequence;",
            ")",
            "Ljava/util/List",
            "<",
            "Lcom/fonts/rainbow/CharacterDiffResult;",
            ">;"
        }
    .end annotation

    .prologue
    .line 16
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 17
    .local v2, "differentList":Ljava/util/List;, "Ljava/util/List<Lcom/fonts/rainbow/CharacterDiffResult;>;"
    new-instance v5, Ljava/util/HashSet;

    invoke-direct {v5}, Ljava/util/HashSet;-><init>()V

    .line 19
    .local v5, "skip":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/Integer;>;"
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_b
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-ge v3, v6, :cond_47

    .line 20
    invoke-interface {p0, v3}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    .line 21
    .local v0, "c":C
    const/4 v4, 0x0

    .local v4, "j":I
    :goto_16
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-ge v4, v6, :cond_41

    .line 22
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_44

    invoke-interface {p1, v4}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v6

    if-ne v0, v6, :cond_44

    .line 23
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 24
    new-instance v1, Lcom/fonts/rainbow/CharacterDiffResult;

    invoke-direct {v1}, Lcom/fonts/rainbow/CharacterDiffResult;-><init>()V

    .line 25
    .local v1, "different":Lcom/fonts/rainbow/CharacterDiffResult;
    iput-char v0, v1, Lcom/fonts/rainbow/CharacterDiffResult;->c:C

    .line 26
    iput v3, v1, Lcom/fonts/rainbow/CharacterDiffResult;->fromIndex:I

    .line 27
    iput v4, v1, Lcom/fonts/rainbow/CharacterDiffResult;->moveIndex:I

    .line 28
    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 19
    .end local v1    # "different":Lcom/fonts/rainbow/CharacterDiffResult;
    :cond_41
    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    .line 21
    :cond_44
    add-int/lit8 v4, v4, 0x1

    goto :goto_16

    .line 33
    .end local v0    # "c":C
    .end local v4    # "j":I
    :cond_47
    return-object v2
.end method

.method public static getOffset(IIFFFLjava/util/List;Ljava/util/List;)F
    .registers 11
    .param p0, "from"    # I
    .param p1, "move"    # I
    .param p2, "progress"    # F
    .param p3, "startX"    # F
    .param p4, "oldStartX"    # F
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IIFFF",
            "Ljava/util/List",
            "<",
            "Ljava/lang/Float;",
            ">;",
            "Ljava/util/List",
            "<",
            "Ljava/lang/Float;",
            ">;)F"
        }
    .end annotation

    .prologue
    .line 58
    .local p5, "gaps":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Float;>;"
    .local p6, "oldGaps":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Float;>;"
    move v1, p3

    .line 59
    .local v1, "dist":F
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_2
    if-ge v2, p1, :cond_12

    .line 60
    invoke-interface {p5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Float;

    invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F

    move-result v3

    add-float/2addr v1, v3

    .line 59
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    .line 63
    :cond_12
    move v0, p4

    .line 64
    .local v0, "cur":F
    const/4 v2, 0x0

    :goto_14
    if-ge v2, p0, :cond_24

    .line 65
    invoke-interface {p6, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Float;

    invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F

    move-result v3

    add-float/2addr v0, v3

    .line 64
    add-int/lit8 v2, v2, 0x1

    goto :goto_14

    .line 68
    :cond_24
    sub-float v3, v1, v0

    mul-float/2addr v3, p2

    add-float/2addr v3, v0

    return v3
.end method

.method public static needMove(ILjava/util/List;)I
    .registers 5
    .param p0, "index"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List",
            "<",
            "Lcom/fonts/rainbow/CharacterDiffResult;",
            ">;)I"
        }
    .end annotation

    .prologue
    .line 37
    .local p1, "differentList":Ljava/util/List;, "Ljava/util/List<Lcom/fonts/rainbow/CharacterDiffResult;>;"
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_17

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/fonts/rainbow/CharacterDiffResult;

    .line 38
    .local v0, "different":Lcom/fonts/rainbow/CharacterDiffResult;
    iget v2, v0, Lcom/fonts/rainbow/CharacterDiffResult;->fromIndex:I

    if-ne v2, p0, :cond_4

    .line 39
    iget v1, v0, Lcom/fonts/rainbow/CharacterDiffResult;->moveIndex:I

    .line 42
    .end local v0    # "different":Lcom/fonts/rainbow/CharacterDiffResult;
    :goto_16
    return v1

    :cond_17
    const/4 v1, -0x1

    goto :goto_16
.end method

.method public static stayHere(ILjava/util/List;)Z
    .registers 5
    .param p0, "index"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List",
            "<",
            "Lcom/fonts/rainbow/CharacterDiffResult;",
            ">;)Z"
        }
    .end annotation

    .prologue
    .line 46
    .local p1, "differentList":Ljava/util/List;, "Ljava/util/List<Lcom/fonts/rainbow/CharacterDiffResult;>;"
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_16

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/fonts/rainbow/CharacterDiffResult;

    .line 47
    .local v0, "different":Lcom/fonts/rainbow/CharacterDiffResult;
    iget v2, v0, Lcom/fonts/rainbow/CharacterDiffResult;->moveIndex:I

    if-ne v2, p0, :cond_4

    .line 48
    const/4 v1, 0x1

    .line 51
    .end local v0    # "different":Lcom/fonts/rainbow/CharacterDiffResult;
    :goto_15
    return v1

    :cond_16
    const/4 v1, 0x0

    goto :goto_15
.end method
