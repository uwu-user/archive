.class public Lcom/fonts/rainbow/TextView;
.super Lcom/fonts/rainbow/HTextView;
.source "TextView.java"


# instance fields
.field private colorSpace:F

.field private colorSpeed:F

.field private colors:[I

.field private mLinearGradient:Landroid/graphics/LinearGradient;

.field private mMatrix:Landroid/graphics/Matrix;

.field private mTranslate:F


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 29
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/fonts/rainbow/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 30
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;

    .prologue
    .line 33
    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, v0}, Lcom/fonts/rainbow/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 34
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;
    .param p3, "defStyleAttr"    # I

    .prologue
    .line 37
    invoke-direct {p0, p1, p2, p3}, Lcom/fonts/rainbow/HTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 25
    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_10

    iput-object v0, p0, Lcom/fonts/rainbow/TextView;->colors:[I

    .line 38
    invoke-direct {p0, p2, p3}, Lcom/fonts/rainbow/TextView;->init(Landroid/util/AttributeSet;I)V

    .line 39
    return-void

    .line 25
    nop

    :array_10
    .array-data 4
        -0xd4de
        -0x80de
        -0x1200de
        -0xdd00de
        -0xdd0b01
        -0xddc601
        -0xabff09
    .end array-data
.end method

.method private init(Landroid/util/AttributeSet;I)V
    .registers 6
    .param p1, "attrs"    # Landroid/util/AttributeSet;
    .param p2, "defStyleAttr"    # I

    .prologue
    .line 43
    invoke-virtual {p0}, Lcom/fonts/rainbow/TextView;->getContext()Landroid/content/Context;

    move-result-object v1

    sget-object v2, Lcom/fonts/rainbow/R$styleable;->TextView:[I

    invoke-virtual {v1, p1, v2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v0

    .line 44
    .local v0, "typedArray":Landroid/content/res/TypedArray;
    sget v1, Lcom/fonts/rainbow/R$styleable;->TextView_colorSpace:I

    const/high16 v2, 0x43160000    # 150.0f

    invoke-static {v2}, Lcom/fonts/rainbow/DisplayUtils;->dp2px(F)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v1

    iput v1, p0, Lcom/fonts/rainbow/TextView;->colorSpace:F

    .line 45
    sget v1, Lcom/fonts/rainbow/R$styleable;->TextView_colorSpeed:I

    const/high16 v2, 0x40a00000    # 5.0f

    invoke-static {v2}, Lcom/fonts/rainbow/DisplayUtils;->dp2px(F)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v1

    iput v1, p0, Lcom/fonts/rainbow/TextView;->colorSpeed:F

    .line 46
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 48
    new-instance v1, Landroid/graphics/Matrix;

    invoke-direct {v1}, Landroid/graphics/Matrix;-><init>()V

    iput-object v1, p0, Lcom/fonts/rainbow/TextView;->mMatrix:Landroid/graphics/Matrix;

    .line 49
    invoke-direct {p0}, Lcom/fonts/rainbow/TextView;->initPaint()V

    .line 50
    return-void
.end method

.method private initPaint()V
    .registers 9

    .prologue
    const/4 v1, 0x0

    .line 74
    new-instance v0, Landroid/graphics/LinearGradient;

    iget v3, p0, Lcom/fonts/rainbow/TextView;->colorSpace:F

    iget-object v5, p0, Lcom/fonts/rainbow/TextView;->colors:[I

    const/4 v6, 0x0

    sget-object v7, Landroid/graphics/Shader$TileMode;->MIRROR:Landroid/graphics/Shader$TileMode;

    move v2, v1

    move v4, v1

    invoke-direct/range {v0 .. v7}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    iput-object v0, p0, Lcom/fonts/rainbow/TextView;->mLinearGradient:Landroid/graphics/LinearGradient;

    .line 75
    invoke-virtual {p0}, Lcom/fonts/rainbow/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v0

    iget-object v1, p0, Lcom/fonts/rainbow/TextView;->mLinearGradient:Landroid/graphics/LinearGradient;

    invoke-virtual {v0, v1}, Landroid/text/TextPaint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 76
    return-void
.end method


# virtual methods
.method public animateText(Ljava/lang/CharSequence;)V
    .registers 2
    .param p1, "text"    # Ljava/lang/CharSequence;

    .prologue
    .line 84
    invoke-virtual {p0, p1}, Lcom/fonts/rainbow/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 85
    return-void
.end method

.method public getColorSpace()F
    .registers 2

    .prologue
    .line 53
    iget v0, p0, Lcom/fonts/rainbow/TextView;->colorSpace:F

    return v0
.end method

.method public getColorSpeed()F
    .registers 2

    .prologue
    .line 61
    iget v0, p0, Lcom/fonts/rainbow/TextView;->colorSpeed:F

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 5
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .prologue
    .line 89
    iget-object v0, p0, Lcom/fonts/rainbow/TextView;->mMatrix:Landroid/graphics/Matrix;

    if-nez v0, :cond_b

    .line 90
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, Lcom/fonts/rainbow/TextView;->mMatrix:Landroid/graphics/Matrix;

    .line 92
    :cond_b
    iget v0, p0, Lcom/fonts/rainbow/TextView;->mTranslate:F

    iget v1, p0, Lcom/fonts/rainbow/TextView;->colorSpeed:F

    add-float/2addr v0, v1

    iput v0, p0, Lcom/fonts/rainbow/TextView;->mTranslate:F

    .line 93
    iget-object v0, p0, Lcom/fonts/rainbow/TextView;->mMatrix:Landroid/graphics/Matrix;

    iget v1, p0, Lcom/fonts/rainbow/TextView;->mTranslate:F

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->setTranslate(FF)V

    .line 94
    iget-object v0, p0, Lcom/fonts/rainbow/TextView;->mLinearGradient:Landroid/graphics/LinearGradient;

    iget-object v1, p0, Lcom/fonts/rainbow/TextView;->mMatrix:Landroid/graphics/Matrix;

    invoke-virtual {v0, v1}, Landroid/graphics/LinearGradient;->setLocalMatrix(Landroid/graphics/Matrix;)V

    .line 95
    invoke-super {p0, p1}, Lcom/fonts/rainbow/HTextView;->onDraw(Landroid/graphics/Canvas;)V

    .line 96
    const-wide/16 v0, 0x64

    invoke-virtual {p0, v0, v1}, Lcom/fonts/rainbow/TextView;->postInvalidateDelayed(J)V

    .line 97
    return-void
.end method

.method public setColorSpace(F)V
    .registers 2
    .param p1, "colorSpace"    # F

    .prologue
    .line 57
    iput p1, p0, Lcom/fonts/rainbow/TextView;->colorSpace:F

    .line 58
    return-void
.end method

.method public setColorSpeed(F)V
    .registers 2
    .param p1, "colorSpeed"    # F

    .prologue
    .line 65
    iput p1, p0, Lcom/fonts/rainbow/TextView;->colorSpeed:F

    .line 66
    return-void
.end method

.method public varargs setColors([I)V
    .registers 2
    .param p1, "colors"    # [I

    .prologue
    .line 69
    iput-object p1, p0, Lcom/fonts/rainbow/TextView;->colors:[I

    .line 70
    invoke-direct {p0}, Lcom/fonts/rainbow/TextView;->initPaint()V

    .line 71
    return-void
.end method

.method public setProgress(F)V
    .registers 2
    .param p1, "progress"    # F

    .prologue
    .line 80
    return-void
.end method
