.class public final Lcom/card/cardview/R$interpolator;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/card/cardview/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "interpolator"
.end annotation


# static fields
.field public static final mtrl_fast_out_linear_in:I = 0x7f070000

.field public static final mtrl_fast_out_slow_in:I = 0x7f070001

.field public static final mtrl_linear:I = 0x7f070002

.field public static final mtrl_linear_out_slow_in:I = 0x7f070003


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 4773
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
