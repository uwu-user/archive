.class public final Lcom/card/cardview/R$dimen;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/card/cardview/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "dimen"
.end annotation


# static fields
.field public static final abc_action_bar_content_inset_material:I = 0x7f080086

.field public static final abc_action_bar_content_inset_with_nav:I = 0x7f080087

.field public static final abc_action_bar_default_height_material:I = 0x7f08007c

.field public static final abc_action_bar_default_padding_end_material:I = 0x7f080088

.field public static final abc_action_bar_default_padding_start_material:I = 0x7f080089

.field public static final abc_action_bar_elevation_material:I = 0x7f08008b

.field public static final abc_action_bar_icon_vertical_padding_material:I = 0x7f08008c

.field public static final abc_action_bar_overflow_padding_end_material:I = 0x7f08008d

.field public static final abc_action_bar_overflow_padding_start_material:I = 0x7f08008e

.field public static final abc_action_bar_stacked_max_height:I = 0x7f08008f

.field public static final abc_action_bar_stacked_tab_max_width:I = 0x7f080090

.field public static final abc_action_bar_subtitle_bottom_margin_material:I = 0x7f080091

.field public static final abc_action_bar_subtitle_top_margin_material:I = 0x7f080092

.field public static final abc_action_button_min_height_material:I = 0x7f080093

.field public static final abc_action_button_min_width_material:I = 0x7f080094

.field public static final abc_action_button_min_width_overflow_material:I = 0x7f080095

.field public static final abc_alert_dialog_button_bar_height:I = 0x7f08007b

.field public static final abc_alert_dialog_button_dimen:I = 0x7f080096

.field public static final abc_button_inset_horizontal_material:I = 0x7f080097

.field public static final abc_button_inset_vertical_material:I = 0x7f080098

.field public static final abc_button_padding_horizontal_material:I = 0x7f080099

.field public static final abc_button_padding_vertical_material:I = 0x7f08009a

.field public static final abc_cascading_menus_min_smallest_width:I = 0x7f08009b

.field public static final abc_config_prefDialogWidth:I = 0x7f08007f

.field public static final abc_control_corner_material:I = 0x7f08009c

.field public static final abc_control_inset_material:I = 0x7f08009d

.field public static final abc_control_padding_material:I = 0x7f08009e

.field public static final abc_dialog_corner_radius_material:I = 0x7f08009f

.field public static final abc_dialog_fixed_height_major:I = 0x7f080080

.field public static final abc_dialog_fixed_height_minor:I = 0x7f080081

.field public static final abc_dialog_fixed_width_major:I = 0x7f080082

.field public static final abc_dialog_fixed_width_minor:I = 0x7f080083

.field public static final abc_dialog_list_padding_bottom_no_buttons:I = 0x7f0800a0

.field public static final abc_dialog_list_padding_top_no_title:I = 0x7f0800a1

.field public static final abc_dialog_min_width_major:I = 0x7f080084

.field public static final abc_dialog_min_width_minor:I = 0x7f080085

.field public static final abc_dialog_padding_material:I = 0x7f0800a2

.field public static final abc_dialog_padding_top_material:I = 0x7f0800a3

.field public static final abc_dialog_title_divider_material:I = 0x7f0800a4

.field public static final abc_disabled_alpha_material_dark:I = 0x7f0800a5

.field public static final abc_disabled_alpha_material_light:I = 0x7f0800a6

.field public static final abc_dropdownitem_icon_width:I = 0x7f0800a7

.field public static final abc_dropdownitem_text_padding_left:I = 0x7f0800a8

.field public static final abc_dropdownitem_text_padding_right:I = 0x7f0800a9

.field public static final abc_edit_text_inset_bottom_material:I = 0x7f0800aa

.field public static final abc_edit_text_inset_horizontal_material:I = 0x7f0800ab

.field public static final abc_edit_text_inset_top_material:I = 0x7f0800ac

.field public static final abc_floating_window_z:I = 0x7f0800ad

.field public static final abc_list_item_padding_horizontal_material:I = 0x7f0800ae

.field public static final abc_panel_menu_list_width:I = 0x7f0800af

.field public static final abc_progress_bar_height_material:I = 0x7f0800b0

.field public static final abc_search_view_preferred_height:I = 0x7f0800b1

.field public static final abc_search_view_preferred_width:I = 0x7f0800b2

.field public static final abc_seekbar_track_background_height_material:I = 0x7f0800b3

.field public static final abc_seekbar_track_progress_height_material:I = 0x7f0800b4

.field public static final abc_select_dialog_padding_start_material:I = 0x7f0800b5

.field public static final abc_switch_padding:I = 0x7f08008a

.field public static final abc_text_size_body_1_material:I = 0x7f0800b6

.field public static final abc_text_size_body_2_material:I = 0x7f0800b7

.field public static final abc_text_size_button_material:I = 0x7f0800b8

.field public static final abc_text_size_caption_material:I = 0x7f0800b9

.field public static final abc_text_size_display_1_material:I = 0x7f0800ba

.field public static final abc_text_size_display_2_material:I = 0x7f0800bb

.field public static final abc_text_size_display_3_material:I = 0x7f0800bc

.field public static final abc_text_size_display_4_material:I = 0x7f0800bd

.field public static final abc_text_size_headline_material:I = 0x7f0800be

.field public static final abc_text_size_large_material:I = 0x7f0800bf

.field public static final abc_text_size_medium_material:I = 0x7f0800c0

.field public static final abc_text_size_menu_header_material:I = 0x7f0800c1

.field public static final abc_text_size_menu_material:I = 0x7f0800c2

.field public static final abc_text_size_small_material:I = 0x7f0800c3

.field public static final abc_text_size_subhead_material:I = 0x7f0800c4

.field public static final abc_text_size_subtitle_material_toolbar:I = 0x7f08007d

.field public static final abc_text_size_title_material:I = 0x7f0800c5

.field public static final abc_text_size_title_material_toolbar:I = 0x7f08007e

.field public static final cardview_compat_inset_shadow:I = 0x7f080006

.field public static final cardview_default_elevation:I = 0x7f080007

.field public static final cardview_default_radius:I = 0x7f080008

.field public static final compat_button_inset_horizontal_material:I = 0x7f080069

.field public static final compat_button_inset_vertical_material:I = 0x7f08006a

.field public static final compat_button_padding_horizontal_material:I = 0x7f08006b

.field public static final compat_button_padding_vertical_material:I = 0x7f08006c

.field public static final compat_control_corner_material:I = 0x7f08006d

.field public static final compat_notification_large_icon_max_height:I = 0x7f08006e

.field public static final compat_notification_large_icon_max_width:I = 0x7f08006f

.field public static final design_appbar_elevation:I = 0x7f080011

.field public static final design_bottom_navigation_active_item_max_width:I = 0x7f080012

.field public static final design_bottom_navigation_active_item_min_width:I = 0x7f080013

.field public static final design_bottom_navigation_active_text_size:I = 0x7f080014

.field public static final design_bottom_navigation_elevation:I = 0x7f080015

.field public static final design_bottom_navigation_height:I = 0x7f080016

.field public static final design_bottom_navigation_icon_size:I = 0x7f080017

.field public static final design_bottom_navigation_item_max_width:I = 0x7f080018

.field public static final design_bottom_navigation_item_min_width:I = 0x7f080019

.field public static final design_bottom_navigation_margin:I = 0x7f08001a

.field public static final design_bottom_navigation_shadow_height:I = 0x7f08001b

.field public static final design_bottom_navigation_text_size:I = 0x7f08001c

.field public static final design_bottom_sheet_modal_elevation:I = 0x7f08001d

.field public static final design_bottom_sheet_peek_height_min:I = 0x7f08001e

.field public static final design_fab_border_width:I = 0x7f08001f

.field public static final design_fab_elevation:I = 0x7f080020

.field public static final design_fab_image_size:I = 0x7f080021

.field public static final design_fab_size_mini:I = 0x7f080022

.field public static final design_fab_size_normal:I = 0x7f080023

.field public static final design_fab_translation_z_hovered_focused:I = 0x7f080024

.field public static final design_fab_translation_z_pressed:I = 0x7f080025

.field public static final design_navigation_elevation:I = 0x7f080026

.field public static final design_navigation_icon_padding:I = 0x7f080027

.field public static final design_navigation_icon_size:I = 0x7f080028

.field public static final design_navigation_item_horizontal_padding:I = 0x7f080029

.field public static final design_navigation_item_icon_padding:I = 0x7f08002a

.field public static final design_navigation_max_width:I = 0x7f080009

.field public static final design_navigation_padding_bottom:I = 0x7f08002b

.field public static final design_navigation_separator_vertical_padding:I = 0x7f08002c

.field public static final design_snackbar_action_inline_max_width:I = 0x7f08000a

.field public static final design_snackbar_background_corner_radius:I = 0x7f08000b

.field public static final design_snackbar_elevation:I = 0x7f08002d

.field public static final design_snackbar_extra_spacing_horizontal:I = 0x7f08000c

.field public static final design_snackbar_max_width:I = 0x7f08000d

.field public static final design_snackbar_min_width:I = 0x7f08000e

.field public static final design_snackbar_padding_horizontal:I = 0x7f08002e

.field public static final design_snackbar_padding_vertical:I = 0x7f08002f

.field public static final design_snackbar_padding_vertical_2lines:I = 0x7f08000f

.field public static final design_snackbar_text_size:I = 0x7f080030

.field public static final design_tab_max_width:I = 0x7f080031

.field public static final design_tab_scrollable_min_width:I = 0x7f080010

.field public static final design_tab_text_size:I = 0x7f080032

.field public static final design_tab_text_size_2line:I = 0x7f080033

.field public static final design_textinput_caption_translate_y:I = 0x7f080034

.field public static final disabled_alpha_material_dark:I = 0x7f0800c6

.field public static final disabled_alpha_material_light:I = 0x7f0800c7

.field public static final fastscroll_default_thickness:I = 0x7f080000

.field public static final fastscroll_margin:I = 0x7f080001

.field public static final fastscroll_minimum_range:I = 0x7f080002

.field public static final highlight_alpha_material_colored:I = 0x7f0800c8

.field public static final highlight_alpha_material_dark:I = 0x7f0800c9

.field public static final highlight_alpha_material_light:I = 0x7f0800ca

.field public static final hint_alpha_material_dark:I = 0x7f0800cb

.field public static final hint_alpha_material_light:I = 0x7f0800cc

.field public static final hint_pressed_alpha_material_dark:I = 0x7f0800cd

.field public static final hint_pressed_alpha_material_light:I = 0x7f0800ce

.field public static final item_touch_helper_max_drag_scroll_per_frame:I = 0x7f080003

.field public static final item_touch_helper_swipe_escape_max_velocity:I = 0x7f080004

.field public static final item_touch_helper_swipe_escape_velocity:I = 0x7f080005

.field public static final mtrl_bottomappbar_fabOffsetEndMode:I = 0x7f080035

.field public static final mtrl_bottomappbar_fab_cradle_margin:I = 0x7f080036

.field public static final mtrl_bottomappbar_fab_cradle_rounded_corner_radius:I = 0x7f080037

.field public static final mtrl_bottomappbar_fab_cradle_vertical_offset:I = 0x7f080038

.field public static final mtrl_bottomappbar_height:I = 0x7f080039

.field public static final mtrl_btn_corner_radius:I = 0x7f08003a

.field public static final mtrl_btn_dialog_btn_min_width:I = 0x7f08003b

.field public static final mtrl_btn_disabled_elevation:I = 0x7f08003c

.field public static final mtrl_btn_disabled_z:I = 0x7f08003d

.field public static final mtrl_btn_elevation:I = 0x7f08003e

.field public static final mtrl_btn_focused_z:I = 0x7f08003f

.field public static final mtrl_btn_hovered_z:I = 0x7f080040

.field public static final mtrl_btn_icon_btn_padding_left:I = 0x7f080041

.field public static final mtrl_btn_icon_padding:I = 0x7f080042

.field public static final mtrl_btn_inset:I = 0x7f080043

.field public static final mtrl_btn_letter_spacing:I = 0x7f080044

.field public static final mtrl_btn_padding_bottom:I = 0x7f080045

.field public static final mtrl_btn_padding_left:I = 0x7f080046

.field public static final mtrl_btn_padding_right:I = 0x7f080047

.field public static final mtrl_btn_padding_top:I = 0x7f080048

.field public static final mtrl_btn_pressed_z:I = 0x7f080049

.field public static final mtrl_btn_stroke_size:I = 0x7f08004a

.field public static final mtrl_btn_text_btn_icon_padding:I = 0x7f08004b

.field public static final mtrl_btn_text_btn_padding_left:I = 0x7f08004c

.field public static final mtrl_btn_text_btn_padding_right:I = 0x7f08004d

.field public static final mtrl_btn_text_size:I = 0x7f08004e

.field public static final mtrl_btn_z:I = 0x7f08004f

.field public static final mtrl_card_elevation:I = 0x7f080050

.field public static final mtrl_card_spacing:I = 0x7f080051

.field public static final mtrl_chip_pressed_translation_z:I = 0x7f080052

.field public static final mtrl_chip_text_size:I = 0x7f080053

.field public static final mtrl_fab_elevation:I = 0x7f080054

.field public static final mtrl_fab_translation_z_hovered_focused:I = 0x7f080055

.field public static final mtrl_fab_translation_z_pressed:I = 0x7f080056

.field public static final mtrl_navigation_elevation:I = 0x7f080057

.field public static final mtrl_navigation_item_horizontal_padding:I = 0x7f080058

.field public static final mtrl_navigation_item_icon_padding:I = 0x7f080059

.field public static final mtrl_snackbar_background_corner_radius:I = 0x7f08005a

.field public static final mtrl_snackbar_margin:I = 0x7f08005b

.field public static final mtrl_textinput_box_bottom_offset:I = 0x7f08005c

.field public static final mtrl_textinput_box_corner_radius_medium:I = 0x7f08005d

.field public static final mtrl_textinput_box_corner_radius_small:I = 0x7f08005e

.field public static final mtrl_textinput_box_label_cutout_padding:I = 0x7f08005f

.field public static final mtrl_textinput_box_padding_end:I = 0x7f080060

.field public static final mtrl_textinput_box_stroke_width_default:I = 0x7f080061

.field public static final mtrl_textinput_box_stroke_width_focused:I = 0x7f080062

.field public static final mtrl_textinput_outline_box_expanded_padding:I = 0x7f080063

.field public static final mtrl_toolbar_default_height:I = 0x7f080064

.field public static final notification_action_icon_size:I = 0x7f080070

.field public static final notification_action_text_size:I = 0x7f080071

.field public static final notification_big_circle_margin:I = 0x7f080072

.field public static final notification_content_margin_start:I = 0x7f080066

.field public static final notification_large_icon_height:I = 0x7f080073

.field public static final notification_large_icon_width:I = 0x7f080074

.field public static final notification_main_column_padding_top:I = 0x7f080067

.field public static final notification_media_narrow_margin:I = 0x7f080068

.field public static final notification_right_icon_size:I = 0x7f080075

.field public static final notification_right_side_padding_top:I = 0x7f080065

.field public static final notification_small_icon_background_padding:I = 0x7f080076

.field public static final notification_small_icon_size_as_large:I = 0x7f080077

.field public static final notification_subtext_size:I = 0x7f080078

.field public static final notification_top_pad:I = 0x7f080079

.field public static final notification_top_pad_large_text:I = 0x7f08007a

.field public static final tooltip_corner_radius:I = 0x7f0800cf

.field public static final tooltip_horizontal_padding:I = 0x7f0800d0

.field public static final tooltip_margin:I = 0x7f0800d1

.field public static final tooltip_precise_anchor_extra_offset:I = 0x7f0800d2

.field public static final tooltip_precise_anchor_threshold:I = 0x7f0800d3

.field public static final tooltip_vertical_padding:I = 0x7f0800d4

.field public static final tooltip_y_offset_non_touch:I = 0x7f0800d5

.field public static final tooltip_y_offset_touch:I = 0x7f0800d6


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 4440
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
