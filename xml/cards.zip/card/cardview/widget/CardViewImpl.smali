.class interface abstract Lcom/card/cardview/widget/CardViewImpl;
.super Ljava/lang/Object;
.source "CardViewImpl.java"


# virtual methods
.method public abstract getBackgroundColor(Lcom/card/cardview/widget/CardViewDelegate;)Landroid/content/res/ColorStateList;
.end method

.method public abstract getElevation(Lcom/card/cardview/widget/CardViewDelegate;)F
.end method

.method public abstract getMaxElevation(Lcom/card/cardview/widget/CardViewDelegate;)F
.end method

.method public abstract getMinHeight(Lcom/card/cardview/widget/CardViewDelegate;)F
.end method

.method public abstract getMinWidth(Lcom/card/cardview/widget/CardViewDelegate;)F
.end method

.method public abstract getRadius(Lcom/card/cardview/widget/CardViewDelegate;)F
.end method

.method public abstract initStatic()V
.end method

.method public abstract initialize(Lcom/card/cardview/widget/CardViewDelegate;Landroid/content/Context;Landroid/content/res/ColorStateList;FFF)V
.end method

.method public abstract onCompatPaddingChanged(Lcom/card/cardview/widget/CardViewDelegate;)V
.end method

.method public abstract onPreventCornerOverlapChanged(Lcom/card/cardview/widget/CardViewDelegate;)V
.end method

.method public abstract setBackgroundColor(Lcom/card/cardview/widget/CardViewDelegate;Landroid/content/res/ColorStateList;)V
    .param p2    # Landroid/content/res/ColorStateList;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param
.end method

.method public abstract setElevation(Lcom/card/cardview/widget/CardViewDelegate;F)V
.end method

.method public abstract setMaxElevation(Lcom/card/cardview/widget/CardViewDelegate;F)V
.end method

.method public abstract setRadius(Lcom/card/cardview/widget/CardViewDelegate;F)V
.end method

.method public abstract updatePadding(Lcom/card/cardview/widget/CardViewDelegate;)V
.end method
