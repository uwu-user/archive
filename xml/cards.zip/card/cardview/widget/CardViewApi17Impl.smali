.class Lcom/card/cardview/widget/CardViewApi17Impl;
.super Lcom/card/cardview/widget/CardViewBaseImpl;
.source "CardViewApi17Impl.java"


# annotations
.annotation build Lcom/cardannotation/RequiresApi;
    value = 0x11
.end annotation


# direct methods
.method constructor <init>()V
    .registers 3

    .prologue
    .line 25
    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Lcom/card/cardview/widget/CardViewBaseImpl;-><init>()V

    return-void
.end method


# virtual methods
.method public initStatic()V
    .registers 6

    .prologue
    .line 29
    move-object v0, p0

    new-instance v1, Lcom/card/cardview/widget/CardViewApi17Impl$1;

    move-object v4, v1

    move-object v1, v4

    move-object v2, v4

    move-object v3, v0

    invoke-direct {v2, v3}, Lcom/card/cardview/widget/CardViewApi17Impl$1;-><init>(Lcom/card/cardview/widget/CardViewApi17Impl;)V

    sput-object v1, Lcom/card/cardview/widget/RoundRectDrawableWithShadow;->sRoundRectHelper:Lcom/card/cardview/widget/RoundRectDrawableWithShadow$RoundRectHelper;

    .line 37
    return-void
.end method
