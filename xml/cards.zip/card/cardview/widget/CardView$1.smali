.class Lcom/card/cardview/widget/CardView$1;
.super Ljava/lang/Object;
.source "CardView.java"

# interfaces
.implements Lcom/card/cardview/widget/CardViewDelegate;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/card/cardview/widget/CardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private mCardBackground:Landroid/graphics/drawable/Drawable;

.field final synthetic this$0:Lcom/card/cardview/widget/CardView;


# direct methods
.method constructor <init>(Lcom/card/cardview/widget/CardView;)V
    .registers 6

    .prologue
    .line 447
    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    move-object v3, v1

    iput-object v3, v2, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getCardBackground()Landroid/graphics/drawable/Drawable;
    .registers 3

    .prologue
    .line 485
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/cardview/widget/CardView$1;->mCardBackground:Landroid/graphics/drawable/Drawable;

    move-object v0, v1

    return-object v0
.end method

.method public getCardView()Landroid/view/View;
    .registers 3

    .prologue
    .line 490
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    move-object v0, v1

    return-object v0
.end method

.method public getPreventCornerOverlap()Z
    .registers 3

    .prologue
    .line 463
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    invoke-virtual {v1}, Lcom/card/cardview/widget/CardView;->getPreventCornerOverlap()Z

    move-result v1

    move v0, v1

    return v0
.end method

.method public getUseCompatPadding()Z
    .registers 3

    .prologue
    .line 458
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    invoke-virtual {v1}, Lcom/card/cardview/widget/CardView;->getUseCompatPadding()Z

    move-result v1

    move v0, v1

    return v0
.end method

.method public setCardBackground(Landroid/graphics/drawable/Drawable;)V
    .registers 6

    .prologue
    .line 452
    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    move-object v3, v1

    iput-object v3, v2, Lcom/card/cardview/widget/CardView$1;->mCardBackground:Landroid/graphics/drawable/Drawable;

    .line 453
    move-object v2, v0

    iget-object v2, v2, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    move-object v3, v1

    invoke-virtual {v2, v3}, Lcom/card/cardview/widget/CardView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 454
    return-void
.end method

.method public setMinWidthHeightInternal(II)V
    .registers 8

    .prologue
    .line 475
    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, v1

    move-object v4, v0

    iget-object v4, v4, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    iget v4, v4, Lcom/card/cardview/widget/CardView;->mUserSetMinWidth:I

    if-le v3, v4, :cond_12

    .line 476
    move-object v3, v0

    iget-object v3, v3, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    move v4, v1

    invoke-static {v3, v4}, Lcom/card/cardview/widget/CardView;->access$101(Lcom/card/cardview/widget/CardView;I)V

    .line 478
    :cond_12
    move v3, v2

    move-object v4, v0

    iget-object v4, v4, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    iget v4, v4, Lcom/card/cardview/widget/CardView;->mUserSetMinHeight:I

    if-le v3, v4, :cond_21

    .line 479
    move-object v3, v0

    iget-object v3, v3, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    move v4, v2

    invoke-static {v3, v4}, Lcom/card/cardview/widget/CardView;->access$201(Lcom/card/cardview/widget/CardView;I)V

    .line 481
    :cond_21
    return-void
.end method

.method public setShadowPadding(IIII)V
    .registers 16

    .prologue
    .line 468
    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, v0

    iget-object v5, v5, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    iget-object v5, v5, Lcom/card/cardview/widget/CardView;->mShadowBounds:Landroid/graphics/Rect;

    move v6, v1

    move v7, v2

    move v8, v3

    move v9, v4

    invoke-virtual {v5, v6, v7, v8, v9}, Landroid/graphics/Rect;->set(IIII)V

    .line 469
    move-object v5, v0

    iget-object v5, v5, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    move v6, v1

    move-object v7, v0

    iget-object v7, v7, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    iget-object v7, v7, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    iget v7, v7, Landroid/graphics/Rect;->left:I

    add-int/2addr v6, v7

    move v7, v2

    move-object v8, v0

    iget-object v8, v8, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    iget-object v8, v8, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    iget v8, v8, Landroid/graphics/Rect;->top:I

    add-int/2addr v7, v8

    move v8, v3

    move-object v9, v0

    iget-object v9, v9, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    iget-object v9, v9, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->right:I

    add-int/2addr v8, v9

    move v9, v4

    move-object v10, v0

    iget-object v10, v10, Lcom/card/cardview/widget/CardView$1;->this$0:Lcom/card/cardview/widget/CardView;

    iget-object v10, v10, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    iget v10, v10, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v9, v10

    invoke-static {v5, v6, v7, v8, v9}, Lcom/card/cardview/widget/CardView;->access$001(Lcom/card/cardview/widget/CardView;IIII)V

    .line 471
    return-void
.end method
