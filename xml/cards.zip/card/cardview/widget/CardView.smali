.class public Lcom/card/cardview/widget/CardView;
.super Landroid/widget/FrameLayout;
.source "CardView.java"


# static fields
.field private static final COLOR_BACKGROUND_ATTR:[I

.field private static final IMPL:Lcom/card/cardview/widget/CardViewImpl;


# instance fields
.field private final mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

.field private mCompatPadding:Z

.field final mContentPadding:Landroid/graphics/Rect;

.field private mPreventCornerOverlap:Z

.field final mShadowBounds:Landroid/graphics/Rect;

.field mUserSetMinHeight:I

.field mUserSetMinWidth:I


# direct methods
.method static constructor <clinit>()V
    .registers 5

    .prologue
    .line 81
    const/4 v0, 0x1

    new-array v0, v0, [I

    move-object v4, v0

    move-object v0, v4

    move-object v1, v4

    const/4 v2, 0x0

    const v3, 0x1010031

    aput v3, v1, v2

    sput-object v0, Lcom/card/cardview/widget/CardView;->COLOR_BACKGROUND_ATTR:[I

    .line 85
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x15

    if-lt v0, v1, :cond_24

    .line 86
    new-instance v0, Lcom/card/cardview/widget/CardViewApi21Impl;

    move-object v4, v0

    move-object v0, v4

    move-object v1, v4

    invoke-direct {v1}, Lcom/card/cardview/widget/CardViewApi21Impl;-><init>()V

    sput-object v0, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    .line 92
    :goto_1e
    sget-object v0, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    invoke-interface {v0}, Lcom/card/cardview/widget/CardViewImpl;->initStatic()V

    .line 93
    return-void

    .line 87
    :cond_24
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x11

    if-lt v0, v1, :cond_35

    .line 88
    new-instance v0, Lcom/card/cardview/widget/CardViewApi17Impl;

    move-object v4, v0

    move-object v0, v4

    move-object v1, v4

    invoke-direct {v1}, Lcom/card/cardview/widget/CardViewApi17Impl;-><init>()V

    sput-object v0, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    goto :goto_1e

    .line 90
    :cond_35
    new-instance v0, Lcom/card/cardview/widget/CardViewBaseImpl;

    move-object v4, v0

    move-object v0, v4

    move-object v1, v4

    invoke-direct {v1}, Lcom/card/cardview/widget/CardViewBaseImpl;-><init>()V

    sput-object v0, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    goto :goto_1e
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 7
    .param p1    # Landroid/content/Context;
        .annotation build Lcom/cardannotation/NonNull;
        .end annotation
    .end param

    .prologue
    .line 113
    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    move-object v3, v1

    const/4 v4, 0x0

    invoke-direct {v2, v3, v4}, Lcom/card/cardview/widget/CardView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 114
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 10
    .param p1    # Landroid/content/Context;
        .annotation build Lcom/cardannotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param

    .prologue
    .line 117
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, v0

    move-object v4, v1

    move-object v5, v2

    sget v6, Lcom/card/cardview/R$attr;->cardViewStyle:I

    invoke-direct {v3, v4, v5, v6}, Lcom/card/cardview/widget/CardView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 118
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 22
    .param p1    # Landroid/content/Context;
        .annotation build Lcom/cardannotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param

    .prologue
    .line 121
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move-object v10, v0

    move-object v11, v1

    move-object v12, v2

    move v13, v3

    invoke-direct {v10, v11, v12, v13}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 108
    move-object v10, v0

    new-instance v11, Landroid/graphics/Rect;

    move-object/from16 v17, v11

    move-object/from16 v11, v17

    move-object/from16 v12, v17

    invoke-direct {v12}, Landroid/graphics/Rect;-><init>()V

    iput-object v11, v10, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    .line 110
    move-object v10, v0

    new-instance v11, Landroid/graphics/Rect;

    move-object/from16 v17, v11

    move-object/from16 v11, v17

    move-object/from16 v12, v17

    invoke-direct {v12}, Landroid/graphics/Rect;-><init>()V

    iput-object v11, v10, Lcom/card/cardview/widget/CardView;->mShadowBounds:Landroid/graphics/Rect;

    .line 447
    move-object v10, v0

    new-instance v11, Lcom/card/cardview/widget/CardView$1;

    move-object/from16 v17, v11

    move-object/from16 v11, v17

    move-object/from16 v12, v17

    move-object v13, v0

    invoke-direct {v12, v13}, Lcom/card/cardview/widget/CardView$1;-><init>(Lcom/card/cardview/widget/CardView;)V

    iput-object v11, v10, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    .line 123
    move-object v10, v1

    move-object v11, v2

    sget-object v12, Lcom/card/cardview/R$styleable;->CardView:[I

    move v13, v3

    sget v14, Lcom/card/cardview/R$style;->CardView:I

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v10

    move-object v4, v10

    .line 126
    move-object v10, v4

    sget v11, Lcom/card/cardview/R$styleable;->CardView_cardBackgroundColor:I

    invoke-virtual {v10, v11}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v10

    if-eqz v10, :cond_f6

    .line 127
    move-object v10, v4

    sget v11, Lcom/card/cardview/R$styleable;->CardView_cardBackgroundColor:I

    invoke-virtual {v10, v11}, Landroid/content/res/TypedArray;->getColorStateList(I)Landroid/content/res/ColorStateList;

    move-result-object v10

    move-object v5, v10

    .line 141
    :goto_57
    move-object v10, v4

    sget v11, Lcom/card/cardview/R$styleable;->CardView_cardCornerRadius:I

    const/4 v12, 0x0

    invoke-virtual {v10, v11, v12}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v10

    move v6, v10

    .line 142
    move-object v10, v4

    sget v11, Lcom/card/cardview/R$styleable;->CardView_cardElevation:I

    const/4 v12, 0x0

    invoke-virtual {v10, v11, v12}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v10

    move v7, v10

    .line 143
    move-object v10, v4

    sget v11, Lcom/card/cardview/R$styleable;->CardView_cardMaxElevation:I

    const/4 v12, 0x0

    invoke-virtual {v10, v11, v12}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v10

    move v8, v10

    .line 144
    move-object v10, v0

    move-object v11, v4

    sget v12, Lcom/card/cardview/R$styleable;->CardView_cardUseCompatPadding:I

    const/4 v13, 0x0

    invoke-virtual {v11, v12, v13}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v11

    iput-boolean v11, v10, Lcom/card/cardview/widget/CardView;->mCompatPadding:Z

    .line 145
    move-object v10, v0

    move-object v11, v4

    sget v12, Lcom/card/cardview/R$styleable;->CardView_cardPreventCornerOverlap:I

    const/4 v13, 0x1

    invoke-virtual {v11, v12, v13}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v11

    iput-boolean v11, v10, Lcom/card/cardview/widget/CardView;->mPreventCornerOverlap:Z

    .line 146
    move-object v10, v4

    sget v11, Lcom/card/cardview/R$styleable;->CardView_contentPadding:I

    const/4 v12, 0x0

    invoke-virtual {v10, v11, v12}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v10

    move v9, v10

    .line 147
    move-object v10, v0

    iget-object v10, v10, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    move-object v11, v4

    sget v12, Lcom/card/cardview/R$styleable;->CardView_contentPaddingLeft:I

    move v13, v9

    invoke-virtual {v11, v12, v13}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v11

    iput v11, v10, Landroid/graphics/Rect;->left:I

    .line 149
    move-object v10, v0

    iget-object v10, v10, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    move-object v11, v4

    sget v12, Lcom/card/cardview/R$styleable;->CardView_contentPaddingTop:I

    move v13, v9

    invoke-virtual {v11, v12, v13}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v11

    iput v11, v10, Landroid/graphics/Rect;->top:I

    .line 151
    move-object v10, v0

    iget-object v10, v10, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    move-object v11, v4

    sget v12, Lcom/card/cardview/R$styleable;->CardView_contentPaddingRight:I

    move v13, v9

    invoke-virtual {v11, v12, v13}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v11

    iput v11, v10, Landroid/graphics/Rect;->right:I

    .line 153
    move-object v10, v0

    iget-object v10, v10, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    move-object v11, v4

    sget v12, Lcom/card/cardview/R$styleable;->CardView_contentPaddingBottom:I

    move v13, v9

    invoke-virtual {v11, v12, v13}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v11

    iput v11, v10, Landroid/graphics/Rect;->bottom:I

    .line 155
    move v10, v7

    move v11, v8

    cmpl-float v10, v10, v11

    if-lez v10, :cond_cd

    .line 156
    move v10, v7

    move v8, v10

    .line 158
    :cond_cd
    move-object v10, v0

    move-object v11, v4

    sget v12, Lcom/card/cardview/R$styleable;->CardView_android_minWidth:I

    const/4 v13, 0x0

    invoke-virtual {v11, v12, v13}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v11

    iput v11, v10, Lcom/card/cardview/widget/CardView;->mUserSetMinWidth:I

    .line 159
    move-object v10, v0

    move-object v11, v4

    sget v12, Lcom/card/cardview/R$styleable;->CardView_android_minHeight:I

    const/4 v13, 0x0

    invoke-virtual {v11, v12, v13}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v11

    iput v11, v10, Lcom/card/cardview/widget/CardView;->mUserSetMinHeight:I

    .line 160
    move-object v10, v4

    invoke-virtual {v10}, Landroid/content/res/TypedArray;->recycle()V

    .line 162
    sget-object v10, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v11, v0

    iget-object v11, v11, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    move-object v12, v1

    move-object v13, v5

    move v14, v6

    move v15, v7

    move/from16 v16, v8

    invoke-interface/range {v10 .. v16}, Lcom/card/cardview/widget/CardViewImpl;->initialize(Lcom/card/cardview/widget/CardViewDelegate;Landroid/content/Context;Landroid/content/res/ColorStateList;FFF)V

    .line 164
    return-void

    .line 130
    :cond_f6
    move-object v10, v0

    invoke-virtual {v10}, Lcom/card/cardview/widget/CardView;->getContext()Landroid/content/Context;

    move-result-object v10

    sget-object v11, Lcom/card/cardview/widget/CardView;->COLOR_BACKGROUND_ATTR:[I

    invoke-virtual {v10, v11}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object v10

    move-object v6, v10

    .line 131
    move-object v10, v6

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {v10, v11, v12}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v10

    move v7, v10

    .line 132
    move-object v10, v6

    invoke-virtual {v10}, Landroid/content/res/TypedArray;->recycle()V

    .line 135
    const/4 v10, 0x3

    new-array v10, v10, [F

    move-object v8, v10

    .line 136
    move v10, v7

    move-object v11, v8

    invoke-static {v10, v11}, Landroid/graphics/Color;->colorToHSV(I[F)V

    .line 137
    move-object v10, v8

    const/4 v11, 0x2

    aget v10, v10, v11

    const/high16 v11, 0x3f000000    # 0.5f

    cmpl-float v10, v10, v11

    if-lez v10, :cond_133

    move-object v10, v0

    .line 138
    invoke-virtual {v10}, Lcom/card/cardview/widget/CardView;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    sget v11, Lcom/card/cardview/R$color;->cardview_light_background:I

    invoke-virtual {v10, v11}, Landroid/content/res/Resources;->getColor(I)I

    move-result v10

    .line 137
    :goto_12c
    invoke-static {v10}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v10

    move-object v5, v10

    goto/16 :goto_57

    .line 138
    :cond_133
    move-object v10, v0

    .line 139
    invoke-virtual {v10}, Lcom/card/cardview/widget/CardView;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    sget v11, Lcom/card/cardview/R$color;->cardview_dark_background:I

    invoke-virtual {v10, v11}, Landroid/content/res/Resources;->getColor(I)I

    move-result v10

    goto :goto_12c
.end method

.method static synthetic access$001(Lcom/card/cardview/widget/CardView;IIII)V
    .registers 15

    .prologue
    .line 79
    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, v0

    move v6, v1

    move v7, v2

    move v8, v3

    move v9, v4

    invoke-super {v5, v6, v7, v8, v9}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    return-void
.end method

.method static synthetic access$101(Lcom/card/cardview/widget/CardView;I)V
    .registers 6

    .prologue
    .line 79
    move-object v0, p0

    move v1, p1

    move-object v2, v0

    move v3, v1

    invoke-super {v2, v3}, Landroid/widget/FrameLayout;->setMinimumWidth(I)V

    return-void
.end method

.method static synthetic access$201(Lcom/card/cardview/widget/CardView;I)V
    .registers 6

    .prologue
    .line 79
    move-object v0, p0

    move v1, p1

    move-object v2, v0

    move v3, v1

    invoke-super {v2, v3}, Landroid/widget/FrameLayout;->setMinimumHeight(I)V

    return-void
.end method


# virtual methods
.method public getCardBackgroundColor()Landroid/content/res/ColorStateList;
    .registers 4
    .annotation build Lcom/cardannotation/NonNull;
    .end annotation

    .prologue
    .line 303
    move-object v0, p0

    sget-object v1, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v2, v0

    iget-object v2, v2, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    invoke-interface {v1, v2}, Lcom/card/cardview/widget/CardViewImpl;->getBackgroundColor(Lcom/card/cardview/widget/CardViewDelegate;)Landroid/content/res/ColorStateList;

    move-result-object v1

    move-object v0, v1

    return-object v0
.end method

.method public getCardElevation()F
    .registers 4

    .prologue
    .line 387
    move-object v0, p0

    sget-object v1, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v2, v0

    iget-object v2, v2, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    invoke-interface {v1, v2}, Lcom/card/cardview/widget/CardViewImpl;->getElevation(Lcom/card/cardview/widget/CardViewDelegate;)F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getContentPaddingBottom()I
    .registers 3
    .annotation build Lcom/cardannotation/Px;
    .end annotation

    .prologue
    .line 343
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->bottom:I

    move v0, v1

    return v0
.end method

.method public getContentPaddingLeft()I
    .registers 3
    .annotation build Lcom/cardannotation/Px;
    .end annotation

    .prologue
    .line 313
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->left:I

    move v0, v1

    return v0
.end method

.method public getContentPaddingRight()I
    .registers 3
    .annotation build Lcom/cardannotation/Px;
    .end annotation

    .prologue
    .line 323
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->right:I

    move v0, v1

    return v0
.end method

.method public getContentPaddingTop()I
    .registers 3
    .annotation build Lcom/cardannotation/Px;
    .end annotation

    .prologue
    .line 333
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->top:I

    move v0, v1

    return v0
.end method

.method public getMaxCardElevation()F
    .registers 4

    .prologue
    .line 413
    move-object v0, p0

    sget-object v1, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v2, v0

    iget-object v2, v2, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    invoke-interface {v1, v2}, Lcom/card/cardview/widget/CardViewImpl;->getMaxElevation(Lcom/card/cardview/widget/CardViewDelegate;)F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getPreventCornerOverlap()Z
    .registers 3

    .prologue
    .line 424
    move-object v0, p0

    move-object v1, v0

    iget-boolean v1, v1, Lcom/card/cardview/widget/CardView;->mPreventCornerOverlap:Z

    move v0, v1

    return v0
.end method

.method public getRadius()F
    .registers 4

    .prologue
    .line 364
    move-object v0, p0

    sget-object v1, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v2, v0

    iget-object v2, v2, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    invoke-interface {v1, v2}, Lcom/card/cardview/widget/CardViewImpl;->getRadius(Lcom/card/cardview/widget/CardViewDelegate;)F

    move-result v1

    move v0, v1

    return v0
.end method

.method public getUseCompatPadding()Z
    .registers 3

    .prologue
    .line 183
    move-object v0, p0

    move-object v1, v0

    iget-boolean v1, v1, Lcom/card/cardview/widget/CardView;->mCompatPadding:Z

    move v0, v1

    return v0
.end method

.method protected onMeasure(II)V
    .registers 12

    .prologue
    .line 232
    move-object v0, p0

    move v1, p1

    move v2, p2

    sget-object v6, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    instance-of v6, v6, Lcom/card/cardview/widget/CardViewApi21Impl;

    if-nez v6, :cond_66

    .line 233
    move v6, v1

    invoke-static {v6}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v6

    move v3, v6

    .line 234
    move v6, v3

    sparse-switch v6, :sswitch_data_6e

    .line 246
    :goto_13
    move v6, v2

    invoke-static {v6}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v6

    move v4, v6

    .line 247
    move v6, v4

    sparse-switch v6, :sswitch_data_78

    .line 258
    :goto_1d
    move-object v6, v0

    move v7, v1

    move v8, v2

    invoke-super {v6, v7, v8}, Landroid/widget/FrameLayout;->onMeasure(II)V

    .line 262
    :goto_23
    return-void

    .line 237
    :sswitch_24
    sget-object v6, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v7, v0

    iget-object v7, v7, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    invoke-interface {v6, v7}, Lcom/card/cardview/widget/CardViewImpl;->getMinWidth(Lcom/card/cardview/widget/CardViewDelegate;)F

    move-result v6

    float-to-double v6, v6

    invoke-static {v6, v7}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v6

    double-to-int v6, v6

    move v4, v6

    .line 238
    move v6, v4

    move v7, v1

    .line 239
    invoke-static {v7}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v7

    .line 238
    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    move-result v6

    move v7, v3

    invoke-static {v6, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    move v1, v6

    .line 240
    goto :goto_13

    .line 250
    :sswitch_45
    sget-object v6, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v7, v0

    iget-object v7, v7, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    invoke-interface {v6, v7}, Lcom/card/cardview/widget/CardViewImpl;->getMinHeight(Lcom/card/cardview/widget/CardViewDelegate;)F

    move-result v6

    float-to-double v6, v6

    invoke-static {v6, v7}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v6

    double-to-int v6, v6

    move v5, v6

    .line 251
    move v6, v5

    move v7, v2

    .line 252
    invoke-static {v7}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v7

    .line 251
    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    move-result v6

    move v7, v4

    invoke-static {v6, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    move v2, v6

    .line 253
    goto :goto_1d

    .line 260
    :cond_66
    move-object v6, v0

    move v7, v1

    move v8, v2

    invoke-super {v6, v7, v8}, Landroid/widget/FrameLayout;->onMeasure(II)V

    goto :goto_23

    .line 234
    nop

    :sswitch_data_6e
    .sparse-switch
        -0x80000000 -> :sswitch_24
        0x40000000 -> :sswitch_24
    .end sparse-switch

    .line 247
    :sswitch_data_78
    .sparse-switch
        -0x80000000 -> :sswitch_45
        0x40000000 -> :sswitch_45
    .end sparse-switch
.end method

.method public setCardBackgroundColor(I)V
    .registers 7
    .param p1    # I
        .annotation build Lcom/cardannotation/ColorInt;
        .end annotation
    .end param

    .prologue
    .line 283
    move-object v0, p0

    move v1, p1

    sget-object v2, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v3, v0

    iget-object v3, v3, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    move v4, v1

    invoke-static {v4}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    invoke-interface {v2, v3, v4}, Lcom/card/cardview/widget/CardViewImpl;->setBackgroundColor(Lcom/card/cardview/widget/CardViewDelegate;Landroid/content/res/ColorStateList;)V

    .line 284
    return-void
.end method

.method public setCardBackgroundColor(Landroid/content/res/ColorStateList;)V
    .registers 7
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param

    .prologue
    .line 293
    move-object v0, p0

    move-object v1, p1

    sget-object v2, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v3, v0

    iget-object v3, v3, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    move-object v4, v1

    invoke-interface {v2, v3, v4}, Lcom/card/cardview/widget/CardViewImpl;->setBackgroundColor(Lcom/card/cardview/widget/CardViewDelegate;Landroid/content/res/ColorStateList;)V

    .line 294
    return-void
.end method

.method public setCardElevation(F)V
    .registers 7

    .prologue
    .line 376
    move-object v0, p0

    move v1, p1

    sget-object v2, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v3, v0

    iget-object v3, v3, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    move v4, v1

    invoke-interface {v2, v3, v4}, Lcom/card/cardview/widget/CardViewImpl;->setElevation(Lcom/card/cardview/widget/CardViewDelegate;F)V

    .line 377
    return-void
.end method

.method public setContentPadding(IIII)V
    .registers 15
    .param p1    # I
        .annotation build Lcom/cardannotation/Px;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Lcom/cardannotation/Px;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Lcom/cardannotation/Px;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Lcom/cardannotation/Px;
        .end annotation
    .end param

    .prologue
    .line 226
    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, v0

    iget-object v5, v5, Lcom/card/cardview/widget/CardView;->mContentPadding:Landroid/graphics/Rect;

    move v6, v1

    move v7, v2

    move v8, v3

    move v9, v4

    invoke-virtual {v5, v6, v7, v8, v9}, Landroid/graphics/Rect;->set(IIII)V

    .line 227
    sget-object v5, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v6, v0

    iget-object v6, v6, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    invoke-interface {v5, v6}, Lcom/card/cardview/widget/CardViewImpl;->updatePadding(Lcom/card/cardview/widget/CardViewDelegate;)V

    .line 228
    return-void
.end method

.method public setMaxCardElevation(F)V
    .registers 7

    .prologue
    .line 402
    move-object v0, p0

    move v1, p1

    sget-object v2, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v3, v0

    iget-object v3, v3, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    move v4, v1

    invoke-interface {v2, v3, v4}, Lcom/card/cardview/widget/CardViewImpl;->setMaxElevation(Lcom/card/cardview/widget/CardViewDelegate;F)V

    .line 403
    return-void
.end method

.method public setMinimumHeight(I)V
    .registers 6

    .prologue
    .line 272
    move-object v0, p0

    move v1, p1

    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/card/cardview/widget/CardView;->mUserSetMinHeight:I

    .line 273
    move-object v2, v0

    move v3, v1

    invoke-super {v2, v3}, Landroid/widget/FrameLayout;->setMinimumHeight(I)V

    .line 274
    return-void
.end method

.method public setMinimumWidth(I)V
    .registers 6

    .prologue
    .line 266
    move-object v0, p0

    move v1, p1

    move-object v2, v0

    move v3, v1

    iput v3, v2, Lcom/card/cardview/widget/CardView;->mUserSetMinWidth:I

    .line 267
    move-object v2, v0

    move v3, v1

    invoke-super {v2, v3}, Landroid/widget/FrameLayout;->setMinimumWidth(I)V

    .line 268
    return-void
.end method

.method public setPadding(IIII)V
    .registers 5

    .prologue
    .line 169
    return-void
.end method

.method public setPaddingRelative(IIII)V
    .registers 5

    .prologue
    .line 174
    return-void
.end method

.method public setPreventCornerOverlap(Z)V
    .registers 6

    .prologue
    .line 441
    move-object v0, p0

    move v1, p1

    move v2, v1

    move-object v3, v0

    iget-boolean v3, v3, Lcom/card/cardview/widget/CardView;->mPreventCornerOverlap:Z

    if-eq v2, v3, :cond_14

    .line 442
    move-object v2, v0

    move v3, v1

    iput-boolean v3, v2, Lcom/card/cardview/widget/CardView;->mPreventCornerOverlap:Z

    .line 443
    sget-object v2, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v3, v0

    iget-object v3, v3, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    invoke-interface {v2, v3}, Lcom/card/cardview/widget/CardViewImpl;->onPreventCornerOverlapChanged(Lcom/card/cardview/widget/CardViewDelegate;)V

    .line 445
    :cond_14
    return-void
.end method

.method public setRadius(F)V
    .registers 7

    .prologue
    .line 354
    move-object v0, p0

    move v1, p1

    sget-object v2, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v3, v0

    iget-object v3, v3, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    move v4, v1

    invoke-interface {v2, v3, v4}, Lcom/card/cardview/widget/CardViewImpl;->setRadius(Lcom/card/cardview/widget/CardViewDelegate;F)V

    .line 355
    return-void
.end method

.method public setUseCompatPadding(Z)V
    .registers 6

    .prologue
    .line 203
    move-object v0, p0

    move v1, p1

    move-object v2, v0

    iget-boolean v2, v2, Lcom/card/cardview/widget/CardView;->mCompatPadding:Z

    move v3, v1

    if-eq v2, v3, :cond_14

    .line 204
    move-object v2, v0

    move v3, v1

    iput-boolean v3, v2, Lcom/card/cardview/widget/CardView;->mCompatPadding:Z

    .line 205
    sget-object v2, Lcom/card/cardview/widget/CardView;->IMPL:Lcom/card/cardview/widget/CardViewImpl;

    move-object v3, v0

    iget-object v3, v3, Lcom/card/cardview/widget/CardView;->mCardViewDelegate:Lcom/card/cardview/widget/CardViewDelegate;

    invoke-interface {v2, v3}, Lcom/card/cardview/widget/CardViewImpl;->onCompatPaddingChanged(Lcom/card/cardview/widget/CardViewDelegate;)V

    .line 207
    :cond_14
    return-void
.end method
