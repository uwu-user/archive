.class public final Lcom/card/cardview/R$drawable;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/card/cardview/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "drawable"
.end annotation


# static fields
.field public static final abc_ab_share_pack_mtrl_alpha:I = 0x7f020000

.field public static final abc_action_bar_item_background_material:I = 0x7f020001

.field public static final abc_btn_borderless_material:I = 0x7f020002

.field public static final abc_btn_check_material:I = 0x7f020003

.field public static final abc_btn_check_to_on_mtrl_000:I = 0x7f020004

.field public static final abc_btn_check_to_on_mtrl_015:I = 0x7f020005

.field public static final abc_btn_colored_material:I = 0x7f020006

.field public static final abc_btn_default_mtrl_shape:I = 0x7f020007

.field public static final abc_btn_radio_material:I = 0x7f020008

.field public static final abc_btn_radio_to_on_mtrl_000:I = 0x7f020009

.field public static final abc_btn_radio_to_on_mtrl_015:I = 0x7f02000a

.field public static final abc_btn_switch_to_on_mtrl_00001:I = 0x7f02000b

.field public static final abc_btn_switch_to_on_mtrl_00012:I = 0x7f02000c

.field public static final abc_cab_background_internal_bg:I = 0x7f02000d

.field public static final abc_cab_background_top_material:I = 0x7f02000e

.field public static final abc_cab_background_top_mtrl_alpha:I = 0x7f02000f

.field public static final abc_control_background_material:I = 0x7f020010

.field public static final abc_dialog_material_background:I = 0x7f020011

.field public static final abc_edit_text_material:I = 0x7f020012

.field public static final abc_ic_ab_back_material:I = 0x7f020013

.field public static final abc_ic_arrow_drop_right_black_24dp:I = 0x7f020014

.field public static final abc_ic_clear_material:I = 0x7f020015

.field public static final abc_ic_commit_search_api_mtrl_alpha:I = 0x7f020016

.field public static final abc_ic_go_search_api_material:I = 0x7f020017

.field public static final abc_ic_menu_copy_mtrl_am_alpha:I = 0x7f020018

.field public static final abc_ic_menu_cut_mtrl_alpha:I = 0x7f020019

.field public static final abc_ic_menu_overflow_material:I = 0x7f02001a

.field public static final abc_ic_menu_paste_mtrl_am_alpha:I = 0x7f02001b

.field public static final abc_ic_menu_selectall_mtrl_alpha:I = 0x7f02001c

.field public static final abc_ic_menu_share_mtrl_alpha:I = 0x7f02001d

.field public static final abc_ic_search_api_material:I = 0x7f02001e

.field public static final abc_ic_star_black_16dp:I = 0x7f02001f

.field public static final abc_ic_star_black_36dp:I = 0x7f020020

.field public static final abc_ic_star_black_48dp:I = 0x7f020021

.field public static final abc_ic_star_half_black_16dp:I = 0x7f020022

.field public static final abc_ic_star_half_black_36dp:I = 0x7f020023

.field public static final abc_ic_star_half_black_48dp:I = 0x7f020024

.field public static final abc_ic_voice_search_api_material:I = 0x7f020025

.field public static final abc_item_background_holo_dark:I = 0x7f020026

.field public static final abc_item_background_holo_light:I = 0x7f020027

.field public static final abc_list_divider_material:I = 0x7f020028

.field public static final abc_list_divider_mtrl_alpha:I = 0x7f020029

.field public static final abc_list_focused_holo:I = 0x7f02002a

.field public static final abc_list_longpressed_holo:I = 0x7f02002b

.field public static final abc_list_pressed_holo_dark:I = 0x7f02002c

.field public static final abc_list_pressed_holo_light:I = 0x7f02002d

.field public static final abc_list_selector_background_transition_holo_dark:I = 0x7f02002e

.field public static final abc_list_selector_background_transition_holo_light:I = 0x7f02002f

.field public static final abc_list_selector_disabled_holo_dark:I = 0x7f020030

.field public static final abc_list_selector_disabled_holo_light:I = 0x7f020031

.field public static final abc_list_selector_holo_dark:I = 0x7f020032

.field public static final abc_list_selector_holo_light:I = 0x7f020033

.field public static final abc_menu_hardkey_panel_mtrl_mult:I = 0x7f020034

.field public static final abc_popup_background_mtrl_mult:I = 0x7f020035

.field public static final abc_ratingbar_indicator_material:I = 0x7f020036

.field public static final abc_ratingbar_material:I = 0x7f020037

.field public static final abc_ratingbar_small_material:I = 0x7f020038

.field public static final abc_scrubber_control_off_mtrl_alpha:I = 0x7f020039

.field public static final abc_scrubber_control_to_pressed_mtrl_000:I = 0x7f02003a

.field public static final abc_scrubber_control_to_pressed_mtrl_005:I = 0x7f02003b

.field public static final abc_scrubber_primary_mtrl_alpha:I = 0x7f02003c

.field public static final abc_scrubber_track_mtrl_alpha:I = 0x7f02003d

.field public static final abc_seekbar_thumb_material:I = 0x7f02003e

.field public static final abc_seekbar_tick_mark_material:I = 0x7f02003f

.field public static final abc_seekbar_track_material:I = 0x7f020040

.field public static final abc_spinner_mtrl_am_alpha:I = 0x7f020041

.field public static final abc_spinner_textfield_background_material:I = 0x7f020042

.field public static final abc_switch_thumb_material:I = 0x7f020043

.field public static final abc_switch_track_mtrl_alpha:I = 0x7f020044

.field public static final abc_tab_indicator_material:I = 0x7f020045

.field public static final abc_tab_indicator_mtrl_alpha:I = 0x7f020046

.field public static final abc_text_cursor_material:I = 0x7f020047

.field public static final abc_text_select_handle_left_mtrl_dark:I = 0x7f020048

.field public static final abc_text_select_handle_left_mtrl_light:I = 0x7f020049

.field public static final abc_text_select_handle_middle_mtrl_dark:I = 0x7f02004a

.field public static final abc_text_select_handle_middle_mtrl_light:I = 0x7f02004b

.field public static final abc_text_select_handle_right_mtrl_dark:I = 0x7f02004c

.field public static final abc_text_select_handle_right_mtrl_light:I = 0x7f02004d

.field public static final abc_textfield_activated_mtrl_alpha:I = 0x7f02004e

.field public static final abc_textfield_default_mtrl_alpha:I = 0x7f02004f

.field public static final abc_textfield_search_activated_mtrl_alpha:I = 0x7f020050

.field public static final abc_textfield_search_default_mtrl_alpha:I = 0x7f020051

.field public static final abc_textfield_search_material:I = 0x7f020052

.field public static final abc_vector_test:I = 0x7f020053

.field public static final avd_hide_password:I = 0x7f020054

.field public static final avd_hide_password_1:I = 0x7f020072

.field public static final avd_hide_password_2:I = 0x7f020073

.field public static final avd_hide_password_3:I = 0x7f020074

.field public static final avd_show_password:I = 0x7f020055

.field public static final avd_show_password_1:I = 0x7f020075

.field public static final avd_show_password_2:I = 0x7f020076

.field public static final avd_show_password_3:I = 0x7f020077

.field public static final design_bottom_navigation_item_background:I = 0x7f020056

.field public static final design_fab_background:I = 0x7f020057

.field public static final design_ic_visibility:I = 0x7f020058

.field public static final design_ic_visibility_off:I = 0x7f020059

.field public static final design_password_eye:I = 0x7f02005a

.field public static final design_snackbar_background:I = 0x7f02005b

.field public static final ic_launcher_background:I = 0x7f02005c

.field public static final ic_launcher_foreground:I = 0x7f02005d

.field public static final ic_launcher_foreground_1:I = 0x7f020078

.field public static final ic_mtrl_chip_checked_black:I = 0x7f02005e

.field public static final ic_mtrl_chip_checked_circle:I = 0x7f02005f

.field public static final ic_mtrl_chip_close_circle:I = 0x7f020060

.field public static final mtrl_snackbar_background:I = 0x7f020061

.field public static final mtrl_tabs_default_indicator:I = 0x7f020062

.field public static final navigation_empty_icon:I = 0x7f020063

.field public static final notification_action_background:I = 0x7f020064

.field public static final notification_bg:I = 0x7f020065

.field public static final notification_bg_low:I = 0x7f020066

.field public static final notification_bg_low_normal:I = 0x7f020067

.field public static final notification_bg_low_pressed:I = 0x7f020068

.field public static final notification_bg_normal:I = 0x7f020069

.field public static final notification_bg_normal_pressed:I = 0x7f02006a

.field public static final notification_icon_background:I = 0x7f02006b

.field public static final notification_template_icon_bg:I = 0x7f020070

.field public static final notification_template_icon_low_bg:I = 0x7f020071

.field public static final notification_tile_bg:I = 0x7f02006c

.field public static final notify_panel_notification_icon_bg:I = 0x7f02006d

.field public static final tooltip_frame_dark:I = 0x7f02006e

.field public static final tooltip_frame_light:I = 0x7f02006f


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 4563
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
