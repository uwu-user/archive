.class public final Lcom/card/cardview/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/card/cardview/R$anim;,
        Lcom/card/cardview/R$animator;,
        Lcom/card/cardview/R$attr;,
        Lcom/card/cardview/R$bool;,
        Lcom/card/cardview/R$color;,
        Lcom/card/cardview/R$dimen;,
        Lcom/card/cardview/R$drawable;,
        Lcom/card/cardview/R$id;,
        Lcom/card/cardview/R$integer;,
        Lcom/card/cardview/R$interpolator;,
        Lcom/card/cardview/R$layout;,
        Lcom/card/cardview/R$mipmap;,
        Lcom/card/cardview/R$string;,
        Lcom/card/cardview/R$style;,
        Lcom/card/cardview/R$styleable;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 16916
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
