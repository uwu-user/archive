.class public final Lcom/card/core/R$bool;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/card/core/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "bool"
.end annotation


# static fields
.field public static final abc_action_bar_embed_tabs:I = 0x7f0d0001

.field public static final abc_allow_stacked_button_bar:I = 0x7f0d0002

.field public static final abc_config_actionMenuItemAllCaps:I = 0x7f0d0003

.field public static final mtrl_btn_textappearance_all_caps:I = 0x7f0d0000


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 4091
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
