.class public final Lcom/card/core/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/card/core/R$anim;,
        Lcom/card/core/R$animator;,
        Lcom/card/core/R$attr;,
        Lcom/card/core/R$bool;,
        Lcom/card/core/R$color;,
        Lcom/card/core/R$dimen;,
        Lcom/card/core/R$drawable;,
        Lcom/card/core/R$id;,
        Lcom/card/core/R$integer;,
        Lcom/card/core/R$interpolator;,
        Lcom/card/core/R$layout;,
        Lcom/card/core/R$mipmap;,
        Lcom/card/core/R$string;,
        Lcom/card/core/R$style;,
        Lcom/card/core/R$styleable;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 16916
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
