.class public Lcom/card/core/util/Pools$SimplePool;
.super Ljava/lang/Object;
.source "Pools.java"

# interfaces
.implements Lcom/card/core/util/Pools$Pool;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/card/core/util/Pools;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "SimplePool"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/card/core/util/Pools$Pool",
        "<TT;>;"
    }
.end annotation


# instance fields
.field private final mPool:[Ljava/lang/Object;

.field private mPoolSize:I


# direct methods
.method public constructor <init>(I)V
    .registers 8

    .prologue
    .line 94
    move-object v0, p0

    move v1, p1

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 95
    move v2, v1

    if-gtz v2, :cond_14

    .line 96
    new-instance v2, Ljava/lang/IllegalArgumentException;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "The max pool size must be > 0"

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 98
    :cond_14
    move-object v2, v0

    move v3, v1

    new-array v3, v3, [Ljava/lang/Object;

    iput-object v3, v2, Lcom/card/core/util/Pools$SimplePool;->mPool:[Ljava/lang/Object;

    .line 99
    return-void
.end method

.method private isInPool(Ljava/lang/Object;)Z
    .registers 7
    .param p1    # Ljava/lang/Object;
        .annotation build Lcom/cardannotation/NonNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    .prologue
    .line 128
    move-object v0, p0

    move-object v1, p1

    const/4 v3, 0x0

    move v2, v3

    :goto_4
    move v3, v2

    move-object v4, v0

    iget v4, v4, Lcom/card/core/util/Pools$SimplePool;->mPoolSize:I

    if-ge v3, v4, :cond_19

    .line 129
    move-object v3, v0

    iget-object v3, v3, Lcom/card/core/util/Pools$SimplePool;->mPool:[Ljava/lang/Object;

    move v4, v2

    aget-object v3, v3, v4

    move-object v4, v1

    if-ne v3, v4, :cond_16

    .line 130
    const/4 v3, 0x1

    move v0, v3

    .line 133
    :goto_15
    return v0

    .line 128
    :cond_16
    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    .line 133
    :cond_19
    const/4 v3, 0x0

    move v0, v3

    goto :goto_15
.end method


# virtual methods
.method public acquire()Ljava/lang/Object;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 104
    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lcom/card/core/util/Pools$SimplePool;->mPoolSize:I

    if-lez v3, :cond_29

    .line 105
    move-object v3, v0

    iget v3, v3, Lcom/card/core/util/Pools$SimplePool;->mPoolSize:I

    const/4 v4, 0x1

    add-int/lit8 v3, v3, -0x1

    move v1, v3

    .line 106
    move-object v3, v0

    iget-object v3, v3, Lcom/card/core/util/Pools$SimplePool;->mPool:[Ljava/lang/Object;

    move v4, v1

    aget-object v3, v3, v4

    move-object v2, v3

    .line 107
    move-object v3, v0

    iget-object v3, v3, Lcom/card/core/util/Pools$SimplePool;->mPool:[Ljava/lang/Object;

    move v4, v1

    const/4 v5, 0x0

    aput-object v5, v3, v4

    .line 108
    move-object v3, v0

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    iget v4, v4, Lcom/card/core/util/Pools$SimplePool;->mPoolSize:I

    const/4 v5, 0x1

    add-int/lit8 v4, v4, -0x1

    iput v4, v3, Lcom/card/core/util/Pools$SimplePool;->mPoolSize:I

    .line 109
    move-object v3, v2

    move-object v0, v3

    .line 111
    :goto_28
    return-object v0

    :cond_29
    const/4 v3, 0x0

    move-object v0, v3

    goto :goto_28
.end method

.method public release(Ljava/lang/Object;)Z
    .registers 8
    .param p1    # Ljava/lang/Object;
        .annotation build Lcom/cardannotation/NonNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    .prologue
    .line 116
    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    move-object v3, v1

    invoke-direct {v2, v3}, Lcom/card/core/util/Pools$SimplePool;->isInPool(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_15

    .line 117
    new-instance v2, Ljava/lang/IllegalStateException;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "Already in the pool!"

    invoke-direct {v3, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 119
    :cond_15
    move-object v2, v0

    iget v2, v2, Lcom/card/core/util/Pools$SimplePool;->mPoolSize:I

    move-object v3, v0

    iget-object v3, v3, Lcom/card/core/util/Pools$SimplePool;->mPool:[Ljava/lang/Object;

    array-length v3, v3

    if-ge v2, v3, :cond_35

    .line 120
    move-object v2, v0

    iget-object v2, v2, Lcom/card/core/util/Pools$SimplePool;->mPool:[Ljava/lang/Object;

    move-object v3, v0

    iget v3, v3, Lcom/card/core/util/Pools$SimplePool;->mPoolSize:I

    move-object v4, v1

    aput-object v4, v2, v3

    .line 121
    move-object v2, v0

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    iget v3, v3, Lcom/card/core/util/Pools$SimplePool;->mPoolSize:I

    const/4 v4, 0x1

    add-int/lit8 v3, v3, 0x1

    iput v3, v2, Lcom/card/core/util/Pools$SimplePool;->mPoolSize:I

    .line 122
    const/4 v2, 0x1

    move v0, v2

    .line 124
    :goto_34
    return v0

    :cond_35
    const/4 v2, 0x0

    move v0, v2

    goto :goto_34
.end method
