.class public final Lcom/card/core/util/TimeUtils;
.super Ljava/lang/Object;
.source "TimeUtils.java"


# annotations
.annotation build Lcom/cardannotation/RestrictTo;
    value = {
        .enum Lcom/cardannotation/RestrictTo$Scope;->LIBRARY_GROUP:Lcom/cardannotation/RestrictTo$Scope;
    }
.end annotation


# static fields
.field public static final HUNDRED_DAY_FIELD_LEN:I = 0x13
    .annotation build Lcom/cardannotation/RestrictTo;
        value = {
            .enum Lcom/cardannotation/RestrictTo$Scope;->LIBRARY_GROUP:Lcom/cardannotation/RestrictTo$Scope;
        }
    .end annotation
.end field

.field private static final SECONDS_PER_DAY:I = 0x15180

.field private static final SECONDS_PER_HOUR:I = 0xe10

.field private static final SECONDS_PER_MINUTE:I = 0x3c

.field private static sFormatStr:[C

.field private static final sFormatSync:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .prologue
    .line 40
    new-instance v0, Ljava/lang/Object;

    move-object v2, v0

    move-object v0, v2

    move-object v1, v2

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/card/core/util/TimeUtils;->sFormatSync:Ljava/lang/Object;

    .line 41
    const/16 v0, 0x18

    new-array v0, v0, [C

    sput-object v0, Lcom/card/core/util/TimeUtils;->sFormatStr:[C

    return-void
.end method

.method private constructor <init>()V
    .registers 3

    .prologue
    .line 185
    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static accumField(IIZI)I
    .registers 10

    .prologue
    .line 44
    move v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, v0

    const/16 v5, 0x63

    if-gt v4, v5, :cond_10

    move v4, v2

    if-eqz v4, :cond_15

    move v4, v3

    const/4 v5, 0x3

    if-lt v4, v5, :cond_15

    .line 45
    :cond_10
    const/4 v4, 0x3

    move v5, v1

    add-int/2addr v4, v5

    move v0, v4

    .line 53
    :goto_14
    return v0

    .line 47
    :cond_15
    move v4, v0

    const/16 v5, 0x9

    if-gt v4, v5, :cond_21

    move v4, v2

    if-eqz v4, :cond_26

    move v4, v3

    const/4 v5, 0x2

    if-lt v4, v5, :cond_26

    .line 48
    :cond_21
    const/4 v4, 0x2

    move v5, v1

    add-int/2addr v4, v5

    move v0, v4

    goto :goto_14

    .line 50
    :cond_26
    move v4, v2

    if-nez v4, :cond_2c

    move v4, v0

    if-lez v4, :cond_31

    .line 51
    :cond_2c
    const/4 v4, 0x1

    move v5, v1

    add-int/2addr v4, v5

    move v0, v4

    goto :goto_14

    .line 53
    :cond_31
    const/4 v4, 0x0

    move v0, v4

    goto :goto_14
.end method

.method public static formatDuration(JJLjava/io/PrintWriter;)V
    .registers 15
    .annotation build Lcom/cardannotation/RestrictTo;
        value = {
            .enum Lcom/cardannotation/RestrictTo$Scope;->LIBRARY_GROUP:Lcom/cardannotation/RestrictTo$Scope;
        }
    .end annotation

    .prologue
    .line 178
    move-wide v1, p0

    move-wide v3, p2

    move-object v5, p4

    move-wide v6, v1

    const-wide/16 v8, 0x0

    cmp-long v6, v6, v8

    if-nez v6, :cond_11

    .line 179
    move-object v6, v5

    const-string v7, "--"

    invoke-virtual {v6, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 183
    :goto_10
    return-void

    .line 182
    :cond_11
    move-wide v6, v1

    move-wide v8, v3

    sub-long/2addr v6, v8

    move-object v8, v5

    const/4 v9, 0x0

    invoke-static {v6, v7, v8, v9}, Lcom/card/core/util/TimeUtils;->formatDuration(JLjava/io/PrintWriter;I)V

    .line 183
    goto :goto_10
.end method

.method public static formatDuration(JLjava/io/PrintWriter;)V
    .registers 11
    .annotation build Lcom/cardannotation/RestrictTo;
        value = {
            .enum Lcom/cardannotation/RestrictTo$Scope;->LIBRARY_GROUP:Lcom/cardannotation/RestrictTo$Scope;
        }
    .end annotation

    .prologue
    .line 172
    move-wide v0, p0

    move-object v2, p2

    move-wide v3, v0

    move-object v5, v2

    const/4 v6, 0x0

    invoke-static {v3, v4, v5, v6}, Lcom/card/core/util/TimeUtils;->formatDuration(JLjava/io/PrintWriter;I)V

    .line 173
    return-void
.end method

.method public static formatDuration(JLjava/io/PrintWriter;I)V
    .registers 18
    .annotation build Lcom/cardannotation/RestrictTo;
        value = {
            .enum Lcom/cardannotation/RestrictTo$Scope;->LIBRARY_GROUP:Lcom/cardannotation/RestrictTo$Scope;
        }
    .end annotation

    .prologue
    .line 163
    move-wide v0, p0

    move-object/from16 v2, p2

    move/from16 v3, p3

    sget-object v7, Lcom/card/core/util/TimeUtils;->sFormatSync:Ljava/lang/Object;

    move-object v13, v7

    move-object v7, v13

    move-object v8, v13

    move-object v4, v8

    monitor-enter v7

    .line 164
    move-wide v7, v0

    move v9, v3

    :try_start_e
    invoke-static {v7, v8, v9}, Lcom/card/core/util/TimeUtils;->formatDurationLocked(JI)I

    move-result v7

    move v5, v7

    .line 165
    move-object v7, v2

    new-instance v8, Ljava/lang/String;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    sget-object v10, Lcom/card/core/util/TimeUtils;->sFormatStr:[C

    const/4 v11, 0x0

    move v12, v5

    invoke-direct {v9, v10, v11, v12}, Ljava/lang/String;-><init>([CII)V

    invoke-virtual {v7, v8}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 166
    move-object v7, v4

    monitor-exit v7

    .line 167
    return-void

    .line 166
    :catchall_26
    move-exception v7

    move-object v6, v7

    move-object v7, v4

    monitor-exit v7
    :try_end_2a
    .catchall {:try_start_e .. :try_end_2a} :catchall_26

    move-object v7, v6

    throw v7
.end method

.method public static formatDuration(JLjava/lang/StringBuilder;)V
    .registers 15
    .annotation build Lcom/cardannotation/RestrictTo;
        value = {
            .enum Lcom/cardannotation/RestrictTo$Scope;->LIBRARY_GROUP:Lcom/cardannotation/RestrictTo$Scope;
        }
    .end annotation

    .prologue
    .line 154
    move-wide v0, p0

    move-object v2, p2

    sget-object v6, Lcom/card/core/util/TimeUtils;->sFormatSync:Ljava/lang/Object;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move-object v3, v7

    monitor-enter v6

    .line 155
    move-wide v6, v0

    const/4 v8, 0x0

    :try_start_b
    invoke-static {v6, v7, v8}, Lcom/card/core/util/TimeUtils;->formatDurationLocked(JI)I

    move-result v6

    move v4, v6

    .line 156
    move-object v6, v2

    sget-object v7, Lcom/card/core/util/TimeUtils;->sFormatStr:[C

    const/4 v8, 0x0

    move v9, v4

    invoke-virtual {v6, v7, v8, v9}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    move-result-object v6

    .line 157
    move-object v6, v3

    monitor-exit v6

    .line 158
    return-void

    .line 157
    :catchall_1c
    move-exception v6

    move-object v5, v6

    move-object v6, v3

    monitor-exit v6
    :try_end_20
    .catchall {:try_start_b .. :try_end_20} :catchall_1c

    move-object v6, v5

    throw v6
.end method

.method private static formatDurationLocked(JI)I
    .registers 27

    .prologue
    .line 81
    move-wide/from16 v3, p0

    move/from16 v5, p2

    sget-object v16, Lcom/card/core/util/TimeUtils;->sFormatStr:[C

    move-object/from16 v0, v16

    array-length v0, v0

    move/from16 v16, v0

    move/from16 v17, v5

    move/from16 v0, v16

    move/from16 v1, v17

    if-ge v0, v1, :cond_1d

    .line 82
    move/from16 v16, v5

    move/from16 v0, v16

    new-array v0, v0, [C

    move-object/from16 v16, v0

    sput-object v16, Lcom/card/core/util/TimeUtils;->sFormatStr:[C

    .line 85
    :cond_1d
    sget-object v16, Lcom/card/core/util/TimeUtils;->sFormatStr:[C

    move-object/from16 v6, v16

    .line 87
    move-wide/from16 v16, v3

    const-wide/16 v18, 0x0

    cmp-long v16, v16, v18

    if-nez v16, :cond_53

    .line 88
    const/16 v16, 0x0

    move/from16 v7, v16

    .line 89
    add-int/lit8 v5, v5, -0x1

    .line 90
    :goto_2f
    move/from16 v16, v7

    move/from16 v17, v5

    move/from16 v0, v16

    move/from16 v1, v17

    if-ge v0, v1, :cond_42

    .line 91
    move-object/from16 v16, v6

    move/from16 v17, v7

    const/16 v18, 0x20

    aput-char v18, v16, v17

    goto :goto_2f

    .line 93
    :cond_42
    move-object/from16 v16, v6

    move/from16 v17, v7

    const/16 v18, 0x30

    aput-char v18, v16, v17

    .line 94
    move/from16 v16, v7

    const/16 v17, 0x1

    add-int/lit8 v16, v16, 0x1

    move/from16 v3, v16

    .line 148
    :goto_52
    return v3

    .line 98
    :cond_53
    move-wide/from16 v16, v3

    const-wide/16 v18, 0x0

    cmp-long v16, v16, v18

    if-lez v16, :cond_17c

    .line 99
    const/16 v16, 0x2b

    move/from16 v7, v16

    .line 105
    :goto_5f
    move-wide/from16 v16, v3

    const-wide/16 v18, 0x3e8

    rem-long v16, v16, v18

    move-wide/from16 v0, v16

    long-to-int v0, v0

    move/from16 v16, v0

    move/from16 v8, v16

    .line 106
    move-wide/from16 v16, v3

    const-wide/16 v18, 0x3e8

    div-long v16, v16, v18

    move-wide/from16 v0, v16

    long-to-double v0, v0

    move-wide/from16 v16, v0

    invoke-static/range {v16 .. v17}, Ljava/lang/Math;->floor(D)D

    move-result-wide v16

    move-wide/from16 v0, v16

    double-to-int v0, v0

    move/from16 v16, v0

    move/from16 v9, v16

    .line 107
    const/16 v16, 0x0

    move/from16 v10, v16

    const/16 v16, 0x0

    move/from16 v11, v16

    const/16 v16, 0x0

    move/from16 v12, v16

    .line 109
    move/from16 v16, v9

    const v17, 0x15180

    move/from16 v0, v16

    move/from16 v1, v17

    if-le v0, v1, :cond_af

    .line 110
    move/from16 v16, v9

    const v17, 0x15180

    div-int v16, v16, v17

    move/from16 v10, v16

    .line 111
    move/from16 v16, v9

    move/from16 v17, v10

    const v18, 0x15180

    mul-int v17, v17, v18

    sub-int v16, v16, v17

    move/from16 v9, v16

    .line 113
    :cond_af
    move/from16 v16, v9

    const/16 v17, 0xe10

    move/from16 v0, v16

    move/from16 v1, v17

    if-le v0, v1, :cond_d5

    .line 114
    move/from16 v16, v9

    const/16 v17, 0xe10

    move/from16 v0, v16

    div-int/lit16 v0, v0, 0xe10

    move/from16 v16, v0

    move/from16 v11, v16

    .line 115
    move/from16 v16, v9

    move/from16 v17, v11

    const/16 v18, 0xe10

    move/from16 v0, v17

    mul-int/lit16 v0, v0, 0xe10

    move/from16 v17, v0

    sub-int v16, v16, v17

    move/from16 v9, v16

    .line 117
    :cond_d5
    move/from16 v16, v9

    const/16 v17, 0x3c

    move/from16 v0, v16

    move/from16 v1, v17

    if-le v0, v1, :cond_f3

    .line 118
    move/from16 v16, v9

    const/16 v17, 0x3c

    div-int/lit8 v16, v16, 0x3c

    move/from16 v12, v16

    .line 119
    move/from16 v16, v9

    move/from16 v17, v12

    const/16 v18, 0x3c

    mul-int/lit8 v17, v17, 0x3c

    sub-int v16, v16, v17

    move/from16 v9, v16

    .line 122
    :cond_f3
    const/16 v16, 0x0

    move/from16 v13, v16

    .line 124
    move/from16 v16, v5

    if-eqz v16, :cond_197

    .line 125
    move/from16 v16, v10

    const/16 v17, 0x1

    const/16 v18, 0x0

    const/16 v19, 0x0

    invoke-static/range {v16 .. v19}, Lcom/card/core/util/TimeUtils;->accumField(IIZI)I

    move-result v16

    move/from16 v14, v16

    .line 126
    move/from16 v16, v14

    move/from16 v17, v11

    const/16 v18, 0x1

    move/from16 v19, v14

    if-lez v19, :cond_18b

    const/16 v19, 0x1

    :goto_115
    const/16 v20, 0x2

    invoke-static/range {v17 .. v20}, Lcom/card/core/util/TimeUtils;->accumField(IIZI)I

    move-result v17

    add-int v16, v16, v17

    move/from16 v14, v16

    .line 127
    move/from16 v16, v14

    move/from16 v17, v12

    const/16 v18, 0x1

    move/from16 v19, v14

    if-lez v19, :cond_18e

    const/16 v19, 0x1

    :goto_12b
    const/16 v20, 0x2

    invoke-static/range {v17 .. v20}, Lcom/card/core/util/TimeUtils;->accumField(IIZI)I

    move-result v17

    add-int v16, v16, v17

    move/from16 v14, v16

    .line 128
    move/from16 v16, v14

    move/from16 v17, v9

    const/16 v18, 0x1

    move/from16 v19, v14

    if-lez v19, :cond_191

    const/16 v19, 0x1

    :goto_141
    const/16 v20, 0x2

    invoke-static/range {v17 .. v20}, Lcom/card/core/util/TimeUtils;->accumField(IIZI)I

    move-result v17

    add-int v16, v16, v17

    move/from16 v14, v16

    .line 129
    move/from16 v16, v14

    move/from16 v17, v8

    const/16 v18, 0x2

    const/16 v19, 0x1

    move/from16 v20, v14

    if-lez v20, :cond_194

    const/16 v20, 0x3

    :goto_159
    invoke-static/range {v17 .. v20}, Lcom/card/core/util/TimeUtils;->accumField(IIZI)I

    move-result v17

    const/16 v18, 0x1

    add-int/lit8 v17, v17, 0x1

    add-int v16, v16, v17

    move/from16 v14, v16

    .line 130
    :goto_165
    move/from16 v16, v14

    move/from16 v17, v5

    move/from16 v0, v16

    move/from16 v1, v17

    if-ge v0, v1, :cond_197

    .line 131
    move-object/from16 v16, v6

    move/from16 v17, v13

    const/16 v18, 0x20

    aput-char v18, v16, v17

    .line 132
    add-int/lit8 v13, v13, 0x1

    .line 133
    add-int/lit8 v14, v14, 0x1

    goto :goto_165

    .line 101
    :cond_17c
    const/16 v16, 0x2d

    move/from16 v7, v16

    .line 102
    move-wide/from16 v16, v3

    move-wide/from16 v0, v16

    neg-long v0, v0

    move-wide/from16 v16, v0

    move-wide/from16 v3, v16

    goto/16 :goto_5f

    .line 126
    :cond_18b
    const/16 v19, 0x0

    goto :goto_115

    .line 127
    :cond_18e
    const/16 v19, 0x0

    goto :goto_12b

    .line 128
    :cond_191
    const/16 v19, 0x0

    goto :goto_141

    .line 129
    :cond_194
    const/16 v20, 0x0

    goto :goto_159

    .line 137
    :cond_197
    move-object/from16 v16, v6

    move/from16 v17, v13

    move/from16 v18, v7

    aput-char v18, v16, v17

    .line 138
    add-int/lit8 v13, v13, 0x1

    .line 140
    move/from16 v16, v13

    move/from16 v14, v16

    .line 141
    move/from16 v16, v5

    if-eqz v16, :cond_251

    const/16 v16, 0x1

    :goto_1ab
    move/from16 v15, v16

    .line 142
    move-object/from16 v16, v6

    move/from16 v17, v10

    const/16 v18, 0x64

    move/from16 v19, v13

    const/16 v20, 0x0

    const/16 v21, 0x0

    invoke-static/range {v16 .. v21}, Lcom/card/core/util/TimeUtils;->printField([CICIZI)I

    move-result v16

    move/from16 v13, v16

    .line 143
    move-object/from16 v16, v6

    move/from16 v17, v11

    const/16 v18, 0x68

    move/from16 v19, v13

    move/from16 v20, v13

    move/from16 v21, v14

    move/from16 v0, v20

    move/from16 v1, v21

    if-eq v0, v1, :cond_255

    const/16 v20, 0x1

    :goto_1d3
    move/from16 v21, v15

    if-eqz v21, :cond_259

    const/16 v21, 0x2

    :goto_1d9
    invoke-static/range {v16 .. v21}, Lcom/card/core/util/TimeUtils;->printField([CICIZI)I

    move-result v16

    move/from16 v13, v16

    .line 144
    move-object/from16 v16, v6

    move/from16 v17, v12

    const/16 v18, 0x6d

    move/from16 v19, v13

    move/from16 v20, v13

    move/from16 v21, v14

    move/from16 v0, v20

    move/from16 v1, v21

    if-eq v0, v1, :cond_25d

    const/16 v20, 0x1

    :goto_1f3
    move/from16 v21, v15

    if-eqz v21, :cond_260

    const/16 v21, 0x2

    :goto_1f9
    invoke-static/range {v16 .. v21}, Lcom/card/core/util/TimeUtils;->printField([CICIZI)I

    move-result v16

    move/from16 v13, v16

    .line 145
    move-object/from16 v16, v6

    move/from16 v17, v9

    const/16 v18, 0x73

    move/from16 v19, v13

    move/from16 v20, v13

    move/from16 v21, v14

    move/from16 v0, v20

    move/from16 v1, v21

    if-eq v0, v1, :cond_263

    const/16 v20, 0x1

    :goto_213
    move/from16 v21, v15

    if-eqz v21, :cond_266

    const/16 v21, 0x2

    :goto_219
    invoke-static/range {v16 .. v21}, Lcom/card/core/util/TimeUtils;->printField([CICIZI)I

    move-result v16

    move/from16 v13, v16

    .line 146
    move-object/from16 v16, v6

    move/from16 v17, v8

    const/16 v18, 0x6d

    move/from16 v19, v13

    const/16 v20, 0x1

    move/from16 v21, v15

    if-eqz v21, :cond_269

    move/from16 v21, v13

    move/from16 v22, v14

    move/from16 v0, v21

    move/from16 v1, v22

    if-eq v0, v1, :cond_269

    const/16 v21, 0x3

    :goto_239
    invoke-static/range {v16 .. v21}, Lcom/card/core/util/TimeUtils;->printField([CICIZI)I

    move-result v16

    move/from16 v13, v16

    .line 147
    move-object/from16 v16, v6

    move/from16 v17, v13

    const/16 v18, 0x73

    aput-char v18, v16, v17

    .line 148
    move/from16 v16, v13

    const/16 v17, 0x1

    add-int/lit8 v16, v16, 0x1

    move/from16 v3, v16

    goto/16 :goto_52

    .line 141
    :cond_251
    const/16 v16, 0x0

    goto/16 :goto_1ab

    .line 143
    :cond_255
    const/16 v20, 0x0

    goto/16 :goto_1d3

    :cond_259
    const/16 v21, 0x0

    goto/16 :goto_1d9

    .line 144
    :cond_25d
    const/16 v20, 0x0

    goto :goto_1f3

    :cond_260
    const/16 v21, 0x0

    goto :goto_1f9

    .line 145
    :cond_263
    const/16 v20, 0x0

    goto :goto_213

    :cond_266
    const/16 v21, 0x0

    goto :goto_219

    .line 146
    :cond_269
    const/16 v21, 0x0

    goto :goto_239
.end method

.method private static printField([CICIZI)I
    .registers 18

    .prologue
    .line 58
    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move v8, v4

    if-nez v8, :cond_e

    move v8, v1

    if-lez v8, :cond_73

    .line 59
    :cond_e
    move v8, v3

    move v6, v8

    .line 60
    move v8, v4

    if-eqz v8, :cond_17

    move v8, v5

    const/4 v9, 0x3

    if-ge v8, v9, :cond_1c

    :cond_17
    move v8, v1

    const/16 v9, 0x63

    if-le v8, v9, :cond_36

    .line 61
    :cond_1c
    move v8, v1

    const/16 v9, 0x64

    div-int/lit8 v8, v8, 0x64

    move v7, v8

    .line 62
    move-object v8, v0

    move v9, v3

    move v10, v7

    const/16 v11, 0x30

    add-int/lit8 v10, v10, 0x30

    int-to-char v10, v10

    aput-char v10, v8, v9

    .line 63
    add-int/lit8 v3, v3, 0x1

    .line 64
    move v8, v1

    move v9, v7

    const/16 v10, 0x64

    mul-int/lit8 v9, v9, 0x64

    sub-int/2addr v8, v9

    move v1, v8

    .line 66
    :cond_36
    move v8, v4

    if-eqz v8, :cond_3d

    move v8, v5

    const/4 v9, 0x2

    if-ge v8, v9, :cond_46

    :cond_3d
    move v8, v1

    const/16 v9, 0x9

    if-gt v8, v9, :cond_46

    move v8, v6

    move v9, v3

    if-eq v8, v9, :cond_60

    .line 67
    :cond_46
    move v8, v1

    const/16 v9, 0xa

    div-int/lit8 v8, v8, 0xa

    move v7, v8

    .line 68
    move-object v8, v0

    move v9, v3

    move v10, v7

    const/16 v11, 0x30

    add-int/lit8 v10, v10, 0x30

    int-to-char v10, v10

    aput-char v10, v8, v9

    .line 69
    add-int/lit8 v3, v3, 0x1

    .line 70
    move v8, v1

    move v9, v7

    const/16 v10, 0xa

    mul-int/lit8 v9, v9, 0xa

    sub-int/2addr v8, v9

    move v1, v8

    .line 72
    :cond_60
    move-object v8, v0

    move v9, v3

    move v10, v1

    const/16 v11, 0x30

    add-int/lit8 v10, v10, 0x30

    int-to-char v10, v10

    aput-char v10, v8, v9

    .line 73
    add-int/lit8 v3, v3, 0x1

    .line 74
    move-object v8, v0

    move v9, v3

    move v10, v2

    aput-char v10, v8, v9

    .line 75
    add-int/lit8 v3, v3, 0x1

    .line 77
    :cond_73
    move v8, v3

    move v0, v8

    return v0
.end method
