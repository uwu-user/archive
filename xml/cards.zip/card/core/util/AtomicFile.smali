.class public Lcom/card/core/util/AtomicFile;
.super Ljava/lang/Object;
.source "AtomicFile.java"


# instance fields
.field private final mBackupName:Ljava/io/File;

.field private final mBaseName:Ljava/io/File;


# direct methods
.method public constructor <init>(Ljava/io/File;)V
    .registers 10
    .param p1    # Ljava/io/File;
        .annotation build Lcom/cardannotation/NonNull;
        .end annotation
    .end param

    .prologue
    .line 54
    move-object v0, p0

    move-object v1, p1

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 55
    move-object v2, v0

    move-object v3, v1

    iput-object v3, v2, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    .line 56
    move-object v2, v0

    new-instance v3, Ljava/io/File;

    move-object v7, v3

    move-object v3, v7

    move-object v4, v7

    new-instance v5, Ljava/lang/StringBuilder;

    move-object v7, v5

    move-object v5, v7

    move-object v6, v7

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    move-object v6, v1

    invoke-virtual {v6}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ".bak"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    iput-object v3, v2, Lcom/card/core/util/AtomicFile;->mBackupName:Ljava/io/File;

    .line 57
    return-void
.end method

.method private static sync(Ljava/io/FileOutputStream;)Z
    .registers 4
    .param p0    # Ljava/io/FileOutputStream;
        .annotation build Lcom/cardannotation/NonNull;
        .end annotation
    .end param

    .prologue
    .line 212
    move-object v0, p0

    move-object v2, v0

    :try_start_2
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/FileDescriptor;->sync()V
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_9} :catch_c

    .line 213
    const/4 v2, 0x1

    move v0, v2

    .line 216
    :goto_b
    return v0

    .line 214
    :catch_c
    move-exception v2

    move-object v1, v2

    .line 216
    const/4 v2, 0x0

    move v0, v2

    goto :goto_b
.end method


# virtual methods
.method public delete()V
    .registers 3

    .prologue
    .line 72
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    move-result v1

    .line 73
    move-object v1, v0

    iget-object v1, v1, Lcom/card/core/util/AtomicFile;->mBackupName:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    move-result v1

    .line 74
    return-void
.end method

.method public failWrite(Ljava/io/FileOutputStream;)V
    .registers 8
    .param p1    # Ljava/io/FileOutputStream;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param

    .prologue
    .line 144
    move-object v0, p0

    move-object v1, p1

    move-object v3, v1

    if-eqz v3, :cond_1f

    .line 145
    move-object v3, v1

    invoke-static {v3}, Lcom/card/core/util/AtomicFile;->sync(Ljava/io/FileOutputStream;)Z

    move-result v3

    .line 147
    move-object v3, v1

    :try_start_b
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V

    .line 148
    move-object v3, v0

    iget-object v3, v3, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    move-result v3

    .line 149
    move-object v3, v0

    iget-object v3, v3, Lcom/card/core/util/AtomicFile;->mBackupName:Ljava/io/File;

    move-object v4, v0

    iget-object v4, v4, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-virtual {v3, v4}, Ljava/io/File;->renameTo(Ljava/io/File;)Z
    :try_end_1e
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_1e} :catch_20

    move-result v3

    .line 154
    :cond_1f
    :goto_1f
    return-void

    .line 150
    :catch_20
    move-exception v3

    move-object v2, v3

    .line 151
    const-string v3, "AtomicFile"

    const-string v4, "failWrite: Got exception:"

    move-object v5, v2

    invoke-static {v3, v4, v5}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result v3

    goto :goto_1f
.end method

.method public finishWrite(Ljava/io/FileOutputStream;)V
    .registers 8
    .param p1    # Ljava/io/FileOutputStream;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param

    .prologue
    .line 127
    move-object v0, p0

    move-object v1, p1

    move-object v3, v1

    if-eqz v3, :cond_15

    .line 128
    move-object v3, v1

    invoke-static {v3}, Lcom/card/core/util/AtomicFile;->sync(Ljava/io/FileOutputStream;)Z

    move-result v3

    .line 130
    move-object v3, v1

    :try_start_b
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V

    .line 131
    move-object v3, v0

    iget-object v3, v3, Lcom/card/core/util/AtomicFile;->mBackupName:Ljava/io/File;

    invoke-virtual {v3}, Ljava/io/File;->delete()Z
    :try_end_14
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_14} :catch_16

    move-result v3

    .line 136
    :cond_15
    :goto_15
    return-void

    .line 132
    :catch_16
    move-exception v3

    move-object v2, v3

    .line 133
    const-string v3, "AtomicFile"

    const-string v4, "finishWrite: Got exception:"

    move-object v5, v2

    invoke-static {v3, v4, v5}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result v3

    goto :goto_15
.end method

.method public getBaseFile()Ljava/io/File;
    .registers 3
    .annotation build Lcom/cardannotation/NonNull;
    .end annotation

    .prologue
    .line 65
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    move-object v0, v1

    return-object v0
.end method

.method public openRead()Ljava/io/FileInputStream;
    .registers 6
    .annotation build Lcom/cardannotation/NonNull;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/FileNotFoundException;
        }
    .end annotation

    .prologue
    .line 170
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/core/util/AtomicFile;->mBackupName:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_1b

    .line 171
    move-object v1, v0

    iget-object v1, v1, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    move-result v1

    .line 172
    move-object v1, v0

    iget-object v1, v1, Lcom/card/core/util/AtomicFile;->mBackupName:Ljava/io/File;

    move-object v2, v0

    iget-object v2, v2, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-virtual {v1, v2}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v1

    .line 174
    :cond_1b
    new-instance v1, Ljava/io/FileInputStream;

    move-object v4, v1

    move-object v1, v4

    move-object v2, v4

    move-object v3, v0

    iget-object v3, v3, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-direct {v2, v3}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    move-object v0, v1

    return-object v0
.end method

.method public readFully()[B
    .registers 14
    .annotation build Lcom/cardannotation/NonNull;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 183
    move-object v0, p0

    move-object v8, v0

    invoke-virtual {v8}, Lcom/card/core/util/AtomicFile;->openRead()Ljava/io/FileInputStream;

    move-result-object v8

    move-object v1, v8

    .line 185
    const/4 v8, 0x0

    move v2, v8

    .line 186
    move-object v8, v1

    :try_start_a
    invoke-virtual {v8}, Ljava/io/FileInputStream;->available()I

    move-result v8

    move v3, v8

    .line 187
    move v8, v3

    new-array v8, v8, [B

    move-object v4, v8

    .line 189
    :goto_13
    move-object v8, v1

    move-object v9, v4

    move v10, v2

    move-object v11, v4

    array-length v11, v11

    move v12, v2

    sub-int/2addr v11, v12

    invoke-virtual {v8, v9, v10, v11}, Ljava/io/FileInputStream;->read([BII)I
    :try_end_1d
    .catchall {:try_start_a .. :try_end_1d} :catchall_4d

    move-result v8

    move v5, v8

    .line 192
    move v8, v5

    if-gtz v8, :cond_2b

    .line 195
    move-object v8, v4

    move-object v6, v8

    .line 206
    move-object v8, v1

    invoke-virtual {v8}, Ljava/io/FileInputStream;->close()V

    move-object v8, v6

    move-object v0, v8

    return-object v0

    .line 197
    :cond_2b
    move v8, v2

    move v9, v5

    add-int/2addr v8, v9

    move v2, v8

    .line 198
    move-object v8, v1

    :try_start_30
    invoke-virtual {v8}, Ljava/io/FileInputStream;->available()I

    move-result v8

    move v3, v8

    .line 199
    move v8, v3

    move-object v9, v4

    array-length v9, v9

    move v10, v2

    sub-int/2addr v9, v10

    if-le v8, v9, :cond_4c

    .line 200
    move v8, v2

    move v9, v3

    add-int/2addr v8, v9

    new-array v8, v8, [B

    move-object v6, v8

    .line 201
    move-object v8, v4

    const/4 v9, 0x0

    move-object v10, v6

    const/4 v11, 0x0

    move v12, v2

    invoke-static {v8, v9, v10, v11, v12}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    :try_end_4a
    .catchall {:try_start_30 .. :try_end_4a} :catchall_4d

    .line 202
    move-object v8, v6

    move-object v4, v8

    .line 204
    :cond_4c
    goto :goto_13

    .line 206
    :catchall_4d
    move-exception v8

    move-object v7, v8

    move-object v8, v1

    invoke-virtual {v8}, Ljava/io/FileInputStream;->close()V

    move-object v8, v7

    throw v8
.end method

.method public startWrite()Ljava/io/FileOutputStream;
    .registers 11
    .annotation build Lcom/cardannotation/NonNull;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 93
    move-object v0, p0

    move-object v5, v0

    iget-object v5, v5, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v5

    if-eqz v5, :cond_4b

    .line 94
    move-object v5, v0

    iget-object v5, v5, Lcom/card/core/util/AtomicFile;->mBackupName:Ljava/io/File;

    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v5

    if-nez v5, :cond_5a

    .line 95
    move-object v5, v0

    iget-object v5, v5, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    move-object v6, v0

    iget-object v6, v6, Lcom/card/core/util/AtomicFile;->mBackupName:Ljava/io/File;

    invoke-virtual {v5, v6}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v5

    if-nez v5, :cond_4b

    .line 96
    const-string v5, "AtomicFile"

    new-instance v6, Ljava/lang/StringBuilder;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Couldn\'t rename file "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    move-object v7, v0

    iget-object v7, v7, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " to backup file "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    move-object v7, v0

    iget-object v7, v7, Lcom/card/core/util/AtomicFile;->mBackupName:Ljava/io/File;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    move-result v5

    .line 105
    :cond_4b
    :goto_4b
    :try_start_4b
    new-instance v5, Ljava/io/FileOutputStream;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    move-object v7, v0

    iget-object v7, v7, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-direct {v6, v7}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_56
    .catch Ljava/io/FileNotFoundException; {:try_start_4b .. :try_end_56} :catch_62

    move-object v1, v5

    .line 117
    :goto_57
    move-object v5, v1

    move-object v0, v5

    return-object v0

    .line 100
    :cond_5a
    move-object v5, v0

    iget-object v5, v5, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-virtual {v5}, Ljava/io/File;->delete()Z

    move-result v5

    goto :goto_4b

    .line 106
    :catch_62
    move-exception v5

    move-object v2, v5

    .line 107
    move-object v5, v0

    iget-object v5, v5, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-virtual {v5}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v5

    move-object v3, v5

    .line 108
    move-object v5, v3

    invoke-virtual {v5}, Ljava/io/File;->mkdirs()Z

    move-result v5

    if-nez v5, :cond_95

    .line 109
    new-instance v5, Ljava/io/IOException;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    new-instance v7, Ljava/lang/StringBuilder;

    move-object v9, v7

    move-object v7, v9

    move-object v8, v9

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Couldn\'t create directory "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v0

    iget-object v8, v8, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 112
    :cond_95
    :try_start_95
    new-instance v5, Ljava/io/FileOutputStream;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    move-object v7, v0

    iget-object v7, v7, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-direct {v6, v7}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_a0
    .catch Ljava/io/FileNotFoundException; {:try_start_95 .. :try_end_a0} :catch_a2

    move-object v1, v5

    .line 115
    goto :goto_57

    .line 113
    :catch_a2
    move-exception v5

    move-object v4, v5

    .line 114
    new-instance v5, Ljava/io/IOException;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    new-instance v7, Ljava/lang/StringBuilder;

    move-object v9, v7

    move-object v7, v9

    move-object v8, v9

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Couldn\'t create "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v0

    iget-object v8, v8, Lcom/card/core/util/AtomicFile;->mBaseName:Ljava/io/File;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v5
.end method
