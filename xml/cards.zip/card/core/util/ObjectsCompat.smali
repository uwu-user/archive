.class public Lcom/card/core/util/ObjectsCompat;
.super Ljava/lang/Object;
.source "ObjectsCompat.java"


# direct methods
.method private constructor <init>()V
    .registers 3

    .prologue
    .line 29
    move-object v0, p0

    move-object v1, v0

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 31
    return-void
.end method

.method public static equals(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 6
    .param p0    # Ljava/lang/Object;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param

    .prologue
    .line 50
    move-object v0, p0

    move-object v1, p1

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x13

    if-lt v2, v3, :cond_10

    .line 51
    move-object v2, v0

    move-object v3, v1

    invoke-static {v2, v3}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    move v0, v2

    .line 53
    :goto_f
    return v0

    :cond_10
    move-object v2, v0

    move-object v3, v1

    if-eq v2, v3, :cond_1f

    move-object v2, v0

    if-eqz v2, :cond_22

    move-object v2, v0

    move-object v3, v1

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_22

    :cond_1f
    const/4 v2, 0x1

    :goto_20
    move v0, v2

    goto :goto_f

    :cond_22
    const/4 v2, 0x0

    goto :goto_20
.end method

.method public static varargs hash([Ljava/lang/Object;)I
    .registers 4
    .param p0    # [Ljava/lang/Object;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param

    .prologue
    .line 92
    move-object v0, p0

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x13

    if-lt v1, v2, :cond_e

    .line 93
    move-object v1, v0

    invoke-static {v1}, Ljava/util/Objects;->hash([Ljava/lang/Object;)I

    move-result v1

    move v0, v1

    .line 95
    :goto_d
    return v0

    :cond_e
    move-object v1, v0

    invoke-static {v1}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v1

    move v0, v1

    goto :goto_d
.end method

.method public static hashCode(Ljava/lang/Object;)I
    .registers 3
    .param p0    # Ljava/lang/Object;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param

    .prologue
    .line 65
    move-object v0, p0

    move-object v1, v0

    if-eqz v1, :cond_b

    move-object v1, v0

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_9
    move v0, v1

    return v0

    :cond_b
    const/4 v1, 0x0

    goto :goto_9
.end method
