.class public Lcom/card/core/util/Pair;
.super Ljava/lang/Object;
.source "Pair.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<F:",
        "Ljava/lang/Object;",
        "S:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public final first:Ljava/lang/Object;
    .annotation build Lcom/cardannotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TF;"
        }
    .end annotation
.end field

.field public final second:Ljava/lang/Object;
    .annotation build Lcom/cardannotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TS;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 8
    .param p1    # Ljava/lang/Object;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TF;TS;)V"
        }
    .end annotation

    .prologue
    .line 37
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 38
    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lcom/card/core/util/Pair;->first:Ljava/lang/Object;

    .line 39
    move-object v3, v0

    move-object v4, v2

    iput-object v4, v3, Lcom/card/core/util/Pair;->second:Ljava/lang/Object;

    .line 40
    return-void
.end method

.method public static create(Ljava/lang/Object;Ljava/lang/Object;)Lcom/card/core/util/Pair;
    .registers 9
    .param p0    # Ljava/lang/Object;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Lcom/cardannotation/Nullable;
        .end annotation
    .end param
    .annotation build Lcom/cardannotation/NonNull;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<A:",
            "Ljava/lang/Object;",
            "B:",
            "Ljava/lang/Object;",
            ">(TA;TB;)",
            "Lcom/card/core/util/Pair",
            "<TA;TB;>;"
        }
    .end annotation

    .prologue
    .line 82
    move-object v0, p0

    move-object v1, p1

    new-instance v2, Lcom/card/core/util/Pair;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v3, v4, v5}, Lcom/card/core/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object v0, v2

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 7

    .prologue
    .line 52
    move-object v0, p0

    move-object v1, p1

    move-object v3, v1

    instance-of v3, v3, Lcom/card/core/util/Pair;

    if-nez v3, :cond_a

    .line 53
    const/4 v3, 0x0

    move v0, v3

    .line 56
    :goto_9
    return v0

    .line 55
    :cond_a
    move-object v3, v1

    check-cast v3, Lcom/card/core/util/Pair;

    move-object v2, v3

    .line 56
    move-object v3, v2

    iget-object v3, v3, Lcom/card/core/util/Pair;->first:Ljava/lang/Object;

    move-object v4, v0

    iget-object v4, v4, Lcom/card/core/util/Pair;->first:Ljava/lang/Object;

    invoke-static {v3, v4}, Lcom/card/core/util/ObjectsCompat;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_29

    move-object v3, v2

    iget-object v3, v3, Lcom/card/core/util/Pair;->second:Ljava/lang/Object;

    move-object v4, v0

    iget-object v4, v4, Lcom/card/core/util/Pair;->second:Ljava/lang/Object;

    invoke-static {v3, v4}, Lcom/card/core/util/ObjectsCompat;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_29

    const/4 v3, 0x1

    :goto_27
    move v0, v3

    goto :goto_9

    :cond_29
    const/4 v3, 0x0

    goto :goto_27
.end method

.method public hashCode()I
    .registers 4

    .prologue
    .line 66
    move-object v0, p0

    move-object v1, v0

    iget-object v1, v1, Lcom/card/core/util/Pair;->first:Ljava/lang/Object;

    if-nez v1, :cond_10

    const/4 v1, 0x0

    :goto_7
    move-object v2, v0

    iget-object v2, v2, Lcom/card/core/util/Pair;->second:Ljava/lang/Object;

    if-nez v2, :cond_18

    const/4 v2, 0x0

    :goto_d
    xor-int/2addr v1, v2

    move v0, v1

    return v0

    :cond_10
    move-object v1, v0

    iget-object v1, v1, Lcom/card/core/util/Pair;->first:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_7

    :cond_18
    move-object v2, v0

    iget-object v2, v2, Lcom/card/core/util/Pair;->second:Ljava/lang/Object;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    goto :goto_d
.end method

.method public toString()Ljava/lang/String;
    .registers 5

    .prologue
    .line 71
    move-object v0, p0

    new-instance v1, Ljava/lang/StringBuilder;

    move-object v3, v1

    move-object v1, v3

    move-object v2, v3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Pair{"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    move-object v2, v0

    iget-object v2, v2, Lcom/card/core/util/Pair;->first:Ljava/lang/Object;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    move-object v2, v0

    iget-object v2, v2, Lcom/card/core/util/Pair;->second:Ljava/lang/Object;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "}"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    move-object v0, v1

    return-object v0
.end method
