.class public final Lcom/card/core/R$string;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/card/core/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "string"
.end annotation


# static fields
.field public static final abc_action_bar_home_description:I = 0x7f0e000e

.field public static final abc_action_bar_up_description:I = 0x7f0e000f

.field public static final abc_action_menu_overflow_description:I = 0x7f0e0010

.field public static final abc_action_mode_done:I = 0x7f0e0011

.field public static final abc_activity_chooser_view_see_all:I = 0x7f0e0012

.field public static final abc_activitychooserview_choose_application:I = 0x7f0e0013

.field public static final abc_capital_off:I = 0x7f0e0014

.field public static final abc_capital_on:I = 0x7f0e0015

.field public static final abc_font_family_body_1_material:I = 0x7f0e002a

.field public static final abc_font_family_body_2_material:I = 0x7f0e002b

.field public static final abc_font_family_button_material:I = 0x7f0e002c

.field public static final abc_font_family_caption_material:I = 0x7f0e002d

.field public static final abc_font_family_display_1_material:I = 0x7f0e002e

.field public static final abc_font_family_display_2_material:I = 0x7f0e002f

.field public static final abc_font_family_display_3_material:I = 0x7f0e0030

.field public static final abc_font_family_display_4_material:I = 0x7f0e0031

.field public static final abc_font_family_headline_material:I = 0x7f0e0032

.field public static final abc_font_family_menu_material:I = 0x7f0e0033

.field public static final abc_font_family_subhead_material:I = 0x7f0e0034

.field public static final abc_font_family_title_material:I = 0x7f0e0035

.field public static final abc_menu_alt_shortcut_label:I = 0x7f0e0016

.field public static final abc_menu_ctrl_shortcut_label:I = 0x7f0e0017

.field public static final abc_menu_delete_shortcut_label:I = 0x7f0e0018

.field public static final abc_menu_enter_shortcut_label:I = 0x7f0e0019

.field public static final abc_menu_function_shortcut_label:I = 0x7f0e001a

.field public static final abc_menu_meta_shortcut_label:I = 0x7f0e001b

.field public static final abc_menu_shift_shortcut_label:I = 0x7f0e001c

.field public static final abc_menu_space_shortcut_label:I = 0x7f0e001d

.field public static final abc_menu_sym_shortcut_label:I = 0x7f0e001e

.field public static final abc_prepend_shortcut_label:I = 0x7f0e001f

.field public static final abc_search_hint:I = 0x7f0e0020

.field public static final abc_searchview_description_clear:I = 0x7f0e0021

.field public static final abc_searchview_description_query:I = 0x7f0e0022

.field public static final abc_searchview_description_search:I = 0x7f0e0023

.field public static final abc_searchview_description_submit:I = 0x7f0e0024

.field public static final abc_searchview_description_voice:I = 0x7f0e0025

.field public static final abc_shareactionprovider_share_with:I = 0x7f0e0026

.field public static final abc_shareactionprovider_share_with_application:I = 0x7f0e0027

.field public static final abc_toolbar_collapse_description:I = 0x7f0e0028

.field public static final app_name:I = 0x7f0e0036

.field public static final appbar_scrolling_view_behavior:I = 0x7f0e0000

.field public static final bottom_sheet_behavior:I = 0x7f0e0001

.field public static final character_counter_content_description:I = 0x7f0e0002

.field public static final character_counter_pattern:I = 0x7f0e0003

.field public static final fab_transformation_scrim_behavior:I = 0x7f0e0004

.field public static final fab_transformation_sheet_behavior:I = 0x7f0e0005

.field public static final hide_bottom_view_on_scroll_behavior:I = 0x7f0e0006

.field public static final mtrl_chip_close_icon_content_description:I = 0x7f0e0007

.field public static final password_toggle_content_description:I = 0x7f0e0008

.field public static final path_password_eye:I = 0x7f0e0009

.field public static final path_password_eye_mask_strike_through:I = 0x7f0e000a

.field public static final path_password_eye_mask_visible:I = 0x7f0e000b

.field public static final path_password_strike_through:I = 0x7f0e000c

.field public static final search_menu_title:I = 0x7f0e0029

.field public static final status_bar_notification_info_overflow:I = 0x7f0e000d


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 4891
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
