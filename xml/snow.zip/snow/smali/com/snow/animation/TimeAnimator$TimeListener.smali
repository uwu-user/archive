.class public interface Lcom/snow/animation/TimeAnimator$TimeListener;
.super Ljava/lang/Object;
.source "TimeAnimator.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/snow/animation/TimeAnimator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x209
    name = "TimeListener"
.end annotation


# virtual methods
.method public abstract onTimeUpdate(Lcom/snow/animation/TimeAnimator;JJ)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/snow/animation/TimeAnimator;",
            "JJ)V"
        }
    .end annotation
.end method
