.class final Lcom/snow/animation/ComPat;
.super Ljava/lang/Object;
.source "ComPat.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/snow/animation/ComPat$100;,
        Lcom/snow/animation/ComPat$101;,
        Lcom/snow/animation/ComPat$102;,
        Lcom/snow/animation/ComPat$103;,
        Lcom/snow/animation/ComPat$104;,
        Lcom/snow/animation/ComPat$105;,
        Lcom/snow/animation/ComPat$106;,
        Lcom/snow/animation/ComPat$107;,
        Lcom/snow/animation/ComPat$108;,
        Lcom/snow/animation/ComPat$109;,
        Lcom/snow/animation/ComPat$110;,
        Lcom/snow/animation/ComPat$111;,
        Lcom/snow/animation/ComPat$112;,
        Lcom/snow/animation/ComPat$113;
    }
.end annotation


# static fields
.field static ALPHA:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field static PIVOT_X:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field static PIVOT_Y:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field static ROTATION:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field static ROTATION_X:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field static ROTATION_Y:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field static SCALE_X:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field static SCALE_Y:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field static SCROLL_X:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field static SCROLL_Y:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field static TRANSLATION_X:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field static TRANSLATION_Y:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field static X:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field static Y:Lcom/snow/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/snow/util/Property",
            "<",
            "Landroid/view/View;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static final constructor <clinit>()V
    .registers 6

    new-instance v2, Lcom/snow/animation/ComPat$100;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "alpha"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$100;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->ALPHA:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$101;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "pivotX"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$101;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->PIVOT_X:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$102;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "pivotY"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$102;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->PIVOT_Y:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$103;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "translationX"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$103;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->TRANSLATION_X:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$104;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "translationY"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$104;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->TRANSLATION_Y:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$105;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "rotation"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$105;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->ROTATION:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$106;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "rotationX"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$106;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->ROTATION_X:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$107;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "rotationY"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$107;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->ROTATION_Y:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$108;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "scaleX"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$108;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->SCALE_X:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$109;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "scaleY"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$109;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->SCALE_Y:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$110;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "scrollX"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$110;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->SCROLL_X:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$111;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "scrollY"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$111;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->SCROLL_Y:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$112;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "x"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$112;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->X:Lcom/snow/util/Property;

    new-instance v2, Lcom/snow/animation/ComPat$113;

    move-object v5, v2

    move-object v2, v5

    move-object v3, v5

    const-string v4, "y"

    invoke-direct {v3, v4}, Lcom/snow/animation/ComPat$113;-><init>(Ljava/lang/String;)V

    sput-object v2, Lcom/snow/animation/ComPat;->Y:Lcom/snow/util/Property;

    return-void
.end method

.method constructor <init>()V
    .registers 4

    .prologue
    .line 167
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
