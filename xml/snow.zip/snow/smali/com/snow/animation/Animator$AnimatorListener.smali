.class public interface Lcom/snow/animation/Animator$AnimatorListener;
.super Ljava/lang/Object;
.source "Animator.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/snow/animation/Animator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x209
    name = "AnimatorListener"
.end annotation


# virtual methods
.method public abstract onAnimationCancel(Lcom/snow/animation/Animator;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/snow/animation/Animator;",
            ")V"
        }
    .end annotation
.end method

.method public abstract onAnimationEnd(Lcom/snow/animation/Animator;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/snow/animation/Animator;",
            ")V"
        }
    .end annotation
.end method

.method public abstract onAnimationRepeat(Lcom/snow/animation/Animator;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/snow/animation/Animator;",
            ")V"
        }
    .end annotation
.end method

.method public abstract onAnimationStart(Lcom/snow/animation/Animator;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/snow/animation/Animator;",
            ")V"
        }
    .end annotation
.end method
